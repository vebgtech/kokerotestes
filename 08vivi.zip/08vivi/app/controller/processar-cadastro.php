<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
// Conectar ao banco de dados
require_once "../config/conexao.php"; // Assumindo que seu arquivo de conexão está em "config/conexao.php"

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Obter os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $telefone = $_POST['telefone'];
    
    // Validar os campos (Você pode adicionar mais validações, como verificar se o email já existe)
    if (empty($nome) || empty($email) || empty($senha) || empty($telefone)) {
        echo "Todos os campos são obrigatórios!";
        exit();
    }

    // Hash da senha para segurança
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Definir o nível de usuário como 'Cliente' (idNivelUsuario = 1)
    $idNivelUsuario = 1;

    // Preparar a consulta para inserir o usuário
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, telefone, idNivelUsuario) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $nome, $email, $senhaHash, $telefone, $idNivelUsuario);

    // Executar a consulta
    if ($stmt->execute()) {
        // Redirecionar para uma página de login ou sucesso
        header("Location: ../view/cadastre.php?cadastro_sucesso=true"); // Altere para o local desejado após o cadastro
        exit();
    } else {
        header("Location: login.php?erro=1");
        echo "Erro ao cadastrar o usuário: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<?php
include('../config/conexao.php');

// Busca e filtros
$termo_busca = $_GET['busca'] ?? '';
$filtro_estado = $_GET['filtro_estado'] ?? '';
$filtro_tamanho = $_GET['filtro_tamanho'] ?? '';
$filtro_marca = $_GET['filtro_marca'] ?? '';

// Função para buscar produtos por categoria (com filtros, incluindo vendidos recentes)
function buscarProdutos($conn, $idCategoria, $termo_busca = '', $filtro_estado = '', $filtro_tamanho = '', $filtro_marca = '')
{
  $sql = "SELECT p.* FROM produtos p WHERE (p.vendido=0 OR (p.vendido=1 AND p.data_venda > DATE_SUB(NOW(), INTERVAL 7 DAY))) ";
  $params = [];
  $types = '';

  if ($idCategoria != 0) { // 0 para "Todos"
    $sql .= "AND p.idCategoria = ? ";
    $params[] = $idCategoria;
    $types .= 'i';
  }
  if (!empty($termo_busca)) {
    $sql .= "AND p.nome LIKE ? ";
    $params[] = "%$termo_busca%";
    $types .= 's';
  }
  if (!empty($filtro_estado)) {
    $sql .= "AND p.estado = ? ";
    $params[] = $filtro_estado;
    $types .= 's';
  }
  if (!empty($filtro_tamanho)) {
    $sql .= "AND p.tamanho = ? ";
    $params[] = $filtro_tamanho;
    $types .= 's';
  }
  if (!empty($filtro_marca)) {
    $sql .= "AND p.marca = ? ";
    $params[] = $filtro_marca;
    $types .= 's';
  }
  $sql .= "ORDER BY p.idProduto DESC";

  $stmt = $conn->prepare($sql);
  if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
  }
  $stmt->execute();
  return $stmt->get_result();
}

// Opções para filtros (dinâmicas, excluindo vendidos)
$estados = $conn->query("SELECT DISTINCT estado FROM produtos WHERE estado IS NOT NULL AND vendido=0 ORDER BY estado");
$tamanho = $conn->query("SELECT DISTINCT tamanho FROM produtos WHERE tamanho IS NOT NULL AND vendido=0 ORDER BY tamanho");
$marcas = $conn->query("SELECT DISTINCT marca FROM produtos WHERE marca IS NOT NULL AND vendido=0 ORDER BY marca");

// Array com as novas categorias
$categorias = [
  1 => "Bermudas e Shorts",
  2 => "Blazers",
  3 => "Blusas e Camisas",
  4 => "Calças",
  5 => "Casacos e Jaquetas",
  6 => "Conjuntos",
  7 => "Saias",
  8 => "Sapatos",
  9 => "Social",
  10 => "Vestidos"
];

// Para promoções: Buscar com filtros
$produtos_promocao = buscarProdutos($conn, 0, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
$produtos_promocao_filtrados = [];
while ($p = $produtos_promocao->fetch_assoc()) {
  if ($p['promocao'] == 1) {
    $produtos_promocao_filtrados[] = $p;
  }
}
$produtos_promocao = $produtos_promocao_filtrados; // Array filtrado
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Produtos - Brechó Kokero</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      background-color: #000;
      color: #fff;
      font-family: 'Poppins', sans-serif;
    }

    /* ===========================
       NAVBAR
    =========================== */
    .navbar {
      background-color: #014d00;
    }

    .navbar .nav-link {
      color: #9ed06f;
      font-weight: 600;
    }

    .navbar .nav-link:hover,
    .navbar .nav-link.active {
      color: #fcd634;
      /* amarelo */
    }

    .navbar .btn {
      border-radius: 20px;
      background-color: #2b5e1d;
      color: #fff;
    }

    .navbar .btn:hover {
      background-color: #1b3e0e;
    }

    /* ===========================
       FILTROS
    =========================== */
    .filtros {
      background-color: #111;
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 30px;
    }

    .filtros .form-label {
      color: #9ed06f;
    }

    .filtros .form-select {
      background-color: #222;
      color: #fff;
      border: 1px solid #2b5e1d;
    }

    .filtros .btn {
      background-color: #2b5e1d;
      color: #fff;
    }

    .filtros .btn:hover {
      background-color: #fcd634;
      color: #000;
    }

    /* ===========================
       PRODUTOS
    =========================== */
    .produtos {
      padding: 60px 15px;
    }

    .produtos h2 {
      font-weight: 700;
      margin-bottom: 30px;
      color: #fcd634;
      /* amarelo para títulos */
      text-align: center;
    }

    .produtos .categoria {
      margin-bottom: 60px;
    }

    .produtos .categoria h3 {
      color: #9ed06f;
      margin-bottom: 20px;
      text-align: left;
      border-bottom: 2px solid #2b5e1d;
      padding-bottom: 5px;
    }

    .produtos .card {
      background-color: #111;
      border: 1px solid #2b5e1d;
      border-radius: 10px;
      transition: transform 0.3s;
    }

    .produtos .card:hover {
      transform: scale(1.05);
      border-color: #fcd634;
    }

    .produtos .card img {
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      max-height: 250px;
      object-fit: cover;
    }

    .produtos .card-body {
      text-align: center;
    }

    .produtos .card-title {
      font-weight: 600;
      color: #fff;
    }

    .produtos .card-text {
      color: #ccc;
    }

    .produtos .preco {
      color: #fcd634;
      font-weight: bold;
      font-size: 1.2em;
    }

    .produtos .btn-comprar {
      background-color: #2b5e1d;
      color: #fff;
      border-radius: 20px;
    }

    .produtos .btn-comprar:hover {
      background-color: #fcd634;
      color: #000;
    }

    .sem-produtos {
      text-align: center;
      color: #ccc;
      font-style: italic;
    }

    .badge-estoque {
      font-size: 0.8em;
    }

    .vendido {
      color: #dc3545;
      font-weight: bold;
    }

    /* ===========================
       FOOTER
    =========================== */
    footer {
      background-color: #014d00;
      color: #fff;
      padding: 40px 20px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      text-align: center;
      gap: 20px;
    }

    footer a {
      color: #fff;
      text-decoration: none;
    }

    footer a:hover {
      color: #9ed06f;
    }

    .footer-social i {
      font-size: 24px;
      color: #fff;
      margin-right: 8px;
    }

    /* ===========================
       RESPONSIVO
    =========================== */
    @media (max-width: 768px) {
      .produtos .row {
        flex-direction: column;
        gap: 20px;
      }

      .navbar form {
        margin-top: 10px;
      }
    }
  </style>
  </header>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.html">
        <img src="../../public/img/logo.png" alt="Logo" style="height: 80px; width:auto;">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon" style="color:#fff;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link active" href="index.html">Início</a></li>
          <li class="nav-item"><a class="nav-link" href="produtos.php">Produtos</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdownMenu" role="button" data-bs-toggle="dropdown">
              Categorias
            </a>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
              <li><a class="dropdown-item" href="#novidade">Novidade</a></li>
              <li><a class="dropdown-item" href="#todos">Todos</a></li>
              <li><a class="dropdown-item" href="#promocoes">Promoções</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#bermudas-shorts">Bermudas e Shorts</a></li>
              <li><a class="dropdown-item" href="#blazers">Blazers</a></li>
              <li><a class="dropdown-item" href="#blusas-camisas">Blusas e Camisas</a></li>
              <li><a class="dropdown-item" href="#calcas">Calças</a></li>
              <li><a class="dropdown-item" href="#casacos-jaquetas">Casacos e Jaquetas</a></li>
              <li><a class="dropdown-item" href="#conjuntos">Conjuntos</a></li>
              <li><a class="dropdown-item" href="#saias">Saias</a></li>
              <li><a class="dropdown-item" href="#sapatos">Sapatos</a></li>
              <li><a class="dropdown-item" href="#social">Social</a></li>
              <li><a class="dropdown-item" href="#vestidos">Vestidos</a></li>
            </ul>
          </li>
        </ul>

        <form class="d-flex me-3" role="search" method="GET" action="produtos.php">
          <input class="form-control me-2" type="search" name="busca" placeholder="Buscar produtos..."
            value="<?php echo htmlspecialchars($termo_busca); ?>" aria-label="Search">
          <button class="btn btn-dark" type="submit">Buscar</button>
        </form>

        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item me-3">
            <a class="nav-link" href="minha-conta.html">Minha Conta</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="carrinho.html">Carrinho <span class="badge bg-danger">0</span></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Filtros -->
  <div class="produtos container">
    <div class="filtros">
      <h4 class="text-center mb-4" style="color: #9ed06f;">Filtrar Produtos</h4>
      <form method="GET" action="produtos.php">
        <input type="hidden" name="busca" value="<?php echo htmlspecialchars($termo_busca); ?>">
        <div class="row g-3">
          <div class="col-md-3">
            <label class="form-label">Estado</label>
            <select name="filtro_estado" class="form-select">
              <option value="">Todos</option>
              <?php while ($e = $estados->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($e['estado']) ?>" <?= $filtro_estado == $e['estado'] ? 'selected' : '' ?>><?= htmlspecialchars($e['estado']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Tamanho</label>
            <select name="filtro_tamanho" class="form-select">
              <option value="">Todos</option>
              <?php while ($t = $tamanho->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($t['tamanho']) ?>" <?= $filtro_tamanho == $t['tamanho'] ? 'selected' : '' ?>><?= htmlspecialchars($t['tamanho']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label">Marca</label>
            <select name="filtro_marca" class="form-select">
              <option value="">Todos</option>
              <?php while ($m = $marcas->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($m['marca']) ?>" <?= $filtro_marca == $m['marca'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($m['marca']) ?></option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn">Aplicar Filtros</button>
          </div>
        </div>
      </form>
    </div>

    <h2>Nossos Produtos</h2>

<!-- Todos -->
<?php 
$produtos_todos = buscarProdutos($conn, 0, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
$produtos_todos_filtrados = [];
while ($p = $produtos_todos->fetch_assoc()) {
  $produtos_todos_filtrados[] = $p;

}
if (count($produtos_todos_filtrados) > 0): 
?>
    <div class="categoria" id="todos">
      <h3>Todos</h3>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php foreach($produtos_todos_filtrados as $p): ?>
        <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? 'Sem Marca'); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        <?php endforeach; ?>
      </div>
    </div>
<?php else: ?>
    <div class="categoria">
      <h3>Todos</h3>
      <p class="sem-produtos">Nenhum produto disponível nesta categoria no momento.</p>
    </div>
<?php endif; ?>

    <!-- Bermudas e Shorts -->
    <?php
    $produtos_bermudas = buscarProdutos($conn, 1, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_bermudas->num_rows > 0):
      ?>
      <div class="categoria" id="bermudas-shorts">
        <h3>Bermudas e Shorts</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_bermudas->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? 'Sem Marca'); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Blazers -->
    <?php
    $produtos_blazers = buscarProdutos($conn, 2, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_blazers->num_rows > 0):
      ?>
      <div class="categoria" id="blazers">
        <h3>Blazers</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_blazers->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Blusas e Camisas -->
    <?php
    $produtos_blusas_e_camisas = buscarProdutos($conn, 3, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_blusas_e_camisas->num_rows > 0):
      ?>
      <div class="categoria" id="blusas_e_camisas">
        <h3>Blusas e Camisas</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_blusas_e_camisas->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Calças -->
    <?php
    $produtos_calcas = buscarProdutos($conn, 4, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_calcas->num_rows > 0):
      ?>
      <div class="categoria" id="calcas">
        <h3>Calças</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_calcas->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Casacos e Jaquetas -->
    <?php
    $produtos_casacos_e_jaquetas = buscarProdutos($conn, 5, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_casacos_e_jaquetas->num_rows > 0):
      ?>
      <div class="categoria" id="casacos_e_jaquetas">
        <h3>Casacos e Jaquetas</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_casacos_e_jaquetas->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Conjuntos -->
    <?php
    $produtos_conjuntos = buscarProdutos($conn, 6, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
    if ($produtos_conjuntos->num_rows > 0):
      ?>
      <div class="categoria" id="conjuntos">
        <h3>Conjuntos</h3>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php while ($p = $produtos_conjuntos->fetch_assoc()): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <!-- Saias -->
<?php 
$produtos_saias = buscarProdutos($conn, 7, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
if ($produtos_saias->num_rows > 0): 
?>
<div class="categoria" id="saias">
    <h3>Saias</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while($p = $produtos_saias->fetch_assoc()): ?>
                    <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>

<!-- Nome da Categoria -->
<?php 
$produtos_sapatos = buscarProdutos($conn, 8, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
if ($produtos_sapatos->num_rows > 0): 
?>
<div class="categoria" id="sapatos">
    <h3>Sapatos</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while($p = $produtos_sapatos->fetch_assoc()): ?>
                            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>

<!-- Social -->
<?php 
$produtos_social = buscarProdutos($conn, 9, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
if ($produtos_social->num_rows > 0): 
?>
<div class="categoria" id="social">
    <h3>Social</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while($p = $produtos_social->fetch_assoc()): ?>
              <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>

<!-- Vestidos -->
<?php 
$produtos_vestidos = buscarProdutos($conn, 10, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
if ($produtos_vestidos->num_rows > 0): 
?>
<div class="categoria" id="vestidos">
    <h3>Vestidos</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while($p = $produtos_vestidos->fetch_assoc()): ?>
              <div class="col">
              <div class="card">
                <img src="../../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? 'Produto de qualidade do Brechó Kokero.'); ?>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php endif; ?>

    <!-- Promoções -->
    <div class="categoria" id="promocoes">
      <h3>Promoções</h3>
      <?php if (count($produtos_promocao) > 0): ?>
        <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php foreach ($produtos_promocao as $p): ?>
            <div class="col">
              <div class="card">
                <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg'); ?>" class="card-img-top"
                  alt="<?= htmlspecialchars($p['nome']); ?>" onerror="this.src='../../public/img/default.jpg';"
                  onerror="this.src='../../public/img/default.jpg';">
                <div class="card-body">
                  <h5 class="card-title">
                    <?= htmlspecialchars($p['nome']); ?> -
                    <?= htmlspecialchars($p['marca'] ?? ''); ?>
                  </h5>
                  <p class="card-text">
                    <?= htmlspecialchars($p['descricao'] ?? ''); ?> <strong>Em Promoção!</strong>
                  </p>
                  <p class="preco">R$
                    <?= number_format($p['preco'], 2, ',', '.'); ?>
                  </p>
                  <p class="text-muted small">Estado:
                    <?= htmlspecialchars($p['estado'] ?? 'N/A'); ?> | Tamanho:
                    <?= htmlspecialchars($p['tamanho'] ?? 'N/A'); ?>
                  </p>
                  <?php if ($p['vendido'] == 1): ?>
                    <p class="vendido">Já foi vendido</p>
                  <?php else: ?>
                    <?php if ($p['estoque'] == 1): ?>
                      <span class="badge bg-info badge-estoque">Produto Único</span>
                    <?php elseif ($p['estoque'] > 1): ?>
                      <span class="badge bg-success badge-estoque">Em Estoque</span>
                    <?php else: ?>
                      <span class="badge bg-danger badge-estoque">Fora de Estoque</span>
                    <?php endif; ?>
                    <br><br>
                    <a href="produto_detalhes.php?id=<?= $p['idProduto']; ?>" class="btn btn-comprar">Comprar Agora</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="sem-produtos">Nenhuma promoção ativa no momento. Fique de olho!</p>
      <?php endif; ?>
    </div>

  </div>

  <!-- Footer -->
  <footer>
    <div class="footer-social">
      <h5>Siga-nos:</h5>
      <p><i class="bi bi-instagram"></i> <a href="https://www.instagram.com/brechokokero"
          target="_blank">@brechokokero</a></p>
      <p><i class="bi bi-whatsapp"></i> <a href="https://wa.me/5511992424158" target="_blank">+55 11 99242-4158</a></p>
    </div>
    <div class="footer-links">
      <h5>Links Úteis</h5>
      <ul>
        <li><a href="index.html">Início</a></li>
        <li><a href="produtos.php">Produtos</a></li>
        <li><a href="promocoes.html">Promoções</a></li>
        <li><a href="contato.html">Contato</a></li>
      </ul>
    </div>
    <div class="footer-logo">
      <img src="../../public/img/logo.png" alt="Logo" style="height: 60px; width: auto;">
      <p>&copy; 2024 Brechó Kokero. Todos os direitos reservados.</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
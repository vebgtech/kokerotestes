<?php
session_start();
// O index está na raiz. O ponto de partida é '__DIR__' (o diretório atual).

// Conexão (app/config/conexao.php)
require_once('app/model/produto.php'); 
require_once('app/model/produto_dao.php'); 
require_once('app/model/UsuarioDAO.php'); 

$conn = Conexao::getConexao();
$produtoDAO = new ProdutoDAO($conn); // ESTE JÁ ESTÁ CORRETO
$usuarioDAO = new UsuarioDAO(); // ESTE AGORA TEM CONSTRUTOR VAZIO

// ===================================
// LÓGICA DO PAINEL ADMIN
// ===================================
$isAdmin = false;
if (isset($_SESSION['usuario']) && $_SESSION['usuario'] === true && isset($_SESSION['usuario_id'])) {
    // Buscamos o usuário com a Model
    $dados_admin = $usuarioDAO->buscarPorId($_SESSION['usuario_id']);
    
    if ($dados_admin && $dados_admin['idNivelUsuario'] == 2) {
        $isAdmin = true;
    }
}
// ===================================

// Filtros (mantidos)
$termo_busca = $_GET['busca'] ?? '';
$filtro_estado = $_GET['filtro_estado'] ?? '';
$filtro_tamanho = $_GET['filtro_tamanho'] ?? '';
$filtro_marca = $_GET['filtro_marca'] ?? '';

// 🚨 FLUXO POO: A Model busca os dados 🚨

// 1. Dados para o Carrossel e Primeiras Fileiras (Aleatórios)
$produtos_aleatorios = $produtoDAO->buscarProdutosAleatorios(6); 

// 2. Dados para Filtros da Navbar 
$estados = $produtoDAO->getOpcoesFiltro('estado', false);
$tamanho = $produtoDAO->getOpcoesFiltro('tamanho', false);
$marcas = $produtoDAO->getOpcoesFiltro('marca', false);

// Array com as novas categorias (mantido, pois é estático/cacheado)
$categorias = [
    1 => "Bermudas e Shorts",
    2 => "Blazers",
    3 => "Blusas e Camisas",
    4 => "Calças",
    5 => "Casacos e Jaquetas",
    6 => "Conjuntos",
    7 => "Saias",
    8 => "Sapatos",
    9 => "Social",
    10 => "Vestidos"
];

// Lógica de Promoções 
$produtos_promocao_todos = $produtoDAO->buscarProdutosComFiltros(0, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);

$produtos_promocao_filtrados = array_filter($produtos_promocao_todos, function($p) {
    return $p['promocao'] == 1;
});
$produtos_promocao = $produtos_promocao_filtrados;


// --- Adicionar ao carrinho (Mantido o fluxo de controle) ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'adicionar_carrinho') {
    
    if (!isset($_SESSION['usuario_id']) || empty($_SESSION['usuario_id'])) {
        $_SESSION['erro_carrinho'] = "Você precisa fazer login para adicionar itens ao carrinho.";
        header("Location: index.php");
        exit();
    }
    
    $idProdutoForm = isset($_POST['id_produto']) ? (int)$_POST['id_produto'] : 0;
    
    if ($idProdutoForm > 0) {
        // Busca do produto agora deve usar a Model/DAO
        $produto_check = $produtoDAO->buscarPorId($idProdutoForm); // Usar buscarPorId

        if ($produto_check && $produto_check->isVendido() == 0) { // Usar isVendido() da entidade Produto
            if (!isset($_SESSION['carrinho'])) $_SESSION['carrinho'] = [];

            if (!in_array($idProdutoForm, $_SESSION['carrinho'])) {
                $_SESSION['carrinho'][] = $idProdutoForm;
                $_SESSION['sucesso_carrinho'] = "Produto adicionado ao carrinho com sucesso!";
            } else {
                $_SESSION['sucesso_carrinho'] = "Este produto já está no carrinho.";
            }
            
            header("Location: app/view/produto_detalhes.php?id=" . $idProdutoForm);
            exit();
        } else {
            $erro = "Produto não disponível para compra.";
        }
    }
}


// CORREÇÃO: Recupera mensagem da sessão e remove
if (isset($_SESSION['sucesso_carrinho'])) {
    $sucesso = $_SESSION['sucesso_carrinho'];
    unset($_SESSION['sucesso_carrinho']);
}

if (isset($_SESSION['erro_carrinho'])) {
    $erro_carrinho = $_SESSION['erro_carrinho'];
    unset($_SESSION['erro_carrinho']);
}

// CORREÇÃO: Limpa o ID da sessão se estiver acessando uma URL nova com ID
if (isset($_GET['id'])) {
    $_SESSION['current_product_id'] = (int)$_GET['id'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
</html>




<?php
session_start();
require_once '../config/conexao.php';
require_once '../model/produto_dao.php'; // Inclui a Model
$conn = Conexao::getConexao();

// Instancia a Model
$produtoDAO = new ProdutoDAO($conn);

// Filtros (mantidos)
$termo_busca = $_GET['busca'] ?? '';
$filtro_estado = $_GET['filtro_estado'] ?? '';
$filtro_tamanho = $_GET['filtro_tamanho'] ?? '';
$filtro_marca = $_GET['filtro_marca'] ?? '';

// 🚨 NOVO FLUXO POO: A Model busca os dados 🚨

// 1. Dados para Filtros (Movidos para ProdutoDAO)
$estados = $produtoDAO->getOpcoesFiltro('estado', false);
$tamanho = $produtoDAO->getOpcoesFiltro('tamanho', false);
$marcas = $produtoDAO->getOpcoesFiltro('marca', false);

// 2. Dados para Categorias (Movidos para ProdutoDAO)
$categorias_dao = $produtoDAO->getCategorias();
$categorias = [];
foreach ($categorias_dao as $cat) {
    $categorias[$cat['idCategoria']] = $cat['descricao'];
}

// 3. Busca de todos os produtos para promoções
$produtos_todos_com_filtros = $produtoDAO->buscarProdutosComFiltros(0, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);

$produtos_promocao = array_filter($produtos_todos_com_filtros, function($p) {
    return $p['promocao'] == 1;
});

// A função buscarProdutos não é mais necessária aqui, pois foi substituída
// pela chamada da Model $produtoDAO->buscarProdutosComFiltros(...)

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'adicionar_carrinho') {
    // Lógica de carrinho (Mantida, mas a consulta do produto está na Model)
    // ...
}

if (isset($_SESSION['sucesso_carrinho'])) {
    $sucesso = $_SESSION['sucesso_carrinho'];
    unset($_SESSION['sucesso_carrinho']);
}

if (isset($_SESSION['erro_carrinho'])) {
    $erro_carrinho = $_SESSION['erro_carrinho'];
    unset($_SESSION['erro_carrinho']);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<body>
    <div class="produtos container">
        <h2>Nossos Produtos</h2>
        <div class="categoria" id="promocoes">
            <h3>Promoções</h3>
            <?php if (count($produtos_promocao) > 0): ?>
                <div class="row row-cols-1 row-cols-md-3 g-4">
                    <?php foreach ($produtos_promocao as $p): ?>
                        <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="sem-produtos">Nenhuma promoção ativa no momento. Fique de olho!</p>
            <?php endif; ?>
        </div>

        <?php 
        // 🚨 NOVO FLUXO POO: Busca todos os produtos filtrados (sem categoria específica)
        $produtos_todos_filtrados = $produtos_todos_com_filtros;
        if (count($produtos_todos_filtrados) > 0): 
        ?>
            <div class="categoria" id="todos">
                <h3>Todos</h3>
                <div class="row row-cols-1 row-cols-md-3 g-4">
                    <?php foreach($produtos_todos_filtrados as $p): ?>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="categoria">
                <h3>Todos</h3>
                <p class="sem-produtos">Nenhum produto disponível nesta categoria no momento.</p>
            </div>
        <?php endif; ?>

        <?php
        // 🚨 NOVO FLUXO POO: Iteração por categoria 🚨
        foreach ($categorias as $idCategoria => $nomeCategoria):
            // Busca específica por ID de Categoria
            $produtos_categoria = $produtoDAO->buscarProdutosComFiltros($idCategoria, $termo_busca, $filtro_estado, $filtro_tamanho, $filtro_marca);
            
            if (count($produtos_categoria) > 0):
        ?>
            <div class="categoria" id="<?= strtolower(str_replace([' ', 'ç', 'á', 'ã', 'é', 'ê', 'í', 'ó', 'ú'], ['-', 'c', 'a', 'a', 'e', 'e', 'i', 'o', 'u'], $nomeCategoria)); ?>">
                <h3><?= htmlspecialchars($nomeCategoria); ?></h3>
                <div class="row row-cols-1 row-cols-md-3 g-4">
                    <?php foreach ($produtos_categoria as $p): ?>
                        <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php endforeach; ?>
    </div>
</body>
</html>
<?php
require_once '../config/conexao.php'; // Acesso ao Singleton de Conexão

class UsuarioDAO
{
    // Remova a propriedade $conn ou mantenha-a, mas não inicialize no construct

    public function __construct() {} // <--- Construtor vazio

    // Método de conexão defensivo (opcional, mas recomendado)
    private function getConnection() {
        return Conexao::getConexao();
    }

    // Exemplo: Atualize todos os seus métodos para usar getConnection()
    public function buscarPorId($idUsuario)
    {
        $conn = $this->getConnection(); // <-- CONEXÃO OBTIDA AQUI
        $sql = "SELECT nome, email, telefone, senha, idNivelUsuario FROM usuarios WHERE idUsuario = ?";
        try {
            $stmt = $conn->prepare($sql);
            $stmt->execute([$idUsuario]);
            return $stmt->fetch(PDO::FETCH_ASSOC); 
        } catch (PDOException $e) {
            // ...
        }
    }
    
    // Faça essa mudança (obter a conexão dentro do método) para todos os métodos do UsuarioDAO.
}
?>
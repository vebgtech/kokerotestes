<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" href="img/logo.png">
  <title>Brechó Koꓘero</title> 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<!-- ===========================
     NAVBAR PRINCIPAL
=========================== -->
<header>
    <div class="header-main-bar">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <button class="navbar-toggler d-lg-none menu-toggle-btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand flex-grow-1 flex-lg-grow-0 text-center text-lg-start" href="index.php">
              <img src="img/logo.png" alt="Logo Brechó Kokero">
            </a>
            
            <form class="search-form flex-grow-1 mx-4 d-none d-lg-flex" role="search">
                <input class="form-control" type="search" placeholder="Digite aqui o que deseja buscar" aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>

            <a class="cart-link" href="#">
                <i class="bi bi-cart-fill" style="font-size: 1.5rem;"></i>
                <span class="badge rounded-pill">0</span>
            </a>
        </div>
    </div>

    <div class="header-search-mobile d-lg-none">
        <div class="container-fluid py-2">
            <form class="search-form" role="search">
                <input class="form-control" type="search" placeholder="Digite aqui o que deseja buscar" aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg header-nav-bar">
      <div class="container-fluid justify-content-center">
    
        <div class="collapse navbar-collapse flex-grow-0" id="navbarContent">
          <ul class="navbar-nav">
    
            <li class="nav-item">
              <a class="nav-link" href="faq.php">
                <i class="bi bi-box-seam me-1"></i> FAQ
              </a>
            </li>
    
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-tags-fill me-1"></i> Produtos
              </a>
              <ul class="dropdown-menu">
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Feminino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">sapatos</a></li>
                    <li><a class="dropdown-item" href="#">Blusas</a></li>
                    <li><a class="dropdown-item" href="#">Saias</a></li>
                  </ul>
                </li>
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Masculino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Camisas</a></li>
                    <li><a class="dropdown-item" href="#">Calças</a></li>
                    <li><a class="dropdown-item" href="#">Jaquetas</a></li>
                  </ul>
                </li>
                <li><hr class="dropdown-divider" style="border-color: #2b5e1d;"></li>
                <li><a class="dropdown-item" href="produtos.php">Todos os Produtos</a></li>
              </ul>
            </li>
    
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-fill me-1"></i> Minha Conta
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="log.php">Login</a></li>
                
                <li><a class="dropdown-item" href="#">Não tem conta? Cadastre-se</a></li>
              </ul>
            </li>
    
          </ul>
        </div>
      </div>
    </nav>
</header>


<!-- ===========================
     FIM DA NAVBAR
=========================== -->

  <!-- Carrossel -->
  <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/carosel1.png" class="d-block w-100" alt="Slide 1">
      </div>
      <div class="carousel-item">
        <img src="img/carosel2.png" class="d-block w-100" alt="Slide 2">
      </div>
      <div class="carousel-item">
        <img src="img/carosel2.png" class="d-block w-100" alt="Slide 3">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

<!-- Produtos -->
<div class="container text-center produtos">

  <!-- Linha antes da primeira fileira -->
  <hr class="linha-produtos">

  <!-- Primeira fileira -->
  <div class="row g-4">
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 1">
      <p>Camiseta Foda</p>
    </div>
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 2">
      <p>Blazer Elegante</p>
    </div>
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 3">
      <p>Blazer Moderno</p>
    </div>
  </div>

  <!-- Linha entre as fileiras -->
  <hr class="linha-produtos">

  <!-- Segunda fileira -->
  <div class="row g-4 mt-4">
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 4">
      <p>Jaqueta Jeans</p>
    </div>
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 5">
      <p>Casaco Vintage</p>
    </div>
    <div class="col-md-4">
      <img src="img/foto.png" alt="Produto 6">
      <p>Casaco Cinza</p>
    </div>
  </div>

  <!-- Linha depois da última fileira -->
  <hr class="linha-produtos">

</div>





  <!-- Footer -->
<footer class="footer">
  <div class="container">
    <div class="row gy-4">
      
      <!-- Logo + descrição -->
      <div class="col-lg-4 col-md-6 footer-info">
        <a href="index.php" class="logo d-flex align-items-center">
          <img src="img/logo.png" alt="Logo">
          <span>Brechó Koꓘero</span>
        </a>
        <p>Sua loja online de roupas, estilo e qualidade. Verde, amarelo e preto para realçar sua identidade.</p>
        <div class="social-links d-flex mt-3">
          <a href="#"><i class="bi bi-twitter"></i></a>
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/brecho.kokero?igsh=aTV4M3YyNmViZXB1"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <!-- Links úteis -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Links</h4>
        <ul>
          <li><a href="#">Início</a></li>
          <li><a href="#">Produtos</a></li>
          <li><a href="#">Categorias</a></li>
          <li><a href="#">Contato</a></li>
        </ul>
      </div>

      <!-- Categorias -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Categorias</h4>
        <ul>
          <li><a href="#">Masculino</a></li>
          <li><a href="#">Feminino</a></li>
          <li><a href="#">Infantil</a></li>
          <li><a href="#">Acessórios</a></li>
        </ul>
      </div>

      <!-- Contato -->
      <div class="col-lg-4 col-md-6 footer-contact">
        <h4>Contato</h4>
        <p>
          Rua Exemplo, 123 <br>
          Cidade - Estado <br>
          Brasil <br><br>
          <strong>Telefone:</strong> (11) 99999-9999<br>
          <strong>Email:</strong> contato@minhaloja.com<br>
        </p>
      </div>

    </div>
  </div>

  <div class="container mt-4">
    <div class="copyright">
      &copy; 2025 <strong><span>Brechó Koꓘero</span></strong>. Todos os direitos reservados.
    </div>
    <div class="credits">
      Desenvolvido com 💛 por <a href="https://vebgtech.talentosdoifsp.gru.br/">VebgTech</a>
    </div>
  </div>
</footer>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>
</body>
</html>

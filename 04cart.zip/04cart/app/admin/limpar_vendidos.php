<?php
include('../config/conexao.php');

$stmt = $conn->prepare("SELECT idProduto, imagem FROM produtos WHERE vendido=1 AND data_venda < DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $imagem_nome = $row['imagem'];
    if ($imagem_nome != 'default.jpg') {
        $imagem_path = "../../public/img/" . $imagem_nome;
        if (file_exists($imagem_path)) {
            unlink($imagem_path);
        }
    }
    // Deletar produto
    $deleteStmt = $conn->prepare("DELETE FROM produtos WHERE idProduto=?");
    $deleteStmt->bind_param("i", $row['idProduto']);
    $deleteStmt->execute();
    $deleteStmt->close();
}
$stmt->close();
?>

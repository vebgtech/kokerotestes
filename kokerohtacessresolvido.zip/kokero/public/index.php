<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" href="public/img/logo.png">
  <title>Brechó Koꓘero</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="public/css/estilo.css">
</head>
<body>

<!-- ===========================
     NAVBAR PRINCIPAL
=========================== -->
<nav class="navbar navbar-expand-lg position-relative" style="background-color:#014d00;">
  <div class="container-fluid align-items-center">

    <!-- ===========================
         LOGO À ESQUERDA
    ============================ -->
    <a class="navbar-brand" href="index.php">
      <img src="public/img/logo.png" alt="Logo" style="height: 80px; width:auto;">
    </a>

    <!-- ===========================
         BARRA DE PESQUISA CENTRAL
    ============================ -->
    <form class="d-flex search-form" role="search">
      <input class="form-control me-2" type="search" placeholder="Buscar produtos..." aria-label="Search">
      <button class="btn btn-dark" type="submit">Buscar</button>
    </form>

    <!-- ===========================
         BOTÃO HAMBÚRGUER MOBILE
    ============================ -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
      <span class="navbar-toggler-icon" style="color:#fff;"></span>
    </button>

    <!-- ===========================
         MENU COLAPSÁVEL
    ============================ -->
    <div class="collapse navbar-collapse" id="navbarContent">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

        <!-- Início com ícone -->
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="bi bi-house-door-fill me-1"></i> Início
          </a>
        </li>

        <!-- Produtos com ícone -->
        <li class="nav-item">
          <a class="nav-link" href="public/faq.php">
            <i class="bi bi-box-seam me-1"></i> FAQ
          </a>
        </li>

        <!-- Categorias dropdown com submenus -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="dropdownMenu" role="button">
            <i class="bi bi-tags-fill me-1"></i> Produtos
          </a>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenu">

            <!-- Feminino com submenu -->
            <li class="dropdown-submenu">
              <a class="dropdown-item dropdown-toggle" href="#">Feminino</a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Vestidos</a></li>
                <li><a class="dropdown-item" href="#">Blusas</a></li>
                <li><a class="dropdown-item" href="#">Saias</a></li>
              </ul>
            </li>

            <!-- Masculino com submenu -->
            <li class="dropdown-submenu">
              <a class="dropdown-item dropdown-toggle" href="#">Masculino</a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Camisas</a></li>
                <li><a class="dropdown-item" href="#">Calças</a></li>
                <li><a class="dropdown-item" href="#">Jaquetas</a></li>
              </ul>
            </li>

            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="public/produtos.php">Todos os Produtos</a></li>
          </ul>
        </li>

        <!-- Minha Conta dropdown -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="accountDropdown" role="button">
            <i class="bi bi-person-fill me-1"></i> Minha Conta
          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="accountDropdown">
            <li><a class="dropdown-item" href="login.php">Login</a></li>
            <li><a class="dropdown-item" href="cadastro.php">Não tem conta? Cadastre-se</a></li>
          </ul>
        </li>

      </ul>
    </div>
    <!-- FIM DO MENU COLAPSÁVEL -->

    <!-- ===========================
         CARRINHO (FINAL DIREITA)
    ============================ -->
    <a class="cart-link" href="#">
      <i class="bi bi-cart-fill" style="font-size: 1.5rem;"></i>
      <span class="badge bg-danger">0</span>
    </a>

  </div>
</nav>
<!-- ===========================
     FIM DA NAVBAR
=========================== -->

  <!-- Carrossel -->
  <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="public/img/carosel1.png" class="d-block w-100" alt="Slide 1">
      </div>
      <div class="carousel-item">
        <img src="public/img/carosel2.png" class="d-block w-100" alt="Slide 2">
      </div>
      <div class="carousel-item">
        <img src="public/img/carosel2.png" class="d-block w-100" alt="Slide 3">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>

<!-- Produtos -->
<div class="container text-center produtos">

  <!-- Linha antes da primeira fileira -->
  <hr class="linha-produtos">

  <!-- Primeira fileira -->
  <div class="row g-4">
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 1">
      <p>Camiseta Foda</p>
    </div>
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 2">
      <p>Blazer Elegante</p>
    </div>
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 3">
      <p>Blazer Moderno</p>
    </div>
  </div>

  <!-- Linha entre as fileiras -->
  <hr class="linha-produtos">

  <!-- Segunda fileira -->
  <div class="row g-4 mt-4">
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 4">
      <p>Jaqueta Jeans</p>
    </div>
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 5">
      <p>Casaco Vintage</p>
    </div>
    <div class="col-md-4">
      <img src="public/img/foto.png" alt="Produto 6">
      <p>Casaco Cinza</p>
    </div>
  </div>

  <!-- Linha depois da última fileira -->
  <hr class="linha-produtos">

</div>





  <!-- Footer -->
<footer class="footer">
  <div class="container">
    <div class="row gy-4">
      
      <!-- Logo + descrição -->
      <div class="col-lg-4 col-md-6 footer-info">
        <a href="index.php" class="logo d-flex align-items-center">
          <img src="public/img/logo.png" alt="Logo">
          <span>Brechó Koꓘero</span>
        </a>
        <p>Sua loja online de roupas, estilo e qualidade. Verde, amarelo e preto para realçar sua identidade.</p>
        <div class="social-links d-flex mt-3">
          <a href="#"><i class="bi bi-twitter"></i></a>
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/brecho.kokero?igsh=aTV4M3YyNmViZXB1"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <!-- Links úteis -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Links</h4>
        <ul>
          <li><a href="#">Início</a></li>
          <li><a href="#">Produtos</a></li>
          <li><a href="#">Categorias</a></li>
          <li><a href="#">Contato</a></li>
        </ul>
      </div>

      <!-- Categorias -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Categorias</h4>
        <ul>
          <li><a href="#">Masculino</a></li>
          <li><a href="#">Feminino</a></li>
          <li><a href="#">Infantil</a></li>
          <li><a href="#">Acessórios</a></li>
        </ul>
      </div>

      <!-- Contato -->
      <div class="col-lg-4 col-md-6 footer-contact">
        <h4>Contato</h4>
        <p>
          Rua Exemplo, 123 <br>
          Cidade - Estado <br>
          Brasil <br><br>
          <strong>Telefone:</strong> (11) 99999-9999<br>
          <strong>Email:</strong> contato@minhaloja.com<br>
        </p>
      </div>

    </div>
  </div>

  <div class="container mt-4">
    <div class="copyright">
      &copy; 2025 <strong><span>Brechó Koꓘero</span></strong>. Todos os direitos reservados.
    </div>
    <div class="credits">
      Desenvolvido com 💛 por <a href="https://vebgtech.talentosdoifsp.gru.br/">VebgTech</a>
    </div>
  </div>
</footer>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

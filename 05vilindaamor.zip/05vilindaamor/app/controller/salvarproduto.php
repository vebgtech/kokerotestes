<?php
include('app/config/conexao.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome = $_POST['nome'];
  $marca = $_POST['marca'];
  $tamanho = $_POST['tamanho'];
  $cor = $_POST['cor'];
  $genero = $_POST['genero'];
  $descricao = $_POST['descricao'];
  $idCategoria = $_POST['idCategoria'];

  $sql = "INSERT INTO produtos (nome, marca, tamanho, cor, genero, descricao, idCategoria) 
          VALUES (?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssssssi", $nome, $marca, $tamanho, $cor, $genero, $descricao, $idCategoria);

  if ($stmt->execute()) {
    header("Location: admin.php");
    exit;
  } else {
    echo "Erro ao salvar produto: " . $conn->error;
  }
}
?>

<?php
// Inicia a sessão
session_start();
// Inclui o arquivo de conexão com o banco de dados
include('../../config/conexao.php');

// Verifica se o usuário está logado como administrador
//if (!isset($_SESSION['admin_logado']) || $_SESSION['admin_logado'] !== true) {
//    header('Location: login.php');
//    exit;
//}

// Processa as ações de atualização de status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';
    
    if ($acao == 'atualizar_status') {
        $idPedido = (int)$_POST['idPedido'];
        $novoStatus = $_POST['status'];
        
        // Atualiza o status do pedido
        $stmt = $conn->prepare("UPDATE pedidos SET status = ?, data_atualizacao = NOW() WHERE id = ?");
        $stmt->bind_param("si", $novoStatus, $idPedido);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Status do pedido atualizado com sucesso!';
            $_SESSION['tipo_mensagem'] = 'success';
        } else {
            $_SESSION['mensagem'] = '❌ Erro ao atualizar status: ' . $stmt->error;
            $_SESSION['tipo_mensagem'] = 'error';
        }
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if ($acao == 'adicionar_pedido') {
        $nomeCliente = trim($_POST['nome_cliente']);
        $telefone = trim($_POST['telefone']);
        $endereco = trim($_POST['endereco']);
        $itens = trim($_POST['itens']);
        $total = (float)$_POST['total'];
        $status_pagamento = $_POST['status_pagamento'];
        $observacoes_pagamento = trim($_POST['observacoes_pagamento'] ?? '');
        $usuario_id = $_POST['usuario_id'] ?? null;
        $usuario_email = $_POST['usuario_email'] ?? '';
        
        // Insere o novo pedido
        $stmt = $conn->prepare("INSERT INTO pedidos (nome_cliente, telefone, endereco, itens, total, status, status_pagamento, observacoes_pagamento, usuario_id, usuario_email, dtpedido) VALUES (?, ?, ?, ?, ?, 'pendente', ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssdssis", $nomeCliente, $telefone, $endereco, $itens, $total, $status_pagamento, $observacoes_pagamento, $usuario_id, $usuario_email);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Pedido adicionado com sucesso!';
            $_SESSION['tipo_mensagem'] = 'success';
        } else {
            $_SESSION['mensagem'] = '❌ Erro ao adicionar pedido: ' . $stmt->error;
            $_SESSION['tipo_mensagem'] = 'error';
        }
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if ($acao == 'atualizar_pagamento') {
        $idPedido = (int)$_POST['idPedido'];
        $status_pagamento = $_POST['status_pagamento'];
        
        $stmt = $conn->prepare("UPDATE pedidos SET status_pagamento = ?, data_atualizacao = NOW() WHERE id = ?");
        $stmt->bind_param("si", $status_pagamento, $idPedido);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Status de pagamento atualizado!';
            $_SESSION['tipo_mensagem'] = 'success';
        }
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    if ($acao == 'adicionar_observacoes') {
        $idPedido = (int)$_POST['idPedido'];
        $observacoes_pagamento = trim($_POST['observacoes_pagamento']);
        
        $stmt = $conn->prepare("UPDATE pedidos SET observacoes_pagamento = ?, data_atualizacao = NOW() WHERE id = ?");
        $stmt->bind_param("si", $observacoes_pagamento, $idPedido);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Observações salvas!';
            $_SESSION['tipo_mensagem'] = 'success';
        }
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    
    if ($acao == 'excluir_pedido') {
        $idPedido = (int)$_POST['idPedido'];
        
        $stmt = $conn->prepare("DELETE FROM pedidos WHERE id = ?");
        $stmt->bind_param("i", $idPedido);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Pedido excluído com sucesso!';
            $_SESSION['tipo_mensagem'] = 'success';
        }
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Verifica e cria a tabela se necessário
$checkTable = $conn->query("SHOW TABLES LIKE 'pedidos'");

if ($checkTable->num_rows == 0) {
    // Cria a tabela se não existir
    $createTable = "CREATE TABLE pedidos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nome_cliente VARCHAR(255) NOT NULL,
        telefone VARCHAR(20),
        endereco TEXT,
        itens TEXT,
        total DECIMAL(10,2),
        status ENUM('pendente', 'confirmado', 'enviado', 'entregue') DEFAULT 'pendente',
        status_pagamento ENUM('pendente', 'confirmado', 'parcial', 'cancelado') DEFAULT 'pendente',
        observacoes_pagamento TEXT NULL,
        usuario_id INT NULL,
        usuario_email VARCHAR(255) NULL,
        data_pedido DATETIME DEFAULT CURRENT_TIMESTAMP,
        data_atualizacao DATETIME NULL
    )";
    
    if ($conn->query($createTable)) {
        // Insere alguns pedidos de exemplo
        $exemplos = [
            ["Maria Silva", "(11) 99999-1234", "Rua das Flores, 123 - Centro - São Paulo/SP", "Vestido Vermelho (R$ 89,90), Blusa de Seda (R$ 59,90)", 149.80, 1, "maria@email.com"],
            ["João Santos", "(11) 98888-5678", "Av. Paulista, 1000 - Bela Vista - São Paulo/SP", "Calça Jeans (R$ 79,90), Camisa Social (R$ 69,90)", 149.80, null, ""],
            ["Ana Oliveira", "(11) 97777-9012", "Rua Augusta, 500 - Consolação - São Paulo/SP", "Saia Plissada (R$ 65,00), Blazer (R$ 120,00)", 185.00, 2, "ana.oliveira@email.com"]
        ];
        
        foreach ($exemplos as $exemplo) {
            $stmt = $conn->prepare("INSERT INTO pedidos (nome_cliente, telefone, endereco, itens, total, status, usuario_id, usuario_email, data_pedido) VALUES (?, ?, ?, ?, ?, 'pendente', ?, ?, NOW() - INTERVAL FLOOR(RAND() * 7) DAY)");
            $stmt->bind_param("ssssdis", $exemplo[0], $exemplo[1], $exemplo[2], $exemplo[3], $exemplo[4], $exemplo[5], $exemplo[6]);
            $stmt->execute();
            $stmt->close();
        }
    }
} else {
    // Tabela existe, verifica e adiciona colunas faltantes
    $addColumns = [
        "ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS status_pagamento ENUM('pendente', 'confirmado', 'parcial', 'cancelado') DEFAULT 'pendente'",
        "ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS observacoes_pagamento TEXT NULL",
        "ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS usuario_id INT NULL",
        "ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS usuario_email VARCHAR(255) NULL",
        "ALTER TABLE pedidos ADD COLUMN IF NOT EXISTS data_atualizacao DATETIME NULL"
    ];
    
    foreach ($addColumns as $sql) {
        $conn->query($sql);
    }
}

// Busca os pedidos do banco de dados
$query = "SELECT * FROM pedidos ORDER BY idPedido DESC";

$pedidos = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Últimos Pedidos | Painel Administrativo</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../../../public/css/estilo.css">
    
</head>
<body>
    <!-- ===========================
         CABEÇALHO DO PAINEL ADMIN
    =========================== -->
    <header class="admin-header">
        <div class="container">
            <h2><i class="bi bi-speedometer2"></i> Painel do Administrador</h2>
            <p>Gerencie pedidos e acompanhe o status das vendas</p>
        </div>
    </header>

    <!-- ===========================
         NAVBAR SIMPLIFICADA
    =========================== -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="adminNavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="bi bi-house me-1"></i> Início
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="faq.php">
                            <i class="bi bi-question-circle me-1"></i> FAQ
                        </a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-tags-fill me-1"></i> Produtos
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="../produtos.php">Todos os Produtos</a></li>
                            <li><a class="dropdown-item" href="produtos.php">Gerenciar Produtos</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link active" href="ultimospedidos.php">
                            <i class="bi bi-cart-check-fill me-1"></i> Últimos pedidos
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- ===========================
         CONTEÚDO PRINCIPAL
    =========================== -->
    <div class="container my-5">
        <!-- SEÇÃO: TÍTULO E FILTROS -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="section-header">
                <h4><i class="bi bi-cart-check-fill"></i> Últimos Pedidos</h4>
                <p class="text-muted">Total de <?= $pedidos->num_rows ?> pedido(s) encontrado(s)</p>
            </div>
            <div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdicionarPedido">
                    <i class="bi bi-plus-circle"></i> Adicionar Pedido
                </button>
            </div>
        </div>

        <!-- ALERTAS DE MENSAGENS -->
        <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert alert-<?= $_SESSION['tipo_mensagem'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                <?= $_SESSION['mensagem'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
            // Limpa a mensagem após exibir
            unset($_SESSION['mensagem']);
            unset($_SESSION['tipo_mensagem']);
            ?>
        <?php endif; ?>

        <!-- FILTROS DE STATUS -->
        <div class="card p-3 mb-4">
            <div class="row g-2">
                <div class="col-md-3">
                    <label class="form-label">Filtrar por Status</label>
                    <select class="form-select" id="filtroStatus">
                        <option value="todos">Todos os Status</option>
                        <option value="pendente">Pendente</option>
                        <option value="confirmado">Confirmado</option>
                        <option value="enviado">Enviado</option>
                        <option value="entregue">Entregue</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tipo de Cliente</label>
                    <select class="form-select" id="filtroCliente">
                        <option value="todos">Todos os clientes</option>
                        <option value="cadastrado">Clientes cadastrados</option>
                        <option value="nao_cadastrado">Clientes não cadastrados</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Período</label>
                    <select class="form-select" id="filtroPeriodo">
                        <option value="todos">Todos os períodos</option>
                        <option value="hoje">Hoje</option>
                        <option value="semana">Esta semana</option>
                        <option value="mes">Este mês</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="button" class="btn btn-secondary me-2" id="aplicarFiltros">
                        Aplicar Filtros
                    </button>
                    <button type="button" class="btn btn-outline-secondary" id="limparFiltros">
                        Limpar Filtros
                    </button>
                </div>
            </div>
        </div>

        <!-- LISTA DE PEDIDOS -->
        <div class="row" id="listaPedidos">
            <?php if ($pedidos && $pedidos->num_rows > 0): ?>
                <?php while($pedido = $pedidos->fetch_assoc()): ?>
                    <?php 
                    // Determina a data do pedido para exibição
                    $dataPedido = isset($pedido['data_pedido']) ? $pedido['data_pedido'] : (isset($pedido['dtPedido']) ? $pedido['dtPedido'] : '');
                    $isClienteCadastrado = !empty($pedido['usuario_id']);
                    ?>
                    <div class="col-md-6 col-lg-4 mb-4 pedido-item" 
                         data-status="<?= $pedido['status'] ?>" 
                         data-data="<?= date('Y-m-d', strtotime($dataPedido)) ?>"
                         data-cliente="<?= $isClienteCadastrado ? 'cadastrado' : 'nao_cadastrado' ?>">
                        <div class="card h-100 pedido-card <?= $pedido['status'] ?> <?= $isClienteCadastrado ? 'cliente-cadastrado' : '' ?>">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <small class="text-muted">#<?= str_pad($pedido['id'], 4, '0', STR_PAD_LEFT) ?></small>
                                <div class="d-flex gap-1">
                                    <?php if ($isClienteCadastrado): ?>
                                        <span class="status-badge bg-success text-white" title="Cliente cadastrado">
                                            <i class="bi bi-person-check"></i>
                                        </span>
                                    <?php endif; ?>
                                    <span class="status-badge status-<?= $pedido['status_pagamento'] ?? 'pendente' ?>">
                                        <?= ucfirst($pedido['status_pagamento'] ?? 'pendente') ?>
                                    </span>
                                    <span class="status-badge status-<?= $pedido['status'] ?>">
                                        <?= ucfirst($pedido['status']) ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-body">
                                <h6 class="card-title"><?= htmlspecialchars($pedido['nome_cliente']) ?></h6>
                                <p class="card-text">
                                    <small class="text-muted">
                                        <i class="bi bi-telephone"></i> <?= htmlspecialchars($pedido['telefone']) ?><br>
                                        <i class="bi bi-calendar"></i> <?= date('d/m/Y H:i', strtotime($dataPedido)) ?>
                                    </small>
                                </p>
                                
                                <!-- INFORMAÇÕES DO USUÁRIO CADASTRADO -->
                                <?php if ($isClienteCadastrado): ?>
                                    <div class="alert alert-success py-2 mt-2">
                                        <small>
                                            <i class="bi bi-person-check"></i> <strong>Cliente cadastrado</strong><br>
                                            ID: <?= $pedido['usuario_id'] ?><br>
                                            Email: <?= htmlspecialchars($pedido['usuario_email']) ?>
                                        </small>
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-secondary py-2 mt-2">
                                        <small>
                                            <i class="bi bi-person"></i> <strong>Cliente não cadastrado</strong><br>
                                            Compra realizada sem cadastro
                                        </small>
                                    </div>
                                <?php endif; ?>
                                
                                <p class="card-text"><strong>Itens:</strong><br><?= nl2br(htmlspecialchars($pedido['itens'])) ?></p>
                                <p class="card-text"><strong>Endereço:</strong><br><?= nl2br(htmlspecialchars($pedido['endereco'])) ?></p>
                                <p class="card-text"><strong>Total:</strong> R$ <?= number_format($pedido['total'], 2, ',', '.') ?></p>
                                
                                <!-- SEÇÃO DE PAGAMENTO -->
                                <?php if (!empty($pedido['observacoes_pagamento'])): ?>
                                    <div class="alert alert-info py-2 mt-2">
                                        <small><strong>Observações:</strong> <?= htmlspecialchars($pedido['observacoes_pagamento']) ?></small>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card-footer bg-transparent">
                                <div class="d-flex justify-content-between align-items-center">
                                    <a href="https://wa.me/55<?= preg_replace('/[^0-9]/', '', $pedido['telefone']) ?>?text=Olá <?= urlencode($pedido['nome_cliente']) ?>, tudo bem? Aqui é do Brechó Kokero! ✨" 
                                       class="btn btn-sm whatsapp-link" target="_blank" title="Enviar mensagem no WhatsApp">
                                        <i class="bi bi-whatsapp"></i>
                                    </a>
                                    
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Ações
                                        </button>
                                        <ul class="dropdown-menu">
                                            <!-- CONTROLE DE PAGAMENTO -->
                                            <li><h6 class="dropdown-header">Controle de Pagamento</h6></li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_pagamento">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status_pagamento" value="confirmado">
                                                    <button type="submit" class="dropdown-item text-success">
                                                        <i class="bi bi-check-circle"></i> Marcar como Pago
                                                    </button>
                                                </form>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_pagamento">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status_pagamento" value="parcial">
                                                    <button type="submit" class="dropdown-item text-warning">
                                                        <i class="bi bi-currency-dollar"></i> Pagamento Parcial
                                                    </button>
                                                </form>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_pagamento">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status_pagamento" value="pendente">
                                                    <button type="submit" class="dropdown-item text-secondary">
                                                        <i class="bi bi-clock"></i> Pendente
                                                    </button>
                                                </form>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_pagamento">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status_pagamento" value="cancelado">
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        <i class="bi bi-x-circle"></i> Não Pago
                                                    </button>
                                                </form>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            
                                            <!-- CONTROLE DE ENTREGA -->
                                            <li><h6 class="dropdown-header">Controle de Entrega</h6></li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_status">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status" value="confirmado">
                                                    <button type="submit" class="dropdown-item">Confirmar Pedido</button>
                                                </form>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_status">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status" value="enviado">
                                                    <button type="submit" class="dropdown-item">Marcar como Enviado</button>
                                                </form>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="acao" value="atualizar_status">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <input type="hidden" name="status" value="entregue">
                                                    <button type="submit" class="dropdown-item">Marcar como Entregue</button>
                                                </form>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <button type="button" class="dropdown-item text-info" data-bs-toggle="modal" data-bs-target="#modalObservacoes<?= $pedido['id'] ?>">
                                                    <i class="bi bi-pencil"></i> Adicionar Observações
                                                </button>
                                            </li>
                                            <li>
                                                <form method="POST" class="d-inline" onsubmit="return confirm('Tem certeza que deseja excluir este pedido?')">
                                                    <input type="hidden" name="acao" value="excluir_pedido">
                                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        <i class="bi bi-trash"></i> Excluir Pedido
                                                    </button>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- MODAL PARA OBSERVAÇÕES -->
                    <div class="modal fade" id="modalObservacoes<?= $pedido['id'] ?>" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Observações do Pedido #<?= str_pad($pedido['id'], 4, '0', STR_PAD_LEFT) ?></h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form method="POST">
                                    <input type="hidden" name="acao" value="adicionar_observacoes">
                                    <input type="hidden" name="idPedido" value="<?= $pedido['id'] ?>">
                                    <div class="modal-body">
                                        <textarea name="observacoes_pagamento" class="form-control" rows="4" placeholder="Digite observações sobre o pagamento..."><?= htmlspecialchars($pedido['observacoes_pagamento'] ?? '') ?></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary">Salvar Observações</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="bi bi-info-circle"></i> Nenhum pedido encontrado.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- MODAL: ADICIONAR NOVO PEDIDO -->
    <div class="modal fade" id="modalAdicionarPedido" tabindex="-1" aria-labelledby="modalAdicionarPedidoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalAdicionarPedidoLabel">
                        <i class="bi bi-plus-circle"></i> Adicionar Novo Pedido
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="formAdicionarPedido">
                    <input type="hidden" name="acao" value="adicionar_pedido">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nome do Cliente</label>
                                <input type="text" name="nome_cliente" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Telefone (WhatsApp)</label>
                                <input type="text" name="telefone" class="form-control" placeholder="(11) 99999-9999" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Endereço Completo</label>
                                <textarea name="endereco" class="form-control" rows="3" required></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Itens do Pedido</label>
                                <textarea name="itens" class="form-control" rows="4" placeholder="Ex: Vestido Vermelho (R$ 89,90)&#10;Blusa de Seda (R$ 59,90)" required></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Valor Total (R$)</label>
                                <input type="number" step="0.01" name="total" class="form-control" min="0" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Status do Pagamento</label>
                                <select name="status_pagamento" class="form-select" required>
                                    <option value="pendente">Pendente</option>
                                    <option value="confirmado">Pago/Confirmado</option>
                                    <option value="parcial">Pago Parcialmente</option>
                                    <option value="cancelado">Não Pago/Cancelado</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">ID do Usuário (opcional)</label>
                                <input type="number" name="usuario_id" class="form-control" placeholder="ID do usuário cadastrado">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email do Usuário (opcional)</label>
                                <input type="email" name="usuario_email" class="form-control" placeholder="Email do usuário cadastrado">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Observações do Pagamento</label>
                                <textarea name="observacoes_pagamento" class="form-control" rows="2" placeholder="Ex: Pago via PIX, Aguardando confirmação..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Adicionar Pedido</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ====================== FOOTER ====================== -->
    <footer class="footer bg-dark text-light mt-5 py-4">
        <div class="container">
            <div class="row gy-4">
                <!-- ... (footer mantido igual) ... -->
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="../../../public/js/script.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Filtros para pedidos
    document.addEventListener('DOMContentLoaded', function() {
        const aplicarFiltros = document.getElementById('aplicarFiltros');
        const limparFiltros = document.getElementById('limparFiltros');
        
        if (aplicarFiltros) {
            aplicarFiltros.addEventListener('click', function() {
                const filtroStatus = document.getElementById('filtroStatus').value;
                const filtroCliente = document.getElementById('filtroCliente').value;
                const filtroPeriodo = document.getElementById('filtroPeriodo').value;
                
                const pedidos = document.querySelectorAll('.pedido-item');
                
                pedidos.forEach(pedido => {
                    let mostrar = true;
                    
                    // Filtro por status
                    if (filtroStatus !== 'todos' && pedido.dataset.status !== filtroStatus) {
                        mostrar = false;
                    }
                    
                    // Filtro por tipo de cliente
                    if (filtroCliente !== 'todos' && pedido.dataset.cliente !== filtroCliente) {
                        mostrar = false;
                    }
                    
                    // Filtro por período (implementação básica)
                    if (filtroPeriodo !== 'todos') {
                        const dataPedido = new Date(pedido.dataset.data);
                        const hoje = new Date();
                        
                        if (filtroPeriodo === 'hoje' && dataPedido.toDateString() !== hoje.toDateString()) {
                            mostrar = false;
                        } else if (filtroPeriodo === 'semana') {
                            const umaSemanaAtras = new Date(hoje.setDate(hoje.getDate() - 7));
                            if (dataPedido < umaSemanaAtras) {
                                mostrar = false;
                            }
                        } else if (filtroPeriodo === 'mes') {
                            const umMesAtras = new Date(hoje.setMonth(hoje.getMonth() - 1));
                            if (dataPedido < umMesAtras) {
                                mostrar = false;
                            }
                        }
                    }
                    
                    pedido.style.display = mostrar ? 'block' : 'none';
                });
            });
        }
        
        if (limparFiltros) {
            limparFiltros.addEventListener('click', function() {
                document.getElementById('filtroStatus').value = 'todos';
                document.getElementById('filtroCliente').value = 'todos';
                document.getElementById('filtroPeriodo').value = 'todos';
                
                const pedidos = document.querySelectorAll('.pedido-item');
                pedidos.forEach(pedido => {
                    pedido.style.display = 'block';
                });
            });
        }
    });
    </script>
</body>
</html>
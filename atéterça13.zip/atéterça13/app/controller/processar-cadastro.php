<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
// Conectar ao banco de dados
require_once "../config/conexao.php";

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Obter os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Validar os campos
    if (empty($nome) || empty($email) || empty($senha)) {
        header("Location: ../view/cadastre.php?erro=campos_vazios");
        exit();
    }

    // VERIFICAR SE O EMAIL JÁ EXISTE
    $stmt_check = $conn->prepare("SELECT nome FROM usuarios WHERE email = ?");
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // Email já cadastrado
        $stmt_check->close();
        header("Location: ../view/cadastre.php?erro=email_ja_cadastrado");
        exit();
    }
    $stmt_check->close();

    // Hash da senha para segurança
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Definir o nível de usuário como 'Cliente' (idNivelUsuario = 1)
    $idNivelUsuario = 1;

    // Preparar a consulta para inserir o usuário
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, idNivelUsuario) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $nome, $email, $senhaHash, $idNivelUsuario);

    // Executar a consulta
    if ($stmt->execute()) {
        // Redirecionar para página de login com mensagem de sucesso
        header("Location: ../view/log.php?cadastro_sucesso=true");
        exit();
    } else {
        header("Location: ../view/cadastre.php?erro=erro_banco_dados");
        exit();
    }

    $stmt->close();
    $conn->close();
}

?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Conectar ao banco de dados
require_once "../config/conexao.php"; // Arquivo de conexão com o banco

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Obter os dados do formulário
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    
    // Validar se os campos não estão vazios
    if (empty($email) || empty($senha)) {
        header("Location: ../view/log.php?erro=campos_vazios");
        exit();
    }

    // Preparar a consulta para buscar o usuário com o email informado
    $stmt = $conn->prepare("SELECT nome, senha FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Verificar se o usuário existe
    if ($stmt->num_rows == 1) {
        // O usuário existe, então vamos buscar os dados dele
        $stmt->bind_result($nome, $senhaHash);
        $stmt->fetch();

        // Verificar se a senha informada é a mesma que o hash armazenado no banco de dados
        if (password_verify($senha, $senhaHash)) {
            // A senha está correta, podemos fazer o login
            session_start();  // Inicia a sessão

            // Armazenar os dados do usuário na sessão
            $_SESSION["usuario"] = true;
            $_SESSION["nome"] = $nome;
            $_SESSION["email"] = $email;

            // Redirecionar para a página após o login
            header("Location: ../view/minha_conta.php?login_sucesso=true");
            exit();
        } else {
            // A senha não é válida
            header("Location: ../view/log.php?erro=senha_invalida");
            exit();
        }
        
    } else {
        // O email não foi encontrado no banco de dados
        header("Location: ../view/log.php?erro=email_nao_encontrado");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
document.addEventListener('DOMContentLoaded', function () {
    // Apenas para telas mobile (onde o hover não funciona)
    if (window.innerWidth < 992) {
        document.querySelectorAll('.dropdown-submenu a.dropdown-toggle').forEach(function (element) {
            element.addEventListener('click', function (e) {
                // Impede que o link seja seguido e que o menu principal feche
                e.preventDefault();
                e.stopPropagation();
                
                let parentMenu = this.closest('.dropdown-menu');
                
                // Fecha outros submenus que possam estar abertos no mesmo nível
                parentMenu.querySelectorAll('.dropdown-submenu .dropdown-menu.show').forEach(function(openSubmenu) {
                    if (openSubmenu !== this.nextElementSibling) {
                        openSubmenu.classList.remove('show');
                    }
                });
                
                // Abre ou fecha o submenu atual
                this.nextElementSibling.classList.toggle('show');
            });
        });
    }
});











// ======================================================
//  LÓGICA PARA NAVEGAÇÃO ATIVA NA PÁGINA FAQ
// ======================================================
document.addEventListener('DOMContentLoaded', () => {
    // Só executa se encontrar os elementos da página FAQ
    const faqNav = document.querySelector('.faq-nav');
    if (faqNav) {
        const navLinks = document.querySelectorAll('.faq-nav a');
        const sections = document.querySelectorAll('.faq-item');

        const observerOptions = {
            root: null, // Observa em relação ao viewport
            rootMargin: '0px',
            threshold: 0.4  // A seção precisa estar 40% visível
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Remove a classe 'active' de todos os links
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                    });

                    // Adiciona a classe 'active' ao link correspondente
                    const activeLink = document.querySelector(`.faq-nav a[href="#${entry.target.id}"]`);
                    if (activeLink) {
                        activeLink.classList.add('active');
                    }
                }
            });
        }, observerOptions);

        // Observa cada seção
        sections.forEach(section => {
            observer.observe(section);
        });
    }
});
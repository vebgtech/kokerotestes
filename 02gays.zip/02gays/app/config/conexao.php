<?php
$servidor = "localhost";
$usuario = "root";
$senha = "senha";
$banco = "brechokokero";

//criar a coneção
$conn = new mysqli($servidor, $usuario, $senha, $banco);

//caso não conecte
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
?>
<?php
require_once "conexao.php";
// Obter os dados do formulário
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];
$telefone = $_POST ["telefone"];



// Inserir os dados na tabela 'usuario'
$sql = "INSERT INTO usuario (nome, email, senha, telefone) VALUES 
('$nome', '$email', '$senha', '$telefone')";

if ($conn->query($sql) === TRUE) {
    header("Location: ../cad-log.php");
    exit();
} else {
    echo "Erro ao cadastrar o usuário: " . $conn->error;
}

$conn->close();
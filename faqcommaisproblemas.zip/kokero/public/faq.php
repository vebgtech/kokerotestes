<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - Brechó Kokero</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<header>
    <div class="header-main-bar">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            
            <button class="navbar-toggler d-lg-none menu-toggle-btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand flex-grow-1 flex-lg-grow-0 text-center text-lg-start" href="index.php">
              <img src="public/img/logo.png" alt="Logo Brechó Kokero">
            </a>
            
            <form class="search-form flex-grow-1 mx-4 d-none d-lg-flex" role="search">
                <input class="form-control" type="search" placeholder="Buscar produtos..." aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>

            <a class="cart-link" href="#">
                <i class="bi bi-cart-fill" style="font-size: 1.5rem;"></i>
                <span class="badge rounded-pill">0</span>
            </a>
        </div>
    </div>

    <div class="header-search-mobile d-lg-none">
        <div class="container-fluid py-2">
            <form class="search-form" role="search">
                <input class="form-control" type="search" placeholder="Buscar produtos..." aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg header-nav-bar">
      <div class="container-fluid justify-content-center">
        <div class="collapse navbar-collapse flex-grow-0" id="navbarContent">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="index.php"><i class="bi bi-house-door-fill me-1"></i> Início</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-tags-fill me-1"></i> Produtos
              </a>
              <ul class="dropdown-menu">
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Feminino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Vestidos</a></li>
                    <li><a class="dropdown-item" href="#">Blusas</a></li>
                    <li><a class="dropdown-item" href="#">Saias</a></li>
                  </ul>
                </li>
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Masculino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Camisas</a></li>
                    <li><a class="dropdown-item" href="#">Calças</a></li>
                    <li><a class="dropdown-item" href="#">Jaquetas</a></li>
                  </ul>
                </li>
                <li><hr class="dropdown-divider" style="border-color: #2b5e1d;"></li>
                <li><a class="dropdown-item" href="#">Todos os Produtos</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-fill me-1"></i> Minha Conta
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#">Login</a></li>
                <li><a class="dropdown-item" href="#">Não tem conta? Cadastre-se</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
</header>


<main class="container my-5">
    <div class="text-center mb-5">
        <h1 class="faq-main-title">TIRE SUAS DÚVIDAS SOBRE</h1>
    </div>

    <nav class="faq-nav-buttons">
        <a href="#sobre" class="btn-faq">Sobre os Produtos</a>
        <a href="#compra" class="btn-faq">Compra e Pagamento</a>
        <a href="#envio" class="btn-faq">Envio e Entrega</a>
        <a href="#trocas" class="btn-faq">Trocas e Devoluções</a>
        <a href="#tamanhos" class="btn-faq">Tamanhos e Medidas</a>
        <a href="#loja" class="btn-faq">Loja Física</a>
        <a href="#contato" class="btn-faq">Suporte e Contato</a>
    </nav>

    <div class="content-faq">
        <section id="sobre" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Sobre os Produtos</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>Os produtos são originais?</h3>
            <p>Sim! Trabalhamos exclusivamente com produtos 100% originais, garantindo autenticidade e qualidade em cada peça.</p>
            <h3>Os produtos são novos ou usados?</h3>
            <p>Nossa curadoria é composta por itens vintage e seminovos, todos cuidadosamente selecionados e higienizados antes de serem disponibilizados para venda.</p>
            <h3>As peças apresentam sinais de uso?</h3>
            <p>Por serem vintage, algumas peças podem apresentar leves marcas do tempo, o que faz parte da história e autenticidade de cada item. Caso haja algum detalhe relevante (manchas, furos, desgastes), ele será informado na descrição do produto e ilustrado nas fotos.</p>
        </section>
        
        <section id="compra" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Compra e Pagamento</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>Posso comprar diretamente pelo WhatsApp?</h3>
            <p>Sim. Todas as compras são feitas exclusivamente pelo nosso whatsapp.</p>
            <h3>Quais são as formas de pagamento?</h3>
            <p>Aceitamos somente Pix, proporcionando praticidade e segurança na sua compra.</p>
        </section>
        
        <section id="envio" class="faq-item">
             <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Envio e Entrega</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>Vocês fazem entrega em estações de metrô/trem?</h3>
            <p>Não fazemos entregas pessoais. Todas as entregas são realizadas exclusivamente via transportadora para garantir maior segurança e rastreamento.</p>
            <h3>Como calcular o frete e prazo de entrega?</h3>
            <p>Para calcular o frete e prazo de entrega, basta selecionar o produto desejado e inserir seu CEP no campo correspondente.</p>
        </section>

        <section id="trocas" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Trocas e Devoluções</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>Nao seii oo</h3>
            <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
            <h3>Nao seii oo</h3>
            <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
        </section>

        <section id="tamanhos" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Tamanhos e Medidas</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>O tamanho informado na etiqueta é confiável?</h3>
            <p>Nem sempre! Como trabalhamos com diferentes marcas e épocas, os tamanhos podem variar. Por isso, informamos todas as dimensões reais na descrição do produto.</p>
        </section>

         <section id="loja" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Loja Física</h2>
                <hr class="flex-grow-1">
            </div>
            <h3>Vocês possuem loja física?</h3>
            <p>Não temos uma loja física. Todas as compras são feitas via WhatsApp.</p>
        </section>

        <section id="contato" class="faq-item">
            <div class="section-title-container">
                <hr class="flex-grow-1">
                <h2 class="mx-3">Suporte e Contato</h2>
                <hr class="flex-grow-1">
            </div>
            <p>Se ainda tiver dúvidas, nossa equipe está sempre pronta para te ajudar! Entre em contato por:</p>
            <p><strong>WhatsApp:</strong> <a href="tel:+5511992424158" class="contact-link">+55 11 99242-4158</a></p>
            <p><strong>Instagram:</strong> <a href="https://instagram.com/brecho.kokero" target="_blank" class="contact-link">@brecho.kokero</a></p>
        </section>
    </div>
</main>


<footer class="footer">
  <div class="container">
    <div class="row gy-4">
      
      <div class="col-lg-4 col-md-6 footer-info">
        <a href="index.html" class="logo d-flex align-items-center">
          <img src="public/img/logo.png" alt="Logo">
          <span>Brechó Koꓘero</span>
        </a>
        <p>Sua loja online de roupas, estilo e qualidade. Verde, amarelo e preto para realçar sua identidade.</p>
        <div class="social-links d-flex mt-3">
          <a href="#"><i class="bi bi-twitter"></i></a>
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/brecho.kokero?igsh=aTV4M3YyNmViZXB1"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Links</h4>
        <ul>
          <li><a href="#">Início</a></li>
          <li><a href="#">Produtos</a></li>
          <li><a href="#">Categorias</a></li>
          <li><a href="#">Contato</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Categorias</h4>
        <ul>
          <li><a href="#">Masculino</a></li>
          <li><a href="#">Feminino</a></li>
          <li><a href="#">Infantil</a></li>
          <li><a href="#">Acessórios</a></li>
        </ul>
      </div>

      <div class="col-lg-4 col-md-6 footer-contact">
        <h4>Contato</h4>
        <p>
          Rua Exemplo, 123 <br>
          Cidade - Estado <br>
          Brasil <br><br>
          <strong>Telefone:</strong> (11) 99999-9999<br>
          <strong>Email:</strong> contato@minhaloja.com<br>
        </p>
      </div>

    </div>
  </div>

  <div class="container mt-4">
    <div class="copyright">
      &copy; 2025 <strong><span>Brechó Koꓘero</span></strong>. Todos os direitos reservados.
    </div>
    <div class="credits">
      Desenvolvido com 💛 por <a href="https://vebgtech.talentosdoifsp.gru.br/">VebgTech</a>
    </div>
  </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
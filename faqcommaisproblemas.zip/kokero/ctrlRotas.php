<?php

$uri = $_GET["uri"] ?? '';

ob_clean();
error_reporting(E_ALL);
ini_set('display_errors', 1);


$routes = [
    'index'     => [ 'path'=> 'public/index.php', 	     'login'=>false, 'nivelAcesso'=>0 ],
    'main'      => [ 'path'=> 'app/view/main.php',       'login'=>true,  'nivelAcesso'=>1 ],
    'homeAdmin' => [ 'path'=> 'app/view/homeAdmin.php',  'login'=>true,  'nivelAcesso'=>5 ]
];


if ($uri === '' or $uri === 'index.php' or $uri === '/' or $uri === 'início')//adicionei 3 termos
{
	getFile ( 'public/index.php' );
} else{
	if (str_starts_with($uri, "public/")) {
		getFile($uri);
	} else {
		if ( array_key_exists ( $uri, $routes )) {
			$route = $routes[$uri];
			if ( $route['login'] == true ){
				session_start();
				if( $route['nivelAcesso'] == $_SESSION['nivelAcesso']){
					getFile($routes[$uri]['path']);
				}else{
					die("Error 404 - Not Found");
				}
			}else{
				getFile($routes[$uri]['path']);
			}
		}
	}
}
function getFile(string $uri): void {
	$filePath = $uri;
	if (file_exists ( $filePath )) {
		$extensao = pathinfo ( $filePath, PATHINFO_EXTENSION );
		$tiposInterpretados = ['html','php','css','js','json','xml','txt'];
		if (in_array ( $extensao, $tiposInterpretados )) { // tipos interpretados : html, php, css, js, json, xml, txt
			require $filePath;
		} else { // tipos binários : imagens, vídeos, áudios, etc.
			$mimeType = mime_content_type ( $filePath ); // Obtém o tipo MIME do arquivo
			header ( "Content-Type: $mimeType" ); // Define o tipo MIME correto
			readfile ( $filePath ); // Lê o conteúdo do arquivo e envia o arquivo diretamente
		}
		exit (); // Certifica-se de que o script termina após servir o arquivo
	} else {
		http_response_code ( 404 );
		require 'public/404.php';
		exit (); // Certifica-se de que o script termina após servir o arquivo
	}
}
?>

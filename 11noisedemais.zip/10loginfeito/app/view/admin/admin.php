<?php
// Inclui o arquivo de conexão com o banco de dados
include('../../config/conexao.php');

$categorias = $conn->query("SELECT idCategoria, descricao FROM categorias ORDER BY idCategoria");

// Se não houver categorias, usar as padrão
if ($categorias->num_rows == 0) {
    // Criar array com categorias padrão
    $categorias_data = [
        ['idCategoria' => 1, 'descricao' => 'Bermudas e Shorts'],
        ['idCategoria' => 2, 'descricao' => 'Blazers'],
        ['idCategoria' => 3, 'descricao' => 'Blusas e Camisas'],
        ['idCategoria' => 4, 'descricao' => 'Calças'],
        ['idCategoria' => 5, 'descricao' => 'Casacos e Jaquetas'],
        ['idCategoria' => 6, 'descricao' => 'Conjuntos'],
        ['idCategoria' => 7, 'descricao' => 'Saias'],
        ['idCategoria' => 8, 'descricao' => 'Sapatos'],
        ['idCategoria' => 9, 'descricao' => 'Social'],
        ['idCategoria' => 10, 'descricao' => 'Vestidos']
    ];
} else {
    // Usar categorias do banco
    $categorias_data = [];
    while($cat = $categorias->fetch_assoc()) {
        $categorias_data[] = $cat;
    }
}

/**
 * PROCESSAMENTO DAS AÇÕES VIA POST
 * Manipula as operações CRUD: adicionar, editar, excluir e vender produtos
 */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? ''; // Obtém a ação a ser executada

    // AÇÃO: ADICIONAR NOVO PRODUTO
    if ($acao == 'adicionar') {
        // Coleta e sanitiza os dados do formulário
        $nome = trim($_POST['nome']);
        $marca = trim($_POST['marca'] ?? '');
        $tamanho = trim($_POST['tamanho'] ?? '');
        $idCategoria = (int)$_POST['idCategoria'];
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = (float)$_POST['preco'];
        $promocao = isset($_POST['promocao']) ? 1 : 0; // Converte checkbox para booleano
        $estoque = isset($_POST['tem_estoque']) ? max(1, (int)$_POST['estoque']) : 1; // Mínimo 1 item
        $estado = trim($_POST['estado']);
        $imagem = 'default.jpg'; // Imagem padrão

        // PROCESSAMENTO DE UPLOAD DE IMAGEM
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $target_dir = "../../../public/img/";
            // Cria diretório se não existir
            if (!is_dir($target_dir)) { 
                mkdir($target_dir, 0775, true); 
            }
            
            // Valida extensão e tamanho do arquivo
            $file_extension = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif']) && $_FILES['imagem']['size'] <= 5000000) {
                // Gera nome único para o arquivo
                $novo_nome = 'produto_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
                $target_file = $target_dir . $novo_nome;
                
                // Move arquivo para o diretório
                if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target_file)) {
                    $imagem = $novo_nome;
                } else {
                    error_log("Falha no upload: " . $target_file);
                }
            } else {
                error_log("Arquivo inválido: " . $_FILES['imagem']['name']);
            }
        }

        // INSERÇÃO NO BANCO DE DADOS
        $stmt = $conn->prepare("INSERT INTO produtos (nome, marca, tamanho, idCategoria, descricao, preco, promocao, imagem, estoque, estado, vendido, data_venda) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, NULL)");
        $stmt->bind_param('sssisdssis', $nome, $marca, $tamanho, $idCategoria, $descricao, $preco, $promocao, $imagem, $estoque, $estado);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = '✅ Produto cadastrado com sucesso!';
            $_SESSION['tipo_mensagem'] = 'success';
        } else {
            $_SESSION['mensagem'] = '❌ Erro ao cadastrar produto: ' . $stmt->error;
            $_SESSION['tipo_mensagem'] = 'error';
        }
        $stmt->close();

    }

    // AÇÃO: EDITAR PRODUTO EXISTENTE
    if ($acao == 'editar') {
        // Coleta dados do formulário (similar ao adicionar)
        $idProduto = (int)$_POST['idProduto'];
        $nome = trim($_POST['nome']);
        $marca = trim($_POST['marca'] ?? '');
        $tamanho = trim($_POST['tamanho'] ?? '');
        $idCategoria = (int)$_POST['idCategoria'];
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = (float)$_POST['preco'];
        $promocao = isset($_POST['promocao']) ? 1 : 0;
        $estoque = isset($_POST['tem_estoque']) ? max(1, (int)$_POST['estoque']) : 1;
        $estado = trim($_POST['estado']);
        $imagem_atual = $_POST['imagem_atual'] ?? 'default.jpg';

        // UPLOAD DE NOVA IMAGEM (opcional)
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $target_dir = "../../../public/img/";
            if (!is_dir($target_dir)) { 
                mkdir($target_dir, 0775, true); 
            }
            $file_extension = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif']) && $_FILES['imagem']['size'] <= 5000000) {
                $novo_nome = 'produto_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
                $target_file = $target_dir . $novo_nome;
                if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target_file)) {
                    // Remove imagem antiga se não for a padrão
                    if ($imagem_atual != 'default.jpg' && file_exists($target_dir . $imagem_atual)) {
                        unlink($target_dir . $imagem_atual);
                    }
                    $imagem_atual = $novo_nome;
                } else {
                    error_log("Falha no upload de edição: " . $target_file);
                }
            }
        }

        // ATUALIZAÇÃO NO BANCO DE DADOS
        $stmt = $conn->prepare("UPDATE produtos SET nome=?, marca=?, tamanho=?, idCategoria=?, descricao=?, preco=?, promocao=?, imagem=?, estoque=?, estado=? WHERE idProduto=? AND vendido=0");
        $stmt->bind_param('sssisdssisi', $nome, $marca, $tamanho, $idCategoria, $descricao, $preco, $promocao, $imagem_atual, $estoque, $estado, $idProduto);
        
        if ($stmt->execute()) {
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "<div class='alert alert-danger'>Erro ao editar: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }

    // AÇÃO: EXCLUIR PRODUTO
    if ($acao == 'excluir') {
        $idProduto = (int)$_POST['idProduto'];
        
        // Busca informação da imagem para excluir o arquivo
        $stmt = $conn->prepare("SELECT imagem FROM produtos WHERE idProduto=? AND vendido=0");
        $stmt->bind_param("i", $idProduto);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $imagem_nome = $row['imagem'];
            // Remove arquivo de imagem se não for a padrão
            if ($imagem_nome != 'default.jpg') {
                $imagem_path = "../../../public/img/" . $imagem_nome;
                if (file_exists($imagem_path)) {
                    unlink($imagem_path);
                }
            }
        }
        $stmt->close();

        // Exclui registro do banco
        $stmt = $conn->prepare("DELETE FROM produtos WHERE idProduto=? AND vendido=0");
        $stmt->bind_param("i", $idProduto);
        $stmt->execute();
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // AÇÃO: MARCAR PRODUTO COMO VENDIDO
    if ($acao == 'vender') {
        $idProduto = (int)$_POST['idProduto'];
        
        // Atualiza status para vendido e registra data
        $stmt = $conn->prepare("UPDATE produtos SET vendido=1, data_venda=NOW() WHERE idProduto=? AND vendido=0");
        $stmt->bind_param("i", $idProduto);
        $stmt->execute();
        $stmt->close();
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

/**
 * CONSULTA E FILTRAGEM DE PRODUTOS
 * Busca produtos não vendidos com filtros opcionais
 */

// Obtém parâmetros de filtro da URL
$filtro_estado = $_GET['filtro_estado'] ?? '';
$filtro_tamanho = $_GET['filtro_tamanho'] ?? '';
$filtro_marca = $_GET['filtro_marca'] ?? '';

// Constrói query base para produtos não vendidos
$query = "SELECT p.* FROM produtos p WHERE vendido=0";

// Adiciona filtros conforme selecionados
if ($filtro_estado) $query .= " AND p.estado = '" . $conn->real_escape_string($filtro_estado) . "'";
if ($filtro_tamanho) $query .= " AND p.tamanho = '" . $conn->real_escape_string($filtro_tamanho) . "'";
if ($filtro_marca) $query .= " AND p.marca = '" . $conn->real_escape_string($filtro_marca) . "'";

$query .= " ORDER BY idProduto DESC"; // Ordena por ID decrescente (mais recentes primeiro)

// Executa consulta
$produtos = $conn->query($query);

// Busca opções para os filtros (valores distintos do banco)
$estados = $conn->query("SELECT DISTINCT estado FROM produtos WHERE estado IS NOT NULL AND vendido=0 ORDER BY estado");
$tamanho = $conn->query("SELECT DISTINCT tamanho FROM produtos WHERE tamanho IS NOT NULL AND vendido=0 ORDER BY tamanho");
$marcas = $conn->query("SELECT DISTINCT marca FROM produtos WHERE marca IS NOT NULL AND vendido=0 ORDER BY marca");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel do Administrador - Produtos</title>
  <!-- Inclui Bootstrap CSS e ícones -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <link rel="stylesheet" href="../../../public/css/estilo.css">
  
</head>

<!-- ===========================
     CABEÇALHO DO PAINEL ADMIN
=========================== -->
<header class="admin-header">
    <h2><i class="bi bi-speedometer2"></i> Painel do Administrador</h2>
    <p>Gerencie seus produtos de forma completa e organizada</p>
</header>

<!-- ===========================
     NAVBAR SIMPLIFICADA
=========================== -->
<nav class="navbar navbar-expand-lg header-nav-bar">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar" aria-controls="adminNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="bi bi-house me-1"></i> Início
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="faq.php">
                        <i class="bi bi-question-circle me-1"></i> FAQ
                    </a>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-tags-fill me-1"></i> Produtos
                    </a>
                    <ul class="dropdown-menu">
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">Feminino</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Sapatos</a></li>
                                <li><a class="dropdown-item" href="#">Blusas</a></li>
                                <li><a class="dropdown-item" href="#">Saias</a></li>
                            </ul>
                        </li>
                        <li class="dropdown-submenu">
                            <a class="dropdown-item dropdown-toggle" href="#">Masculino</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Camisas</a></li>
                                <li><a class="dropdown-item" href="#">Calças</a></li>
                                <li><a class="dropdown-item" href="#">Jaquetas</a></li>
                            </ul>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../produtos.php">Todos os Produtos</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-fill me-1"></i> Minha Conta
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="log.php">Login</a></li>
                        <li><a class="dropdown-item" href="#">Não tem conta? Cadastre-se</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ===========================
     CONTEÚDO PRINCIPAL
=========================== -->
<div class="container my-5">
    <!-- SEÇÃO: CADASTRO DE NOVO PRODUTO -->
    <div class="section-header">
        <h4><i class="bi bi-plus-circle"></i> Cadastrar Novo Produto</h4>
    </div>
    <div class="card p-4 shadow-sm mb-5">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" id="form-adicionar">
            <input type="hidden" name="acao" value="adicionar">
            <div class="row g-3">
                <!-- Campos do formulário de cadastro -->
                <div class="col-md-6">
                    <label class="form-label">Nome do Produto</label>
                    <input type="text" name="nome" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tem Marca?</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="tem_marca" value="1" id="tem_marca_add">
                        <label class="form-check-label" for="tem_marca_add">Marcar se tiver marca</label>
                    </div>
                    <div class="marca" id="marca_add">
                        <label class="form-label">Marca:</label>
                        <input type="text" name="marca" class="form-control" value="Sem Marca">
                </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tamanho</label>
                    <input type="text" name="tamanho" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Estado</label>
                    <select name="estado" class="form-select" required>
                        <option value="Novo">Novo</option>
                        <option value="Semi-novo">Semi-novo</option>
                        <option value="Usado">Usado</option>
                    </select>
                </div>
<div class="col-md-4">
    <label class="form-label">Categoria</label>
    <select name="idCategoria" class="form-select" required>
        <option value="">Selecione uma categoria</option>
        <?php foreach($categorias_data as $cat): ?>
            <option value="<?= $cat['idCategoria'] ?>">
                <?= htmlspecialchars($cat['descricao']) ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>
                <div class="col-md-6">
                    <label class="form-label">Preço (R$)</label>
                    <input type="number" step="0.01" name="preco" class="form-control" min="0" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Imagem</label>
                    <input type="file" name="imagem" accept="image/*" class="form-control">
                    <small class="text-muted">Apenas JPG, PNG, GIF. Máx. 5MB.</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Promoção?</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="promocao" value="1" id="promocao_add">
                        <label class="form-check-label" for="promocao_add">Marcar como promoção</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Tem Estoque?</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="tem_estoque" value="1" id="tem_estoque_add">
                        <label class="form-check-label" for="tem_estoque_add">Marcar se tem estoque (senão, produto único)</label>
                    </div>
                    <div class="estoque-quantidade" id="estoque_quantidade_add">
                        <label class="form-label">Quantidade em Estoque</label>
                        <input type="number" name="estoque" class="form-control" min="1" value="1">
                    </div>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" rows="3" class="form-control"></textarea>
                </div>
            </div>
            <div class="text-end mt-4">
                <button type="submit" class="btn btn-primary px-4">
                    <i class="bi bi-save"></i> Salvar Produto
                </button>
            </div>
        </form>
        <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert alert-<?= $_SESSION['tipo_mensagem'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show mt-3" role="alert">
                <?= $_SESSION['mensagem'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php 
            // Limpa a mensagem após exibir
            unset($_SESSION['mensagem']);
            unset($_SESSION['tipo_mensagem']);
            ?>
        <?php endif; ?>
    </div>


    <!-- SEÇÃO: LISTAGEM DE PRODUTOS -->
    <div class="section-header">
        <h4><i class="bi bi-list-ul"></i> Produtos Cadastrados</h4>
    </div>
    <div class="card p-4 shadow-sm">
        <!-- FORMULÁRIO DE FILTROS -->
        <form method="GET" class="mb-3">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Filtrar por Estado</label>
                    <select name="filtro_estado" class="form-select">
                        <option value="">Todos</option>
                        <?php while($e = $estados->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($e['estado']) ?>" <?= $filtro_estado == $e['estado'] ? 'selected' : '' ?>><?= htmlspecialchars($e['estado']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Filtrar por Tamanho</label>
                    <select name="filtro_tamanho" class="form-select">
                        <option value="">Todos</option>
                        <?php while($t = $tamanho->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($t['tamanho']) ?>" <?= $filtro_tamanho == $t['tamanho'] ? 'selected' : '' ?>><?= htmlspecialchars($t['tamanho']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Filtrar por Marca</label>
                    <select name="filtro_marca" class="form-select">
                        <option value="">Todos</option>
                        <?php while($m = $marcas->fetch_assoc()): ?>
                            <option value="<?= htmlspecialchars($m['marca']) ?>" <?= $filtro_marca == $m['marca'] ? 'selected' : '' ?>><?= htmlspecialchars($m['marca']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-secondary">Filtrar</button>
                </div>
            </div>
        </form>

        <!-- TABELA DE PRODUTOS -->
        <div class="table-responsive">
            <table class="table table-striped align-middle">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Imagem</th>
                    <th>Nome</th>
                    <th>Categoria</th>
                    <th>Preço</th>
                    <th>Estoque</th>
                    <th>Estado</th>
                    <th>Promoção</th>
                    <th>Vendido</th>
                    <th>Ações</th>
                </tr>
                </thead>
                <tbody>
                <?php while($p = $produtos->fetch_assoc()): ?>
                <tr>
                    <td><?= $p['idProduto'] ?></td>
                    <td>
                        <img src="../../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg') ?>" alt="Img <?= htmlspecialchars($p['nome']) ?>" onerror="this.src='../../../public/img/default.jpg';">
                    </td>
                    <td><?= htmlspecialchars($p['nome']) ?></td>
                    <td>
                        <?php
                        // Converte ID da categoria para nome legível
                        $categoria_nome = '';
                        switch ($p['idCategoria']) {
                            case 1: $categoria_nome = 'Bermudas e Shorts'; break;
                            case 2: $categoria_nome = 'Blazers'; break;
                            case 3: $categoria_nome = 'Blusas e Camisas'; break;
                            case 4: $categoria_nome = 'Calças'; break;
                            case 5: $categoria_nome = 'Casacos e Jaquetas'; break;
                            case 6: $categoria_nome = 'Conjuntos'; break;
                            case 7: $categoria_nome = 'Saias'; break;
                            case 8: $categoria_nome = 'Sapatos'; break;
                            case 9: $categoria_nome = 'Social'; break;
                            case 10: $categoria_nome = 'Vestidos'; break;
                            default: $categoria_nome = 'N/A';
                        }
                        echo htmlspecialchars($categoria_nome);
                        ?>
                    </td>
                    <td>R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
                    <td>
                        <?php if ($p['estoque'] == 1): ?>
                            <span class="badge bg-info">Produto Único</span>
                        <?php elseif ($p['estoque'] > 1): ?>
                            <span class="badge bg-success">Sim (<?= $p['estoque'] ?>)</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Não</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['estado'] ?? 'N/A') ?></td>
                    <td><?= $p['promocao'] ? '<span class="badge badge-promocao">Sim</span>' : '<span class="badge bg-secondary">Não</span>' ?></td>
                    <td>
                        <?php if ($p['vendido']): ?>
                            <span class="badge badge-vendido">Sim</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Não</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!$p['vendido']): ?>
                        <!-- Botões de ação para produtos não vendidos -->
                        <button type="button" class="btn btn-warning btn-sm me-1 editar-btn"
                                data-id="<?= $p['idProduto'] ?>"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>"
                                data-marca="<?= htmlspecialchars($p['marca'] ?? '') ?>"
                                data-tamanho="<?= htmlspecialchars($p['tamanho'] ?? '') ?>"
                                data-idcategoria="<?= $p['idCategoria'] ?? '' ?>"
                                data-descricao="<?= htmlspecialchars($p['descricao'] ?? '') ?>"
                                data-preco="<?= $p['preco'] ?>"
                                data-promocao="<?= $p['promocao'] ?>"
                                data-imagem="<?= htmlspecialchars($p['imagem'] ?? 'default.jpg') ?>"
                                data-estoque="<?= $p['estoque'] ?? 1 ?>"
                                data-estado="<?= htmlspecialchars($p['estado'] ?? '') ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button type="button" class="btn btn-danger btn-sm me-1 excluir-btn"
                                data-id="<?= $p['idProduto'] ?>"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>">
                            <i class="bi bi-trash"></i>
                        </button>
                        <button type="button" class="btn btn-success btn-sm vender-btn"
                                data-id="<?= $p['idProduto'] ?>"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>">
                            <i class="bi bi-check-circle"></i> Vender
                        </button>
                        <?php else: ?>
                        <span class="text-muted">Vendido</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php if ($produtos->num_rows == 0): ?>
            <div class="text-center py-4">
                <p class="text-muted">Nenhum produto cadastrado ainda. Adicione o primeiro!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- MODAL DE EDIÇÃO -->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title" id="modalEditarLabel">
          <i class="bi bi-pencil"></i> Editar Produto
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" id="form-editar">
        <input type="hidden" name="acao" value="editar">
        <input type="hidden" name="idProduto" id="editar_idProduto">
        <input type="hidden" name="imagem_atual" id="editar_imagem_atual">
        <div class="modal-body">
          <!-- Preview da Imagem Atual -->
          <div class="col-md-12 mb-3">
            <label class="form-label">Imagem Atual:</label>
            <img id="preview_imagem_atual" src="" alt="Imagem atual" style="display: none; max-width: 200px; max-height: 200px;">
          </div>
          <div class="row g-3">
            <!-- Campos do formulário de edição -->
            <div class="col-md-6">
              <label class="form-label">Nome do Produto</label>
              <input type="text" name="nome" id="editar_nome" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tem Marca?</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="tem_marca" value="1" id="editar_tem_marca">
                <label class="form-check-label" for="editar_tem_marca">Marcar se tiver marca</label>
              </div>
              <div class="marca" id="editar_marca_div">
                <label class="form-label">Marca:</label>
                <input type="text" name="marca" id="editar_marca" class="form-control" value="Sem Marca">
              </div>
            </div>
            <div class="col-md-4">
              <label class="form-label">Tamanho</label>
              <input type="text" name="tamanho" id="editar_tamanho" class="form-control">
            </div>
            <div class="col-md-4">
              <label class="form-label">Estado</label>
              <select name="estado" id="editar_estado" class="form-select" required>
                <option value="Novo">Novo</option>
                <option value="Semi-novo">Semi-novo</option>
                <option value="Usado">Usado</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Categoria</label>
              <select name="idCategoria" id="editar_idCategoria" class="form-select" required>
                <option value="">Selecione uma categoria</option>
                <?php foreach($categorias_data as $cat): ?>
                  <option value="<?= $cat['idCategoria'] ?>">
                    <?= htmlspecialchars($cat['descricao']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Preço (R$)</label>
              <input type="number" step="0.01" name="preco" id="editar_preco" class="form-control" min="0" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nova Imagem (Opcional)</label>
              <input type="file" name="imagem" accept="image/*" class="form-control">
              <small class="text-muted">Deixe em branco para manter a imagem atual.</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Promoção?</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="promocao" value="1" id="editar_promocao">
                <label class="form-check-label" for="editar_promocao">Marcar como promoção</label>
              </div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tem Estoque?</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="tem_estoque" value="1" id="editar_tem_estoque">
                <label class="form-check-label" for="editar_tem_estoque">Marcar se tem estoque (senão, produto único)</label>
              </div>
              <div class="estoque-quantidade" id="editar_estoque_quantidade">
                <label class="form-label">Quantidade em Estoque</label>
                <input type="number" name="estoque" id="editar_estoque" class="form-control" min="1" value="1">
              </div>
            </div>
            <div class="col-md-12">
              <label class="form-label">Descrição</label>
              <textarea name="descricao" id="editar_descricao" rows="3" class="form-control"></textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-warning">
            <i class="bi bi-save"></i> Atualizar Produto
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- ====================== FOOTER ====================== -->
<footer class="footer">
  <div class="container">
    <div class="row gy-4">
      
      <!-- Logo + descrição -->
      <div class="col-lg-4 col-md-6 footer-info">
        <a href="index.php" class="logo d-flex align-items-center">
          <img src="../../public/img/logo.png" alt="Logo">
          <span>Brechó Koꓘero</span>
        </a>
        <p>Sua loja online de roupas, estilo e qualidade. Verde, amarelo e preto para realçar sua identidade.</p>
        <div class="social-links d-flex mt-3">
          <a href="#"><i class="bi bi-twitter"></i></a>
          <a href="#"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/brecho.kokero?igsh=aTV4M3YyNmViZXB1"><i class="bi bi-instagram"></i></a>
          <a href="#"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <!-- Links úteis -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Links</h4>
        <ul>
          <li><a href="#">Início</a></li>
          <li><a href="#">Produtos</a></li>
          <li><a href="#">Categorias</a></li>
          <li><a href="#">Contato</a></li>
        </ul>
      </div>

      <!-- Categorias -->
      <div class="col-lg-2 col-md-3 footer-links">
        <h4>Categorias</h4>
        <ul>
          <li><a href="#">Masculino</a></li>
          <li><a href="#">Feminino</a></li>
          <li><a href="#">Infantil</a></li>
          <li><a href="#">Acessórios</a></li>
        </ul>
      </div>

      <!-- Contato -->
      <div class="col-lg-4 col-md-6 footer-contact">
        <h4>Contato</h4>
        <p>
          Rua Exemplo, 123 <br>
          Cidade - Estado <br>
          Brasil <br><br>
          <strong>Telefone:</strong> (11) 99999-9999<br>
          <strong>Email:</strong> contato@minhaloja.com<br>
        </p>
      </div>

    </div>
  </div>

  <div class="container mt-4">
    <div class="copyright">
      &copy; 2025 <strong><span>Brechó Koꓘero</span></strong>. Todos os direitos reservados.
    </div>
    <div class="credits">
      Desenvolvido com 💛 por <a href="https://vebgtech.talentosdoifsp.gru.br/">VebgTech</a>
    </div>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../../public/js/script.js"></script>

<script>
/**
 * JAVASCRIPT - FUNCIONALIDADES DA INTERFACE
 * Controla interações do usuário sem recarregar a página
 */
/**
 * JAVASCRIPT - FUNCIONALIDADES DA INTERFACE
 * Controla interações do usuário sem recarregar a página
 */
document.addEventListener('DOMContentLoaded', function () {
    // Função para mostrar/ocultar campo de quantidade de estoque
    function toggleEstoqueQuantidade(checkboxId, quantidadeId) {
        const checkbox = document.getElementById(checkboxId);
        const quantidadeDiv = document.getElementById(quantidadeId);
        
        if (checkbox && quantidadeDiv) {
            const quantidadeInput = quantidadeDiv.querySelector('input[name="estoque"]');
            
            if (checkbox.checked) {
                quantidadeDiv.style.display = 'block';
                if (quantidadeInput) quantidadeInput.required = true;
            } else {
                quantidadeDiv.style.display = 'none';
                if (quantidadeInput) {
                    quantidadeInput.required = false;
                    quantidadeInput.value = '1';  // Default para produto único
                }
            }
        }
    }

    // Função para mostrar/ocultar campo de marca
    function toggleMarcaCampo(checkboxId, campoMarcaId) {
        const checkbox = document.getElementById(checkboxId);
        const marcaDiv = document.getElementById(campoMarcaId);
        
        if (checkbox && marcaDiv) {
            const marcaInput = marcaDiv.querySelector('input[name="marca"]');
            
            if (checkbox.checked) {
                marcaDiv.style.display = 'block';
                if (marcaInput) marcaInput.required = true;
            } else {
                marcaDiv.style.display = 'none';
                if (marcaInput) {
                    marcaInput.required = false;
                    marcaInput.value = 'Sem Marca';
                }
            }
        }
    }

    // Inicializar estados dos campos
function inicializarCampos() {
    // Controle do campo estoque para adicionar produto
    const temEstoqueAdd = document.getElementById('tem_estoque_add');
    if (temEstoqueAdd) {
        toggleEstoqueQuantidade('tem_estoque_add', 'estoque_quantidade_add');
        temEstoqueAdd.addEventListener('change', function() {
            toggleEstoqueQuantidade('tem_estoque_add', 'estoque_quantidade_add');
        });
    }

    // Controle do campo marca para adicionar produto
    const temMarcaAdd = document.getElementById('tem_marca_add');
    if (temMarcaAdd) {
        toggleMarcaCampo('tem_marca_add', 'marca_add');
        temMarcaAdd.addEventListener('change', function() {
            toggleMarcaCampo('tem_marca_add', 'marca_add');
        });
    }

    // Controle do campo estoque para editar produto
    const temEstoqueEdit = document.getElementById('editar_tem_estoque');
    if (temEstoqueEdit) {
        temEstoqueEdit.addEventListener('change', function() {
            toggleEstoqueQuantidade('editar_tem_estoque', 'editar_estoque_quantidade');
        });
    }

    // +++ NOVO: Controle do campo marca para editar produto +++
    const temMarcaEdit = document.getElementById('editar_tem_marca');
    if (temMarcaEdit) {
        temMarcaEdit.addEventListener('change', function() {
            toggleMarcaCampo('editar_tem_marca', 'editar_marca_div');
        });
    }
}

    // Inicializar campos quando a página carregar
    inicializarCampos();

    // MODAL DE EDIÇÃO - Preenchimento dinâmico dos dados
    // MODAL DE EDIÇÃO - Preenchimento dinâmico dos dados
    const modalEditarEl = document.getElementById('modalEditar');
    if (modalEditarEl) {
        const modalEditar = new bootstrap.Modal(modalEditarEl);
        const editButtons = document.querySelectorAll('.editar-btn');
        
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                const data = this.dataset;
                console.log('Dados do produto:', data); // Para debug
                
                // Preenche campos do formulário com dados do produto
                document.getElementById('editar_idProduto').value = data.id || '';
                document.getElementById('editar_imagem_atual').value = data.imagem || 'default.jpg';
                document.getElementById('editar_nome').value = data.nome || '';
                
                // Controle do campo marca
                const marcaInput = document.getElementById('editar_marca');
                const temMarcaCheckbox = document.getElementById('editar_tem_marca');
                if (marcaInput && temMarcaCheckbox) {
                    marcaInput.value = data.marca || 'Sem Marca';
                    // Se tiver marca preenchida, marcar o checkbox
                    temMarcaCheckbox.checked = (data.marca && data.marca !== '' && data.marca !== 'Sem Marca');
                    toggleMarcaCampo('editar_tem_marca', 'editar_marca_div');
                }
                
                document.getElementById('editar_tamanho').value = data.tamanho || '';
                document.getElementById('editar_idCategoria').value = data.idcategoria || '';
                document.getElementById('editar_descricao').value = data.descricao || '';
                document.getElementById('editar_preco').value = data.preco || '';
                
                // Checkbox de promoção
                const promocaoCheckbox = document.getElementById('editar_promocao');
                if (promocaoCheckbox) {
                    promocaoCheckbox.checked = (data.promocao == '1' || data.promocao == 1);
                }
                
                document.getElementById('editar_estoque').value = data.estoque || 1;
                document.getElementById('editar_estado').value = data.estado || '';
                
                // Configura controle de estoque
                const temEstoqueCheckbox = document.getElementById('editar_tem_estoque');
                const estoqueQuantidade = parseInt(data.estoque) || 1;
                if (temEstoqueCheckbox) {
                    temEstoqueCheckbox.checked = estoqueQuantidade > 1;
                    toggleEstoqueQuantidade('editar_tem_estoque', 'editar_estoque_quantidade');
                }
                
                // Exibe preview da imagem atual
                const previewImg = document.getElementById('preview_imagem_atual');
                const imagemAtual = data.imagem || 'default.jpg';
                if (previewImg) {
                    previewImg.src = '../../../public/img/' + imagemAtual;
                    previewImg.style.display = 'block';
                    previewImg.style.maxWidth = '200px';
                    previewImg.style.maxHeight = '200px';
                    previewImg.onerror = function() {
                        this.src = '../../../public/img/default.jpg';
                    };
                }
                
                modalEditar.show();
            });
        });
    }

    // BOTÕES DE EXCLUIR - Confirmação antes de excluir
    const deleteButtons = document.querySelectorAll('.excluir-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.dataset.id;
            const nome = this.dataset.nome;
            
            if (confirm(`Tem certeza que deseja excluir o produto "${nome}"? Esta ação não pode ser desfeita.`)) {
                // Cria formulário dinâmico para enviar requisição POST
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?php echo $_SERVER['PHP_SELF']; ?>';
                form.style.display = 'none';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="idProduto" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        });
    });

    // BOTÕES DE VENDER - Confirmação antes de marcar como vendido
    const sellButtons = document.querySelectorAll('.vender-btn');
    sellButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.dataset.id;
            const nome = this.dataset.nome;
            
            if (confirm(`Marcar "${nome}" como vendido?`)) {
                // Cria formulário dinâmico para enviar requisição POST
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '<?php echo $_SERVER['PHP_SELF']; ?>';
                form.style.display = 'none';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="vender">
                    <input type="hidden" name="idProduto" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        });
    });

    // Fechar alertas automaticamente após 5 segundos
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});
</script>

</body>
</html>
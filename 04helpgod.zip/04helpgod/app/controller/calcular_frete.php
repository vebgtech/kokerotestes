<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');  // Para AJAX do frontend (ajuste se necessário)
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Inclua conexão se precisar buscar mais dados do produto (opcional)
include('../config/conexao.php');

// Configurações do Melhor Envio (SUBSTITUA PELOS SEUS DADOS REAIS)
$token = 'Bearer SEU_TOKEN_AQUI';  // Ex: 'Bearer abc123def456...' (gere no painel)
$id_remetente = 12345;  // ID do remetente cadastrado no painel do Melhor Envio
$cep_origem = '01000000';  // CEP do brechó (sem hífen, ex: CEP de SP para teste)
$url_api = 'https://sandbox.melhorenvio.com.br/api/v2/me/shipment/calculate';  // Sandbox para testes
// Para produção: $url_api = 'https://api.melhorenvio.com.br/api/v2/me/shipment/calculate';

// Receber dados do frontend (JSON via POST)
$input = json_decode(file_get_contents('php://input'), true);
$cep_destino = $input['cep_destino'] ?? '';
$produto = $input['produto'] ?? [];

if (empty($cep_destino) || strlen($cep_destino) !== 8 || !ctype_digit($cep_destino)) {
    echo json_encode(['error' => 'CEP de destino inválido. Digite 8 dígitos numéricos.']);
    exit;
}

// Preparar dados para a API do Melhor Envio
$dados_api = [
    'remetente' => [
        'id' => (int)$id_remetente
    ],
    'destinatario' => [
        'cep' => $cep_destino,
        'nome' => 'Cliente Exemplo',  // Genérico para cálculo (pode ser dinâmico no checkout)
        'telefone' => '11999999999',  // Genérico
        'email' => 'cliente@exemplo.com'  // Genérico
    ],
    'itens' => [
        [
            'id' => $produto['id'] ?? 1,
            'peso' => ($produto['peso'] ?? 0.5) * 1000,  // Converter kg para gramas (ex: 0.5kg = 500g)
            'altura' => (float)($produto['altura'] ?? 20),  // cm
            'largura' => (float)($produto['largura'] ?? 30),  // cm
            'comprimento' => (float)($produto['comprimento'] ?? 10),  // cm
            'diametro' => 0,  // Para pacotes retangulares
            'valor' => (float)($produto['preco'] ?? 0),  // Valor para seguro
            'categoria' => 'outros'  // 'roupa', 'acessorio', 'eletronico' - ajuste se necessário
        ]
    ]
];

// Chamar API via cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($dados_api));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: ' . $token,
    'Content-Type: application/json',
    'Accept: application/json'
]);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  // Para testes; ative em produção

$resposta = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$erro_curl = curl_error($ch);
curl_close($ch);

// Tratar resposta da API
if ($erro_curl) {
    echo json_encode(['error' => 'Erro na conexão: ' . $erro_curl]);
    exit;
}

if ($http_code !== 200) {
    $resposta_decod = json_decode($resposta, true);
    $msg_erro = $resposta_decod['message'] ?? 'Erro desconhecido na API';
    echo json_encode(['error' => 'Falha na API do Melhor Envio (código ' . $http_code . '): ' . $msg_erro]);
    exit;
}

$resposta_decod = json_decode($resposta, true);

// Extrair opções de frete (array de opções)
$fretes = [];
if (isset($resposta_decod['data']['options']) && is_array($resposta_decod['data']['options'])) {
    foreach ($resposta_decod['data']['options'] as $opcao) {
        $fretes[] = [
            'transportadora' => $opcao['company']['name'] ?? 'Desconhecida',
            'servico' => $opcao['service']['name'] ?? 'Serviço padrão',
            'valor' => number_format($opcao['price'] ?? 0, 2, '.', ''),  // Formato para exibição (ex: 15.00)
            'prazo_entrega' => $opcao['deadline']['business_days'] ?? 0 . ' dias úteis',
            'cep_origem' => $cep_origem  // Para exibição
        ];
    }
}

// Retornar JSON para o frontend
echo json_encode([
    'success' => true,
    'cep_origem' => $cep_origem,
    'fretes' => $fretes
]);
?>


// Explicações Finais Antes do Código
Funcionamento:
O frontend (JS em detalhes.php) envia o CEP do cliente e dados do produto via AJAX (POST JSON) para calcular_frete.php.
O backend (calcular_frete.php) valida os dados, prepara o payload para a API do Melhor Envio e faz a chamada via cURL.
A API retorna opções de frete (ex: Correios PAC, Jadlog, etc.). O script processa e retorna um JSON simples com as opções (transportadora, serviço, valor, prazo).
No frontend, o JS exibe as opções em cards bonitos (como no CSS que adicionei).
Configurações Obrigatórias:
Token: Gere no painel do Melhor Envio (https://app.melhorenvio.com.br/integracoes/api). Use o de sandbox para testes: URL https://sandbox.melhorenvio.com.br/api/v2/me/shipment/calculate.
Para produção, troque para https://api.melhorenvio.com.br/api/v2/me/shipment/calculate e use o token real.
ID Remetente: Cadastre o brechó como remetente no painel e anote o ID (ex: 12345).
CEP Origem: Seu CEP fixo (sem hífen, ex: '01234000' para SP).
Dados do Produto: Usei valores padrão (peso 0.5kg, dimensões pequenas para roupas). Se adicionou campos no banco (peso, largura, etc.), eles são passados do detalhes.php.
Limitações e Testes:
A API requer autenticação Bearer. Teste com CEPs reais (ex: origem 01000000, destino 20000000).
Erros comuns: Token inválido (401), CEP inválido (400), sem opções (array vazio).
Para geração de etiqueta (após compra), use outro endpoint (/shipment/generate), mas isso é para o checkout final.
Segurança: O token fica só no server (PHP), não exposto no JS.
Dependências: cURL deve estar habilitado no PHP (padrão em hosts como Hostinger, Locaweb).
Melhorias Futuras: No carrinho/checkout, salve a opção de frete escolhida e gere a etiqueta via API.


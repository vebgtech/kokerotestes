document.addEventListener('DOMContentLoaded', function () {
    // Apenas para telas mobile (onde o hover não funciona)
    if (window.innerWidth < 992) {
        document.querySelectorAll('.dropdown-submenu a.dropdown-toggle').forEach(function (element) {
            element.addEventListener('click', function (e) {
                // Impede que o link seja seguido e que o menu principal feche
                e.preventDefault();
                e.stopPropagation();
                
                let parentMenu = this.closest('.dropdown-menu');
                
                // Fecha outros submenus que possam estar abertos no mesmo nível
                parentMenu.querySelectorAll('.dropdown-submenu .dropdown-menu.show').forEach(function(openSubmenu) {
                    if (openSubmenu !== this.nextElementSibling) {
                        openSubmenu.classList.remove('show');
                    }
                });
                
                // Abre ou fecha o submenu atual
                this.nextElementSibling.classList.toggle('show');
            });
        });
    }
});




// Produtos Detalhes












// ======================================================
//  LÓGICA PARA NAVEGAÇÃO ATIVA NA PÁGINA FAQ
// ======================================================
document.addEventListener('DOMContentLoaded', () => {
    // Só executa se encontrar os elementos da página FAQ
    const faqNav = document.querySelector('.faq-nav');
    if (faqNav) {
        const navLinks = document.querySelectorAll('.faq-nav a');
        const sections = document.querySelectorAll('.faq-item');

        const observerOptions = {
            root: null, // Observa em relação ao viewport
            rootMargin: '0px',
            threshold: 0.4  // A seção precisa estar 40% visível
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Remove a classe 'active' de todos os links
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                    });

                    // Adiciona a classe 'active' ao link correspondente
                    const activeLink = document.querySelector(`.faq-nav a[href="#${entry.target.id}"]`);
                    if (activeLink) {
                        activeLink.classList.add('active');
                    }
                }
            });
        }, observerOptions);

        // Observa cada seção
        sections.forEach(section => {
            observer.observe(section);
        });
    }
});


// cadastre.php - Verificar cadastro com sucesso

// cadastro-success.js
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const cadastroSucesso = urlParams.get('cadastro_sucesso');
    
    if (cadastroSucesso === 'true') {
        // Remover o parâmetro da URL sem recarregar a página
        const novaURL = window.location.pathname;
        window.history.replaceState({}, document.title, novaURL);
        
        // Criar e mostrar o modal
        const modalHTML = `
            <div class="modal fade" id="cadastroSucessoModal" tabindex="-1" aria-labelledby="cadastroSucessoModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title text-success" id="cadastroSucessoModalLabel">
                                <i class="bi bi-check-circle-fill me-2"></i>Cadastro realizado com sucesso!
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <p>Seu cadastro foi realizado com sucesso! Deseja fazer login agora?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Mais tarde</button>
                            <a href="log.php" class="btn btn-success">Fazer Login</a>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        const modal = new bootstrap.Modal(document.getElementById('cadastroSucessoModal'));
        modal.show();
    }
});

// Interatividade para a página de cadastro
document.addEventListener('DOMContentLoaded', function() {
    // Efeitos nos campos do formulário
    const formInputs = document.querySelectorAll('.php-email-form .form-control');
    
    formInputs.forEach(input => {
        // Efeito ao focar
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });
        
        // Efeito ao sair
        input.addEventListener('blur', function() {
            if (this.value === '') {
                this.parentElement.classList.remove('focused');
            }
        });
        
        // Verificar se o campo já tem valor ao carregar a página
        if (input.value !== '') {
            input.parentElement.classList.add('focused');
        }
    });
    
    // Validação em tempo real do telefone
    const telefoneInput = document.getElementById('telefone');
    if (telefoneInput) {
        telefoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value.length <= 11) {
                // Formatação: (00) 00000-0000
                if (value.length > 2) {
                    value = value.replace(/^(\d{2})(\d)/g, '($1) $2');
                }
                if (value.length > 10) {
                    value = value.replace(/(\d{5})(\d)/, '$1-$2');
                }
                
                e.target.value = value;
            }
        });
    }
    
    // Efeito de loading no botão de cadastro
    const cadastroForm = document.querySelector('.php-email-form');
    if (cadastroForm) {
        cadastroForm.addEventListener('submit', function() {
            const submitBtn = this.querySelector('#butao');
            if (submitBtn) {
                submitBtn.classList.add('loading');
            }
        });
    }
});
<?php
session_start();
include('../config/conexao.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $nome_cliente = trim($_POST['nome_cliente'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $endereco = trim($_POST['endereco'] ?? '');
    $observacoes_pagamento = trim($_POST['observacoes_pagamento'] ?? '');
    
    // Dados da sessão
    $usuario_id = $_SESSION['usuario_id'] ?? 0;
    $email_cliente = $_SESSION['usuario_email'] ?? '';
    
    // Processar carrinho
    $itensTexto = "";
    $total = 0;
    $qtdItens = 0;
    
    if (isset($_SESSION['carrinho']) && !empty($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $idProduto) {
            $stmt = $conn->prepare("SELECT nome, preco FROM produtos WHERE idProduto = ?");
            $stmt->bind_param("i", $idProduto);
            $stmt->execute();
            $res = $stmt->get_result();
            
            if ($produto = $res->fetch_assoc()) {
                $total += $produto['preco'];
                $qtdItens++;
                $itensTexto .= $produto['nome'] . " - R$ " . number_format($produto['preco'], 2, ',', '.') . "\n";
            }
            $stmt->close();
        }
    } else {
        echo "error: Carrinho vazio";
        exit;
    }
    
    // 🔥 CORREÇÃO FINAL: INSERT com TODAS as 18 colunas na ordem correta
    $sql = "INSERT INTO pedidos (
        idUsuario, 
        dtPedido, 
        telefoneEntrega, 
        endereco, 
        itens, 
        valorTotal, 
        status, 
        observacoes, 
        metodo_pagamento, 
        qtdItens, 
        status_pagamento, 
        observacoes_pagamento, 
        usuario_id, 
        usuario_email
        -- As colunas data_atualizacao, codigo_rastreio, valorFrete usam valores DEFAULT
    ) VALUES (?, NOW(), ?, ?, ?, ?, 'pendente', '', 'WhatsApp', ?, 'pendente', ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo "error: " . $conn->error;
        exit;
    }
    
    // 🔥 AGORA COM A ORDEM CORRETA: 14 parâmetros para 14 colunas
    // A tabela tem 18 colunas, mas 4 têm valores DEFAULT (data_atualizacao, codigo_rastreio, valorFrete)
    $stmt->bind_param("isssdissis", 
        $usuario_id,           // i - idUsuario
        $telefone,             // s - telefoneEntrega
        $endereco,             // s - endereco  
        $itensTexto,           // s - itens
        $total,                // d - valorTotal
        $qtdItens,             // i - qtdItens
        $observacoes_pagamento, // s - observacoes_pagamento
        $usuario_id,           // i - usuario_id
        $email_cliente         // s - usuario_email
    );
    
    if ($stmt->execute()) {
        $pedido_id = $stmt->insert_id;
        echo "success - Pedido #" . $pedido_id;
        
        // Limpar carrinho
        unset($_SESSION['carrinho']);
    } else {
        echo "error: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    echo "invalid_request_method";
}
?>
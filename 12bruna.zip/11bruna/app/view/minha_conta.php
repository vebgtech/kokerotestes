<?php require_once '../controller/auth_check.php';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Minha conta - Brechó Kokero</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../public/css/estilo.css">
  </header>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="../../public/index.php">
        <img src="../../public/img/logo.png" alt="Logo" style="height: 80px; width:auto;">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon" style="color:#fff;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link active" href="index.html">Início</a></li>
          <li class="nav-item"><a class="nav-link" href="produtos.php">Produtos</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdownMenu" role="button" data-bs-toggle="dropdown">
              Categorias
            </a>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
              <li><a class="dropdown-item" href="#novidade">Novidade</a></li>
              <li><a class="dropdown-item" href="#todos">Todos</a></li>
              <li><a class="dropdown-item" href="#promocoes">Promoções</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#bermudas-shorts">Bermudas e Shorts</a></li>
              <li><a class="dropdown-item" href="#blazers">Blazers</a></li>
              <li><a class="dropdown-item" href="#blusas-camisas">Blusas e Camisas</a></li>
              <li><a class="dropdown-item" href="#calcas">Calças</a></li>
              <li><a class="dropdown-item" href="#casacos-jaquetas">Casacos e Jaquetas</a></li>
              <li><a class="dropdown-item" href="#conjuntos">Conjuntos</a></li>
              <li><a class="dropdown-item" href="#saias">Saias</a></li>
              <li><a class="dropdown-item" href="#sapatos">Sapatos</a></li>
              <li><a class="dropdown-item" href="#social">Social</a></li>
              <li><a class="dropdown-item" href="#vestidos">Vestidos</a></li>
            </ul>
          </li>
        </ul>

        <form class="d-flex me-3" role="search" method="GET" action="produtos.php">
          <input class="form-control me-2" type="search" name="busca" placeholder="Buscar produtos..."
            value="<?php echo htmlspecialchars($termo_busca); ?>" aria-label="Search">
          <button class="btn btn-dark" type="submit">Buscar</button>
        </form>

        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item me-3">
            <a class="nav-link" href="minha-conta.html">Minha Conta</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="carrinho.html">Carrinho <span class="badge bg-danger">0</span></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <section>
    <p>Teste</p>
    <li class="nav-item">
    <a class="nav-link" href="../controller/logout.php">
        <i class="bi bi-box-arrow-right"></i> Sair
    </a>
</li>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-social">
      <h5>Siga-nos:</h5>
      <p><i class="bi bi-instagram"></i> <a href="https://www.instagram.com/brechokokero"
          target="_blank">@brechokokero</a></p>
      <p><i class="bi bi-whatsapp"></i> <a href="https://wa.me/5511992424158" target="_blank">+55 11 99242-4158</a></p>
    </div>
    <div class="footer-links">
      <h5>Links Úteis</h5>
      <ul>
        <li><a href="index.html">Início</a></li>
        <li><a href="produtos.php">Produtos</a></li>
        <li><a href="promocoes.html">Promoções</a></li>
        <li><a href="contato.html">Contato</a></li>
      </ul>
    </div>
    <div class="footer-logo">
      <img src="../../public/img/logo.png" alt="Logo" style="height: 60px; width: auto;">
      <p>&copy; 2024 Brechó Kokero. Todos os direitos reservados.</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
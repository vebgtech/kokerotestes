<?php
// Inicia ou retoma a sessão, crucial para o carrinho ($_SESSION['carrinho']) e mensagens de status.
session_start();
// Inclui o arquivo de configuração da conexão com o banco de dados.
include('../config/conexao.php');

// --- Buscar produto ---
// Obtém o ID do produto da URL (parâmetro 'id') ou da sessão
$idProduto = 0;
if (isset($_GET['id'])) {
    $idProduto = (int)$_GET['id'];
    // CORREÇÃO: Salva o ID na sessão para recuperar em caso de recarregamento
    $_SESSION['current_product_id'] = $idProduto;
} elseif (isset($_SESSION['current_product_id'])) {
    // CORREÇÃO: Recupera o ID da sessão em caso de recarregamento
    $idProduto = (int)$_SESSION['current_product_id'];
}

// Verifica se o ID do produto é válido.
if ($idProduto <= 0) {
    // Define uma mensagem de erro se o ID for inválido.
    $erro = "ID de produto inválido.";
} else {
    // Prepara a consulta SQL para buscar o produto.
    $stmt = $conn->prepare("SELECT p.* FROM produtos p WHERE p.idProduto = ? AND (p.vendido=0 OR (p.vendido=1 AND p.data_venda > DATE_SUB(NOW(), INTERVAL 7 DAY)))");
    // Vincula o parâmetro $idProduto como um inteiro ('i') à consulta preparada.
    $stmt->bind_param("i", $idProduto);
    // Executa a consulta.
    $stmt->execute();
    // Obtém o resultado da consulta.
    $resultado = $stmt->get_result();

    // Tenta buscar o produto como um array associativo.
    if ($produto = $resultado->fetch_assoc()) {
        // Produto encontrado
    } else {
        // Define uma mensagem de erro se o produto não for encontrado.
        $erro = "Produto não encontrado.";
    }
    // Fecha o statement para liberar recursos do banco.
    $stmt->close();
}

// --- Adicionar ao carrinho ---
// Verifica se o formulário foi submetido via POST e se a ação é 'adicionar_carrinho'.
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'adicionar_carrinho') {
    
    // Obtém o ID do produto do formulário
    $idProdutoForm = isset($_POST['id_produto']) ? (int)$_POST['id_produto'] : 0;
    
    // Verifica se o produto existe e não foi vendido
    if ($idProdutoForm > 0 && isset($produto) && $produto['vendido'] == 0) {
        // Inicializa o array do carrinho na sessão se ainda não existir.
        if (!isset($_SESSION['carrinho'])) $_SESSION['carrinho'] = [];

        // Verifica se o produto (identificado pelo ID) já está no carrinho.
        if (!in_array($idProdutoForm, $_SESSION['carrinho'])) {
            // Adiciona o ID do produto ao array do carrinho.
            $_SESSION['carrinho'][] = $idProdutoForm;
            // Define uma mensagem de sucesso.
            $_SESSION['sucesso_carrinho'] = "Produto único adicionado ao carrinho!";
        } else {
            // Define uma mensagem se o produto já estiver no carrinho.
            $_SESSION['sucesso_carrinho'] = "Este produto já está no carrinho.";
        }
        
        // CORREÇÃO: Redireciona para a mesma página atual mantendo o ID
        $current_url = "produto_detalhes.php?id=" . $idProdutoForm;
        header("Location: " . $current_url);
        exit();
    }
}

// CORREÇÃO: Recupera mensagem da sessão e remove
if (isset($_SESSION['sucesso_carrinho'])) {
    $sucesso = $_SESSION['sucesso_carrinho'];
    unset($_SESSION['sucesso_carrinho']);
}

// CORREÇÃO: Limpa o ID da sessão se estiver acessando uma URL nova com ID
if (isset($_GET['id'])) {
    $_SESSION['current_product_id'] = (int)$_GET['id'];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../public/img/logo.png">
    <title>Brechó Koꓘero</title> 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../../public/css/estilo.css">
    <style>
        /* Estilos CSS embutidos */
        body { font-family: 'Poppins', sans-serif; }
        /* Estilo para preço: cor e tamanho */
        .price { color: #fcd634; font-weight: bold; font-size: 1.5em; }
        /* Ajusta a largura do offcanvas do carrinho */
        .offcanvas { width: 380px !important; }
        /* Estilo para a mensagem de vendido */
        .vendido { color: #dc3545; font-weight: bold; font-size: 1.2em; }
    </style>
</head>
<body>

<header>
    <div class="header-main-bar">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <button class="navbar-toggler d-lg-none menu-toggle-btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand flex-grow-1 flex-lg-grow-0 text-center text-lg-start" href="index.php">
              <img src="../../public/img/logo.png" alt="Logo Brechó Kokero">
            </a>
            
            <form class="search-form flex-grow-1 mx-4 d-none d-lg-flex" role="search">
                <input class="form-control" type="search" placeholder="Digite aqui o que deseja buscar" aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>

            <a class="cart-link" href="#" data-bs-toggle="offcanvas" data-bs-target="#carrinhoOffcanvas" aria-controls="carrinhoOffcanvas">
              <i class="bi bi-cart-fill" style="font-size: 1.5rem;"></i>
              <span class="badge rounded-pill bg-success">
                <?php echo isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : 0; ?>
              </span>
            </a>


        </div>
    </div>

    <div class="header-search-mobile d-lg-none">
        <div class="container-fluid py-2">
            <form class="search-form" role="search">
                <input class="form-control" type="search" placeholder="Digite aqui o que deseja buscar" aria-label="Search">
                <button class="btn" type="submit"><i class="bi bi-search"></i></button>
            </form>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg header-nav-bar">
      <div class="container-fluid justify-content-center">
        <div class="collapse navbar-collapse flex-grow-0" id="navbarContent">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="faq.php">
                <i class="bi bi-box-seam me-1"></i> FAQ
              </a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-tags-fill me-1"></i> Produtos
              </a>
              <ul class="dropdown-menu">
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Feminino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">sapatos</a></li>
                    <li><a class="dropdown-item" href="#">Blusas</a></li>
                    <li><a class="dropdown-item" href="#">Saias</a></li>
                  </ul>
                </li>
                <li class="dropdown-submenu">
                  <a class="dropdown-item dropdown-toggle" href="#">Masculino</a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Camisas</a></li>
                    <li><a class="dropdown-item" href="#">Calças</a></li>
                    <li><a class="dropdown-item" href="#">Jaquetas</a></li>
                  </ul>
                </li>
                <li><hr class="dropdown-divider" style="border-color: #2b5e1d;"></li>
                <li><a class="dropdown-item" href="produtos.php">Todos os Produtos</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-fill me-1"></i> Minha Conta
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="log.php">Login</a></li>
                <li><a class="dropdown-item" href="#">Não tem conta? Cadastre-se</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
</header>

<!-- Container principal da página de detalhes do produto -->
<div class="container mt-5">
    <?php if (isset($erro)): ?>
        <!-- Exibe mensagem de erro se existir -->
        <div class="alert alert-danger text-center">
            <h4>Erro</h4>
            <p><?php echo htmlspecialchars($erro); ?></p>
            <!-- Botão para voltar à lista de produtos -->
            <a href="produtos.php" class="btn btn-success">Voltar</a>
        </div>
    <?php else: ?>
        <!-- Se não há erro, exibe o conteúdo normal da página -->

        <?php if (isset($sucesso)): ?>
            <!-- Exibe mensagem de sucesso (ex: produto adicionado ao carrinho) -->
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo $sucesso; ?>
                <!-- Botão para fechar o alerta -->
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Layout em duas colunas para exibir o produto -->
        <div class="row">
            <!-- Coluna da esquerda: Imagem do produto -->
            <div class="col-md-6">
                <!-- Exibe a imagem do produto com fallback para imagem padrão -->
                <img src="../../public/img/<?php echo htmlspecialchars($produto['imagem'] ?? '../../public/img/default.jpg'); ?>" 
                     class="img-fluid rounded">
                
                <!-- Badge indicando status do produto -->
                <?php if ($produto['vendido'] == 1): ?>
                    <!-- Badge vermelho para produto vendido -->
                    <span class="badge bg-danger mt-2">Já foi vendido</span>
                <?php else: ?>
                    <!-- Badge azul para produto disponível (único) -->
                    <span class="badge bg-info mt-2">Produto Único</span>
                <?php endif; ?>
            </div>

            <!-- Coluna da direita: Informações do produto -->
            <div class="col-md-6">
                <!-- Nome do produto -->
                <h2><?php echo htmlspecialchars($produto['nome']); ?></h2>
                
                <!-- Preço formatado em Real brasileiro -->
                <p class="price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                
                <!-- Informações adicionais do produto -->
                <p><strong>Marca:</strong> <?php echo htmlspecialchars($produto['marca'] ?? ''); ?></p>
                <p><strong>Tamanho:</strong> <?php echo htmlspecialchars($produto['tamanho'] ?? 'N/A'); ?></p>
                
                <!-- Descrição do produto com quebra de linhas preservadas -->
                <p><strong>Descrição:</strong><br><?php echo nl2br(htmlspecialchars($produto['descricao'] ?? 'Descrição não disponível.')); ?></p>
                
<!-- Seção de compra - só exibe se o produto não foi vendido -->
<?php if (isset($produto) && $produto['vendido'] == 0): ?>
    <!-- Formulário para adicionar ao carrinho -->
    <form method="POST" id="form-carrinho">
        <!-- Campo hidden para identificar a ação no backend -->
        <input type="hidden" name="acao" value="adicionar_carrinho">
        <!-- Campo hidden com o ID do produto -->
        <input type="hidden" name="id_produto" value="<?php echo $idProduto; ?>">
        <!-- Botão principal de compra -->
        <button type="submit" class="btn btn-success btn-lg" id="btn-adicionar-carrinho">
            Adicionar ao Carrinho
        </button>
    </form>
<?php else: ?>
    <!-- Mensagem indicando que o produto não está disponível -->
    <p class="vendido mt-3">Este produto já foi vendido.</p>
<?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Offcanvas/Sidebar do carrinho de compras -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="carrinhoOffcanvas">
    <!-- Cabeçalho do offcanvas -->
    <div class="offcanvas-header">
        <!-- Título com ícone -->
        <h5 class="offcanvas-title"><i class="bi bi-bag"></i> Meu Carrinho</h5>
        <!-- Botão para fechar o carrinho -->
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    
    <!-- Corpo do offcanvas -->
    <div class="offcanvas-body">
        <?php if (empty($_SESSION['carrinho'])): ?>
            <!-- Mensagem exibida quando o carrinho está vazio -->
            <p class="text-center text-muted">Seu carrinho está vazio 😢</p>
        <?php else: ?>
            <!-- Lista de itens do carrinho -->
            <ul class="list-group mb-3">
                <?php
                // Inicializa o total da compra
                $total = 0;
                
                // Itera sobre cada ID de produto armazenado na sessão do carrinho
                foreach ($_SESSION['carrinho'] as $id) {
                    // Prepara consulta para buscar detalhes do produto no banco
                    $stmt = $conn->prepare("SELECT nome, preco, imagem FROM produtos WHERE idProduto=?");
                    $stmt->bind_param("i", $id); // "i" indica que o parâmetro é um integer
                    $stmt->execute();
                    $res = $stmt->get_result();
                    
                    // Exibe o item se encontrado no banco
                    if ($p = $res->fetch_assoc()):
                        // Soma o preço ao total
                        $total += $p['preco'];
                ?>
                <!-- Item individual do carrinho -->
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <!-- Container da esquerda: Imagem e informações do produto -->
                    <div class="d-flex align-items-center">
                        <!-- Imagem miniatura do produto -->
                        <img src="../../public/img/<?php echo htmlspecialchars($p['imagem']); ?>" 
                             style="width:50px;height:50px;object-fit:cover;" 
                             class="rounded me-2">
                        <div>
                            <!-- Nome do produto -->
                            <strong><?php echo htmlspecialchars($p['nome']); ?></strong><br>
                            <!-- Preço do produto -->
                            <small>R$ <?php echo number_format($p['preco'], 2, ',', '.'); ?></small>
                        </div>
                    </div>
                    
                    <!-- Container da direita: Botão para remover item -->
                    <form method="POST" action="../controller/remover_carrinho.php">
                        <!-- Campo hidden com ID do produto a ser removido -->
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <!-- Botão de remover com ícone de lixeira -->
                        <button class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i></button>
                    </form>
                </li>
                <?php 
                    endif; 
                    $stmt->close(); // Fecha o statement para liberar recursos
                } // Fim do loop foreach 
                ?>
            </ul>

            <!-- Seção do total da compra -->
            <div class="d-flex justify-content-between mb-3">
                <strong>Total:</strong>
                <!-- Total formatado em Real -->
                <span class="text-success fw-bold">R$ <?php echo number_format($total, 2, ',', '.'); ?></span>
            </div>

            <!-- Botão para finalizar a compra -->
            <a href="checkout.php" class="btn btn-success w-100">Finalizar Compra</a>
        <?php endif; ?>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <div class="row gy-4">
            
            <div class="col-lg-4 col-md-6 footer-info">
                <a href="index.php" class="logo d-flex align-items-center">
                    <img src="../../public/img/logo.png" alt="Logo">
                    <span>Brechó Koꓘero</span>
                </a>
                <p>Sua loja online de roupas, estilo e qualidade. Verde, amarelo e preto para realçar sua identidade.</p>
                <div class="social-links d-flex mt-3">
                    <a href="#"><i class="bi bi-twitter"></i></a>
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="https://www.instagram.com/brecho.kokero?igsh=aTV4M3YyNmViZXB1"><i class="bi bi-instagram"></i></a>
                    <a href="#"><i class="bi bi-linkedin"></i></a>
                </div>
            </div>

            <div class="col-lg-2 col-md-3 footer-links">
                <h4>Links</h4>
                <ul>
                    <li><a href="#">Início</a></li>
                    <li><a href="#">Produtos</a></li>
                    <li><a href="#">Categorias</a></li>
                    <li><a href="#">Contato</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-3 footer-links">
                <h4>Categorias</h4>
                <ul>
                    <li><a href="#">Masculino</a></li>
                    <li><a href="#">Feminino</a></li>
                    <li><a href="#">Infantil</a></li>
                    <li><a href="#">Acessórios</a></li>
                </ul>
            </div>

            <div class="col-lg-4 col-md-6 footer-contact">
                <h4>Contato</h4>
                <p>
                    Rua Exemplo, 123 <br>
                    Cidade - Estado <br>
                    Brasil <br><br>
                    <strong>Telefone:</strong> (11) 99999-9999<br>
                    <strong>Email:</strong> contato@minhaloja.com<br>
                </p>
            </div>

        </div>
    </div>

    <div class="container mt-4">
        <div class="copyright">
            &copy; 2025 <strong><span>Brechó Koꓘero</span></strong>. Todos os direitos reservados.
        </div>
        <div class="credits">
            Desenvolvido com 💛 por <a href="https://vebgtech.talentosdoifsp.gru.br/">VebgTech</a>
        </div>
    </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../public/js/script.js"></script>
<script>
// Script para abrir o offcanvas do carrinho automaticamente se um produto for adicionado.
document.addEventListener("DOMContentLoaded", () => {
    // Verifica se a variável $sucesso foi definida (ou seja, se o produto foi adicionado/já estava no carrinho)
    const sucesso = <?php echo isset($sucesso) && !isset($erro) ? 'true' : 'false'; ?>;
    if (sucesso) {
        // Cria uma nova instância do Offcanvas do Bootstrap
        const offcanvas = new bootstrap.Offcanvas(document.getElementById('carrinhoOffcanvas'));
        // Abre o offcanvas com um pequeno atraso (0.5s) para melhor experiência de usuário após o POST
        setTimeout(() => offcanvas.show(), 500);
    }
    
    // CORREÇÃO: Prevenir reenvio do formulário ao recarregar a página
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
});

// CORREÇÃO: Prevenir envio duplo do formulário
document.querySelector('form')?.addEventListener('submit', function(e) {
    const submitBtn = this.querySelector('button[type="submit"]');
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = 'Adicionando...';
    }
});
</script>

</body>
</html>
<?php require_once '../controller/auth_check.php';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Minha conta - Brechó Kokero</title>
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../public/css/estilo.css">
  <style>
    body {
      background-color: #000;
      color: #fff;
      font-family: 'Poppins', sans-serif;
    }

    /* ===========================
       NAVBAR
    =========================== */
    .navbar {
      background-color: #014d00;
    }

    .navbar .nav-link {
      color: #9ed06f;
      font-weight: 600;
    }

    .navbar .nav-link:hover,
    .navbar .nav-link.active {
      color: #fcd634;
      /* amarelo */
    }

    .navbar .btn {
      border-radius: 20px;
      background-color: #2b5e1d;
      color: #fff;
    }

    .navbar .btn:hover {
      background-color: #1b3e0e;
    }

    /* ===========================
       FILTROS
    =========================== */
    .filtros {
      background-color: #111;
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 30px;
    }

    .filtros .form-label {
      color: #9ed06f;
    }

    .filtros .form-select {
      background-color: #222;
      color: #fff;
      border: 1px solid #2b5e1d;
    }

    .filtros .btn {
      background-color: #2b5e1d;
      color: #fff;
    }

    .filtros .btn:hover {
      background-color: #fcd634;
      color: #000;
    }

    /* ===========================
       PRODUTOS
    =========================== */
    .produtos {
      padding: 60px 15px;
    }

    .produtos h2 {
      font-weight: 700;
      margin-bottom: 30px;
      color: #fcd634;
      /* amarelo para títulos */
      text-align: center;
    }

    .produtos .categoria {
      margin-bottom: 60px;
    }

    .produtos .categoria h3 {
      color: #9ed06f;
      margin-bottom: 20px;
      text-align: left;
      border-bottom: 2px solid #2b5e1d;
      padding-bottom: 5px;
    }

    .produtos .card {
      background-color: #111;
      border: 1px solid #2b5e1d;
      border-radius: 10px;
      transition: transform 0.3s;
    }

    .produtos .card:hover {
      transform: scale(1.05);
      border-color: #fcd634;
    }

    .produtos .card img {
      border-top-left-radius: 10px;
      border-top-right-radius: 10px;
      max-height: 250px;
      object-fit: cover;
    }

    .produtos .card-body {
      text-align: center;
    }

    .produtos .card-title {
      font-weight: 600;
      color: #fff;
    }

    .produtos .card-text {
      color: #ccc;
    }

    .produtos .preco {
      color: #fcd634;
      font-weight: bold;
      font-size: 1.2em;
    }

    .produtos .btn-comprar {
      background-color: #2b5e1d;
      color: #fff;
      border-radius: 20px;
    }

    .produtos .btn-comprar:hover {
      background-color: #fcd634;
      color: #000;
    }

    .sem-produtos {
      text-align: center;
      color: #ccc;
      font-style: italic;
    }

    .badge-estoque {
      font-size: 0.8em;
    }

    .vendido {
      color: #dc3545;
      font-weight: bold;
    }

    /* ===========================
       FOOTER
    =========================== */
    footer {
      background-color: #014d00;
      color: #fff;
      padding: 40px 20px;
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      text-align: center;
      gap: 20px;
    }

    footer a {
      color: #fff;
      text-decoration: none;
    }

    footer a:hover {
      color: #9ed06f;
    }

    .footer-social i {
      font-size: 24px;
      color: #fff;
      margin-right: 8px;
    }

    /* ===========================
       RESPONSIVO
    =========================== */
    @media (max-width: 768px) {
      .produtos .row {
        flex-direction: column;
        gap: 20px;
      }

      .navbar form {
        margin-top: 10px;
      }
    }
  </style>
  </header>

<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.html">
        <img src="../../public/img/logo.png" alt="Logo" style="height: 80px; width:auto;">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
        <span class="navbar-toggler-icon" style="color:#fff;"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link active" href="index.html">Início</a></li>
          <li class="nav-item"><a class="nav-link" href="produtos.php">Produtos</a></li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdownMenu" role="button" data-bs-toggle="dropdown">
              Categorias
            </a>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
              <li><a class="dropdown-item" href="#novidade">Novidade</a></li>
              <li><a class="dropdown-item" href="#todos">Todos</a></li>
              <li><a class="dropdown-item" href="#promocoes">Promoções</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#bermudas-shorts">Bermudas e Shorts</a></li>
              <li><a class="dropdown-item" href="#blazers">Blazers</a></li>
              <li><a class="dropdown-item" href="#blusas-camisas">Blusas e Camisas</a></li>
              <li><a class="dropdown-item" href="#calcas">Calças</a></li>
              <li><a class="dropdown-item" href="#casacos-jaquetas">Casacos e Jaquetas</a></li>
              <li><a class="dropdown-item" href="#conjuntos">Conjuntos</a></li>
              <li><a class="dropdown-item" href="#saias">Saias</a></li>
              <li><a class="dropdown-item" href="#sapatos">Sapatos</a></li>
              <li><a class="dropdown-item" href="#social">Social</a></li>
              <li><a class="dropdown-item" href="#vestidos">Vestidos</a></li>
            </ul>
          </li>
        </ul>

        <form class="d-flex me-3" role="search" method="GET" action="produtos.php">
          <input class="form-control me-2" type="search" name="busca" placeholder="Buscar produtos..."
            value="<?php echo htmlspecialchars($termo_busca); ?>" aria-label="Search">
          <button class="btn btn-dark" type="submit">Buscar</button>
        </form>

        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item me-3">
            <a class="nav-link" href="minha-conta.html">Minha Conta</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="carrinho.html">Carrinho <span class="badge bg-danger">0</span></a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <section>
    <p>Teste</p>
    <li class="nav-item">
    <a class="nav-link" href="../controller/logout.php">
        <i class="bi bi-box-arrow-right"></i> Sair
    </a>
</li>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-social">
      <h5>Siga-nos:</h5>
      <p><i class="bi bi-instagram"></i> <a href="https://www.instagram.com/brechokokero"
          target="_blank">@brechokokero</a></p>
      <p><i class="bi bi-whatsapp"></i> <a href="https://wa.me/5511992424158" target="_blank">+55 11 99242-4158</a></p>
    </div>
    <div class="footer-links">
      <h5>Links Úteis</h5>
      <ul>
        <li><a href="index.html">Início</a></li>
        <li><a href="produtos.php">Produtos</a></li>
        <li><a href="promocoes.html">Promoções</a></li>
        <li><a href="contato.html">Contato</a></li>
      </ul>
    </div>
    <div class="footer-logo">
      <img src="../../public/img/logo.png" alt="Logo" style="height: 60px; width: auto;">
      <p>&copy; 2024 Brechó Kokero. Todos os direitos reservados.</p>
    </div>
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();
unset($_SESSION['carrinho']); // Remove todos os itens
echo "Carrinho limpo";
?>
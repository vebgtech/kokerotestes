<?php
// Inicia a sessão para acessar o carrinho de compras
session_start();
// Inclui o arquivo de conexão com o banco de dados
include('../config/conexao.php');

// Verifica se o carrinho existe na sessão e não está vazio
if (!isset($_SESSION['carrinho']) || count($_SESSION['carrinho']) === 0) {
    // Se o carrinho estiver vazio, redireciona para a página de produtos
    header("Location: produtos.php");
    exit; // Encerra a execução do script
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Finalizar Compra | Brechó Kokero</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; } /* Fundo cinza claro */
    .card { border-radius: 15px; } /* Cantos arredondados para cards */
    .btn-success { 
        background-color: #2b5e1d; /* Verde escuro personalizado */
        border: none; /* Remove borda padrão */
    }
    .btn-success:hover { 
        background-color: #244d17; /* Verde mais escuro no hover */
    }
  </style>
</head>
<body>
<div class="container py-5">
  <!-- Título da página com ícone -->
  <h2 class="mb-4 text-success"><i class="bi bi-bag-check"></i> Finalizar Compra</h2>

  <div class="row">
    <!-- 🧍 SEÇÃO: Dados do Cliente -->
    <div class="col-md-6">
      <div class="card shadow-sm mb-4">
        <div class="card-body">
          <h5 class="card-title mb-3">Dados para entrega</h5>
          <!-- Formulário de dados do cliente -->
          <form id="checkoutForm">
            <!-- Campo Nome Completo -->
            <div class="mb-3">
              <label class="form-label">Nome completo</label>
              <input type="text" id="nome" class="form-control" required>
            </div>
            
            <!-- Campo Telefone -->
            <div class="mb-3">
              <label class="form-label">Telefone (WhatsApp)</label>
              <input type="tel" id="telefone" class="form-control" required placeholder="(11) 99999-9999">
            </div>
            
            <!-- Campo CEP com busca automática -->
            <div class="mb-3">
              <label class="form-label">CEP</label>
              <input type="text" id="cep" class="form-control" maxlength="9" required>
            </div>
            
            <!-- Campos de endereço (preenchidos automaticamente via CEP) -->
            <div class="mb-3">
              <label class="form-label">Rua</label>
              <input type="text" id="rua" class="form-control" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Número</label>
              <input type="text" id="numero" class="form-control" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Bairro</label>
              <input type="text" id="bairro" class="form-control" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Cidade</label>
              <input type="text" id="cidade" class="form-control" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Estado</label>
              <input type="text" id="estado" class="form-control" required>
            </div>
            
            <!-- Campo opcional -->
            <div class="mb-3">
              <label class="form-label">Complemento (opcional)</label>
              <input type="text" id="complemento" class="form-control">
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- 💰 SEÇÃO: Resumo do Pedido -->
    <div class="col-md-6">
      <div class="card shadow-sm">
        <div class="card-body">
          <h5 class="card-title mb-3">Resumo do Pedido</h5>
          <!-- Lista de itens do carrinho -->
          <ul class="list-group mb-3">
            <?php
              // Inicializa variáveis para cálculo do total
              $total = 0;
              $itens = []; // Array para armazenar dados dos itens (usado no JavaScript)
              
              // Itera sobre cada produto no carrinho (armazenado por ID na sessão)
              foreach ($_SESSION['carrinho'] as $id) {
                  // Prepara consulta para buscar detalhes do produto
                  $stmt = $conn->prepare("SELECT nome, preco FROM produtos WHERE idProduto = ?");
                  $stmt->bind_param("i", $id); // "i" = integer
                  $stmt->execute();
                  $res = $stmt->get_result();
                  
                  // Se encontrou o produto, exibe e calcula total
                  if ($p = $res->fetch_assoc()) {
                      $total += $p['preco']; // Soma ao total
                      $itens[] = $p; // Armazena no array para uso posterior
                      
                      // Exibe o item na lista
                      echo '<li class="list-group-item d-flex justify-content-between align-items-center">'
                        . htmlspecialchars($p['nome']) . // Previne XSS
                        '<span>R$ ' . number_format($p['preco'], 2, ',', '.') . '</span></li>';
                  }
              }
            ?>
          </ul>
          
          <!-- Exibe o total do pedido -->
          <div class="d-flex justify-content-between">
            <strong>Total:</strong>
            <strong class="text-success">R$ <?php echo number_format($total, 2, ',', '.'); ?></strong>
          </div>
          
          <hr>
          
          <!-- Botão para finalizar pedido via WhatsApp -->
          <button id="enviarWhatsApp" class="btn btn-success w-100 mt-3">
            <i class="bi bi-whatsapp"></i> Enviar pedido via WhatsApp
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  
// 📦 INTEGRAÇÃO COM VIA CEP: Busca automática de endereço
document.getElementById('cep').addEventListener('blur', function() {
  // Remove caracteres não numéricos do CEP
  const cep = this.value.replace(/\D/g, '');
  
  // Verifica se o CEP tem 8 dígitos
  if (cep.length !== 8) {
    alert('CEP deve conter exatamente 8 dígitos');
    this.focus(); // volta o foco para o campo
    this.select(); // seleciona o texto para facilitar correção
    return;
  }

  // Faz requisição à API ViaCEP
  fetch(`https://viacep.com.br/ws/${cep}/json/`)
    .then(res => res.json())
    .then(data => {
      // Se CEP não for encontrado
      if (data.erro) {
        alert('CEP não encontrado.');
        this.focus(); // volta o foco para o campo
        this.select(); // seleciona o texto para facilitar correção
        return;
      }
      
      // Preenche automaticamente os campos de endereço
      document.getElementById('rua').value = data.logradouro || '';
      document.getElementById('bairro').value = data.bairro || '';
      document.getElementById('cidade').value = data.localidade || '';
      document.getElementById('estado').value = data.uf || '';
    })
    .catch(() => alert('Erro ao buscar CEP.')); // Trata erros na requisição
});

// 🟢 ENVIAR PEDIDO VIA WHATSAPP
document.getElementById('enviarWhatsApp').addEventListener('click', function() {
  // Obtém valores dos campos do formulário
  const nome = document.getElementById('nome').value.trim();
  const telefone = document.getElementById('telefone').value.trim();
  const cep = document.getElementById('cep').value.trim();
  const rua = document.getElementById('rua').value.trim();
  const numero = document.getElementById('numero').value.trim();
  const bairro = document.getElementById('bairro').value.trim();
  const cidade = document.getElementById('cidade').value.trim();
  const estado = document.getElementById('estado').value.trim();
  const complemento = document.getElementById('complemento').value.trim();

  // Valida se todos os campos obrigatórios foram preenchidos
  if (!nome || !telefone || !cep || !rua || !numero || !bairro || !cidade || !estado) {
    alert('Por favor, preencha todos os campos obrigatórios.');
    return; // Interrompe a execução se campos estiverem vazios
  }

  // Número do vendedor (formato internacional: 55 + DDD + número)
  const numeroVendedor = "5511962474158";

  // Constrói a mensagem formatada para WhatsApp
  const mensagem = `🛍️ *Novo pedido - Brechó Kokero*%0A
*Nome:* ${nome}%0A
*Telefone:* ${telefone}%0A
*Endereço:* ${rua}, ${numero} - ${bairro}%0A
*Cidade/UF:* ${cidade}/${estado}%0A
*CEP:* ${cep}%0A
${complemento ? '*Complemento:* ' + complemento + '%0A' : ''}
--------------------%0A
*Itens do Pedido:*%0A
<?php
// Gera a lista de itens dinamicamente a partir do PHP
foreach ($itens as $p) {
  // Formata cada item do pedido (escapado para JavaScript)
  echo '- ' . addslashes($p['nome']) . ' (R$ ' . number_format($p['preco'], 2, ',', '.') . ')%0A';
}
?>
--------------------%0A
*Total:* R$ <?php echo number_format($total, 2, ',', '.'); ?>%0A`;

  // Constrói o link do WhatsApp com a mensagem
  const link = `https://wa.me/${numeroVendedor}?text=${mensagem}`;

  // 🧹 LIMPA O CARRINHO NO SERVIDOR via AJAX
  fetch('../controller/limpar_carrinho.php', { method: 'POST' })
    .then(() => {
      // Se a limpeza for bem-sucedida:
      // 1. Abre o WhatsApp em nova aba
      window.open(link, '_blank');
      // 2. Redireciona para produtos após 1 segundo
      setTimeout(() => {
        window.location.href = 'produtos.php';
      }, 1000);
    })
    .catch(() => {
      // Se houver erro na limpeza, ainda envia o pedido
      alert('Erro ao limpar o carrinho, mas o pedido foi enviado.');
      window.open(link, '_blank');
    });
});
</script>

</body>
</html>
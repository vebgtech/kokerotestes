document.addEventListener('DOMContentLoaded', function () {
    // Apenas para telas mobile (onde o hover não funciona)
    if (window.innerWidth < 992) {
        document.querySelectorAll('.dropdown-submenu a.dropdown-toggle').forEach(function (element) {
            element.addEventListener('click', function (e) {
                // Impede que o link seja seguido e que o menu principal feche
                e.preventDefault();
                e.stopPropagation();
                
                let parentMenu = this.closest('.dropdown-menu');
                
                // Fecha outros submenus que possam estar abertos no mesmo nível
                parentMenu.querySelectorAll('.dropdown-submenu .dropdown-menu.show').forEach(function(openSubmenu) {
                    if (openSubmenu !== this.nextElementSibling) {
                        openSubmenu.classList.remove('show');
                    }
                });
                
                // Abre ou fecha o submenu atual
                this.nextElementSibling.classList.toggle('show');
            });
        });
    }
});
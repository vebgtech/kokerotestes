<?php
include('../config/conexao.php');  // Sua conexão ao banco

// Processar ações (adicionar, editar, excluir)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao == 'adicionar') {
        $nome = trim($_POST['nome']);
        $marca = trim($_POST['marca'] ?? '');
        $tamanho = trim($_POST['tamanho'] ?? '');
        $cor = trim($_POST['cor'] ?? '');
        $genero = trim($_POST['genero']);
        $idCategoria = (int)$_POST['idCategoria'];  // Cast para int
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = (float)$_POST['preco'];  // Cast para float/double
        $promocao = isset($_POST['promocao']) ? 1 : 0;  // Int para TINYINT
        $imagem = 'default.jpg';  // Salva só o nome do arquivo no banco (default simples)

        // Upload de imagem
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $target_dir = "../../public/img/";  // Path absoluto relativo ao admin
            if (!is_dir($target_dir)) { 
                mkdir($target_dir, 0775, true); 
            }
            $file_extension = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif']) && $_FILES['imagem']['size'] <= 5000000) {
                $novo_nome = 'produto_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
                $target_file = $target_dir . $novo_nome;
                if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target_file)) {
                    $imagem = $novo_nome;  // Salva só o nome no banco
                } else {
                    error_log("Falha no upload: " . $target_file);  // Log para depuração
                }
            } else {
                error_log("Arquivo inválido: " . $_FILES['imagem']['name']);
            }
        }

        $stmt = $conn->prepare("INSERT INTO produtos (nome, marca, tamanho, cor, genero, idCategoria, descricao, preco, promocao, imagem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('sssssisdis', $nome, $marca, $tamanho, $cor, $genero, $idCategoria, $descricao, $preco, $promocao, $imagem);
        if ($stmt->execute()) {
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "<div class='alert alert-danger'>Erro ao adicionar: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }

    if ($acao == 'editar') {
        $idProduto = (int)$_POST['idProduto'];  // Cast para int
        $nome = trim($_POST['nome']);
        $marca = trim($_POST['marca'] ?? '');
        $tamanho = trim($_POST['tamanho'] ?? '');
        $cor = trim($_POST['cor'] ?? '');
        $genero = trim($_POST['genero']);
        $idCategoria = (int)$_POST['idCategoria'];  // Cast para int
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = (float)$_POST['preco'];  // Cast para float
        $promocao = isset($_POST['promocao']) ? 1 : 0;  // Int
        $imagem_atual = $_POST['imagem_atual'] ?? 'default.jpg';  // Nome do arquivo do banco

        // Upload de nova imagem (opcional)
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
            $target_dir = "../../public/img/";
            if (!is_dir($target_dir)) { 
                mkdir($target_dir, 0775, true); 
            }
            $file_extension = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            if (in_array($file_extension, ['jpg', 'jpeg', 'png', 'gif']) && $_FILES['imagem']['size'] <= 5000000) {
                $novo_nome = 'produto_' . time() . '_' . rand(1000, 9999) . '.' . $file_extension;
                $target_file = $target_dir . $novo_nome;
                if (move_uploaded_file($_FILES['imagem']['tmp_name'], $target_file)) {
                    // Deletar imagem antiga
                    $imagem_antiga_path = $target_dir . $imagem_atual;
                    if ($imagem_atual != 'default.jpg' && file_exists($imagem_antiga_path)) {
                        unlink($imagem_antiga_path);
                    }
                    $imagem_atual = $novo_nome;  // Atualiza só o nome no banco
                } else {
                    error_log("Falha no upload de edição: " . $target_file);
                }
            }
        }

        $stmt = $conn->prepare("UPDATE produtos SET nome=?, marca=?, tamanho=?, cor=?, genero=?, idCategoria=?, descricao=?, preco=?, promocao=?, imagem=? WHERE idProduto=?");
        // String de tipos corrigida para 11 params: s s s s s i s d i s i
        $stmt->bind_param('sssssisdisi', $nome, $marca, $tamanho, $cor, $genero, $idCategoria, $descricao, $preco, $promocao, $imagem_atual, $idProduto);
        if ($stmt->execute()) {
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            echo "<div class='alert alert-danger'>Erro ao editar: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }

    if ($acao == 'excluir') {
        $idProduto = (int)$_POST['idProduto'];  // Cast para int
        $stmt = $conn->prepare("SELECT imagem FROM produtos WHERE idProduto=?");
        $stmt->bind_param("i", $idProduto);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $imagem_nome = $row['imagem'];
            if ($imagem_nome != 'default.jpg') {
                $imagem_path = "../../public/img/" . $imagem_nome;  // Path completo para unlink
                if (file_exists($imagem_path)) {
                    unlink($imagem_path);
                }
            }
        }
        $stmt->close();

        $stmt = $conn->prepare("DELETE FROM produtos WHERE idProduto=?");
        $stmt->bind_param("i", $idProduto);
        $stmt->execute();
        $stmt->close();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

// Consulta categorias
$categorias = $conn->query("SELECT * FROM categorias ORDER BY descricao ASC");

// Consulta produtos
$produtos = $conn->query("SELECT p.*, c.descricao AS categoria 
                          FROM produtos p 
                          LEFT JOIN categorias c ON p.idCategoria = c.idCategoria 
                          ORDER BY idProduto DESC");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Painel do Administrador - Produtos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
      body { background-color: #f8f9fa; font-family: 'Poppins', sans-serif; }
      header { background-color: #2b5e1d; color: #fff; padding: 1rem; text-align: center; }
      .btn-primary { background-color: #2b5e1d; border-color: #2b5e1d; }
      .btn-primary:hover { background-color: #244e18; }
      .card { border-radius: 1rem; box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075); }
      .section-header { background-color: #e9ecef; border-radius: 0.5rem; padding: 1rem; margin-bottom: 1rem; }
      .table th { background-color: #2b5e1d; color: white; }
      .table img { max-width: 50px; height: auto; border-radius: 5px; }
      .badge-promocao { background-color: #ffc107; color: #000; }
      #preview_imagem_atual { max-width: 200px; max-height: 200px; border-radius: 8px; margin-top: 10px; display: block; }  /* Estilo para preview no modal */
  </style>
</head>
<body>

<header>
  <h2>Painel do Administrador</h2>
  <p>Gerencie seus produtos de forma completa e organizada</p>
</header>

<div class="container my-5">
    <div class="section-header">
        <h4><i class="bi bi-plus-circle"></i> Cadastrar Novo Produto</h4>
    </div>
    <div class="card p-4 shadow-sm mb-5">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="acao" value="adicionar">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nome do Produto</label>
                    <input type="text" name="nome" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Marca</label>
                    <input type="text" name="marca" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tamanho</label>
                    <input type="text" name="tamanho" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Cor</label>
                    <input type="text" name="cor" class="form-control">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Gênero</label>
                    <select name="genero" class="form-select">
                        <option value="Feminino">Feminino</option>
                        <option value="Masculino">Masculino</option>
                        <option value="Unissex">Unissex</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Categoria</label>
                    <select name="idCategoria" class="form-select" required>
                        <option value="">Selecione uma categoria</option>
                        <?php while($c = $categorias->fetch_assoc()): ?>
                            <option value="<?= $c['idCategoria'] ?>"><?= htmlspecialchars($c['descricao']) ?></option>
                        <?php endwhile; $categorias->data_seek(0); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Preço (R$)</label>
                    <input type="number" step="0.01" name="preco" class="form-control" min="0" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Imagem</label>
                    <input type="file" name="imagem" accept="image/*" class="form-control">
                    <small class="text-muted">Apenas JPG, PNG, GIF. Máx. 5MB.</small>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Promoção?</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="promocao" value="1" id="promocao_add">
                        <label class="form-check-label" for="promocao_add">Marcar como promoção</label>
                    </div>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Descrição</label>
                    <textarea name="descricao" rows="3" class="form-control"></textarea>
                </div>
            </div>
            <div class="text-end mt-4">
                <button type="submit" class="btn btn-primary px-4">
                    <i class="bi bi-save"></i> Salvar Produto
                </button>
            </div>
        </form>
    </div>

    <div class="section-header">
        <h4><i class="bi bi-list-ul"></i> Produtos Cadastrados</h4>
    </div>
    <div class="card p-4 shadow-sm">
        <div class="table-responsive">
            <table class="table table-striped align-middle">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Imagem</th>
                    <th>Nome</th>
                    <th>Categoria</th>
                    <th>Preço</th>
                    <th>Promoção</th>
                    <th>Ações</th>
                </tr>
                </thead>
                <tbody>
                <?php while($p = $produtos->fetch_assoc()): ?>
                <tr>
                    <td><?= $p['idProduto'] ?></td>
                    <td>
                        <!-- Path completo relativo ao admin para exibição na tabela -->
                        <img src="../../public/img/<?= htmlspecialchars($p['imagem'] ?? 'default.jpg') ?>" alt="Img <?= htmlspecialchars($p['nome']) ?>" onerror="this.src='../../public/img/default.jpg';">
                    </td>
                    <td><?= htmlspecialchars($p['nome']) ?></td>
                    <td><?= htmlspecialchars($p['categoria'] ?? 'N/A') ?></td>
                    <td>R$ <?= number_format($p['preco'], 2, ',', '.') ?></td>
                    <td><?= $p['promocao'] ? '<span class="badge badge-promocao">Sim</span>' : '<span class="badge bg-secondary">Não</span>' ?></td>
                    <td>
                        <button type="button" class="btn btn-warning btn-sm me-1 editar-btn"
                                data-id="<?= $p['idProduto'] ?>"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>"
                                data-marca="<?= htmlspecialchars($p['marca'] ?? '') ?>"
                                data-tamanho="<?= htmlspecialchars($p['tamanho'] ?? '') ?>"
                                data-cor="<?= htmlspecialchars($p['cor'] ?? '') ?>"
                                data-genero="<?= htmlspecialchars($p['genero'] ?? '') ?>"
                                data-idcategoria="<?= $p['idCategoria'] ?? '' ?>"
                                data-descricao="<?= htmlspecialchars($p['descricao'] ?? '') ?>"
                                data-preco="<?= $p['preco'] ?>"
                                data-promocao="<?= $p['promocao'] ?>"
                                data-imagem="<?= htmlspecialchars($p['imagem'] ?? 'default.jpg') ?>">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button type="button" class="btn btn-danger btn-sm excluir-btn"
                                data-id="<?= $p['idProduto'] ?>"
                                data-nome="<?= htmlspecialchars($p['nome']) ?>">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php if ($produtos->num_rows == 0): ?>
            <div class="text-center py-4">
                <p class="text-muted">Nenhum produto cadastrado ainda. Adicione o primeiro!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal de Edição -->
<div class="modal fade" id="modalEditar" tabindex="-1" aria-labelledby="modalEditarLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title" id="modalEditarLabel">
          <i class="bi bi-pencil"></i> Editar Produto
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="acao" value="editar">
        <input type="hidden" name="idProduto" id="editar_idProduto">
        <input type="hidden" name="imagem_atual" id="editar_imagem_atual">
        <div class="modal-body">
          <!-- Preview da Imagem Atual -->
          <div class="col-md-12 mb-3">
            <label class="form-label">Imagem Atual:</label>
            <img id="preview_imagem_atual" src="" alt="Imagem atual" style="display: none;">
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nome do Produto</label>
              <input type="text" name="nome" id="editar_nome" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Marca</label>
              <input type="text" name="marca" id="editar_marca" class="form-control">
            </div>
            <div class="col-md-4">
              <label class="form-label">Tamanho</label>
              <input type="text" name="tamanho" id="editar_tamanho" class="form-control">
            </div>
            <div class="col-md-4">
              <label class="form-label">Cor</label>
              <input type="text" name="cor" id="editar_cor" class="form-control">
            </div>
            <div class="col-md-4">
              <label class="form-label">Gênero</label>
              <select name="genero" id="editar_genero" class="form-select">
                <option value="Feminino">Feminino</option>
                                <option value="Masculino">Masculino</option>
                <option value="Unissex">Unissex</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Categoria</label>
              <select name="idCategoria" id="editar_idCategoria" class="form-select" required>
                <option value="">Selecione uma categoria</option>
                <?php $categorias->data_seek(0); while($c = $categorias->fetch_assoc()): ?>
                  <option value="<?= $c['idCategoria'] ?>"><?= htmlspecialchars($c['descricao']) ?></option>
                <?php endwhile; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Preço (R$)</label>
              <input type="number" step="0.01" name="preco" id="editar_preco" class="form-control" min="0" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nova Imagem (Opcional)</label>
              <input type="file" name="imagem" accept="image/*" class="form-control">
              <small class="text-muted">Deixe em branco para manter a imagem atual.</small>
            </div>
            <div class="col-md-12">
              <label class="form-label">Descrição</label>
              <textarea name="descricao" id="editar_descricao" rows="3" class="form-control"></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Promoção?</label>
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="promocao" value="1" id="editar_promocao">
                <label class="form-check-label" for="editar_promocao">Marcar como promoção</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-warning">
            <i class="bi bi-save"></i> Atualizar Produto
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Modal de Edição
    const modalEditarEl = document.getElementById('modalEditar');
    if (modalEditarEl) {
        const modalEditar = new bootstrap.Modal(modalEditarEl);
        const editButtons = document.querySelectorAll('.editar-btn');
        editButtons.forEach(button => {
            button.addEventListener('click', function () {
                const data = this.dataset;
                // Preencher campos do formulário
                document.getElementById('editar_idProduto').value = data.id;
                document.getElementById('editar_imagem_atual').value = data.imagem;
                document.getElementById('editar_nome').value = data.nome || '';
                document.getElementById('editar_marca').value = data.marca || '';
                document.getElementById('editar_tamanho').value = data.tamanho || '';
                document.getElementById('editar_cor').value = data.cor || '';
                document.getElementById('editar_genero').value = data.genero || '';
                document.getElementById('editar_idCategoria').value = data.idcategoria || '';
                document.getElementById('editar_descricao').value = data.descricao || '';
                document.getElementById('editar_preco').value = data.preco || '';
                document.getElementById('editar_promocao').checked = (data.promocao == '1' || data.promocao == 1);
                
                // CORRIGIDO: Preview da imagem atual
                const previewImg = document.getElementById('preview_imagem_atual');
                const imagemAtual = data.imagem || 'default.jpg';
                previewImg.src = '../../public/img/' + imagemAtual;
                previewImg.style.display = 'block';
                previewImg.onerror = function() {
                    this.src = '../../public/img/default.jpg';
                };
                
                modalEditar.show();
            });
        });
    }

    // Botões de Excluir
    const deleteButtons = document.querySelectorAll('.excluir-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.dataset.id;
            const nome = this.dataset.nome;
            if (confirm(`Tem certeza que deseja excluir o produto "${nome}"? Esta ação não pode ser desfeita.`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                form.innerHTML = `
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="idProduto" value="${id}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        });
    });
});
</script>

</body>
</html>

<?php
session_start();  // Para carrinho via sessões
include('../config/conexao.php');

// Pegar ID do produto da URL
$idProduto = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($idProduto <= 0) {
    // Erro: ID inválido
    $erro = "ID de produto inválido.";
} else {
    // Buscar produto pelo ID (inclua peso/dimensões se adicionou no banco)
    $stmt = $conn->prepare("SELECT p.*, c.descricao AS categoria 
                            FROM produtos p 
                            LEFT JOIN categorias c ON p.idCategoria = c.idCategoria 
                            WHERE p.idProduto = ?");
    $stmt->bind_param("i", $idProduto);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($produto = $resultado->fetch_assoc()) {
        // Produto encontrado
        // Valores padrão para frete (ajuste ou use do banco)
        $produto['peso'] = $produto['peso'] ?? 0.50;  // kg
        $produto['largura'] = $produto['largura'] ?? 30.00;  // cm
        $produto['altura'] = $produto['altura'] ?? 20.00;  // cm
        $produto['comprimento'] = $produto['comprimento'] ?? 10.00;  // cm
    } else {
        $erro = "Produto não encontrado.";
    }
    $stmt->close();
}

// Processar adicionar ao carrinho (se POST)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['acao']) && $_POST['acao'] == 'adicionar_carrinho' && isset($produto)) {
    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = [];
    }
    $_SESSION['carrinho'][] = $idProduto;  // Adiciona ID
    $sucesso = "Produto único adicionado ao carrinho!";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="icon" type="image/png" href="img/logo.png">
 <title><?php echo isset($produto) ? htmlspecialchars($produto['nome']) . ' - Brechó Koꓘero' : 'Produto - Brechó Koꓘero'; ?></title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
 <link rel="preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="../../public/css/estilo.css">  <style>
    .price { color: #fcd634; font-weight: bold; font-size: 1.5em; }
    .badge { margin-top: 10px; }
    .frete-opcao { border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 10px; background: #f8f9fa; }
    .frete-opcao h6 { color: #2b5e1d; }
    .frete-preco { font-size: 1.2em; color: #fcd634; font-weight: bold; }
 </style>
</head>
<body>

<?php if (isset($erro)): ?>
    <div class="container mt-5">
        <div class="alert alert-danger text-center">
            <h4>Erro!</h4>
            <p><?php echo htmlspecialchars($erro); ?></p>
            <a href="produtos.php" class="btn btn-primary">Voltar aos Produtos</a>
        </div>
    </div>
<?php else: ?>
    <div class="container mt-5">
        <?php if (isset($sucesso)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $sucesso; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <img src="../../public/img/<?php echo htmlspecialchars($produto['imagem'] ?? 'img/default.jpg'); ?>" alt="<?php echo htmlspecialchars($produto['nome']); ?>" class="img-fluid rounded">
                <?php if ($produto['promocao']): ?>
                    <span class="badge bg-warning">Produto Único em Promoção!</span>
                <?php else: ?>
                    <span class="badge bg-info">Produto Único</span>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <h2><?php echo htmlspecialchars($produto['nome']); ?> - <?php echo htmlspecialchars($produto['marca'] ?? ''); ?></h2>
                <p class="price">R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                <p><strong>Categoria:</strong> <?php echo htmlspecialchars($produto['categoria'] ?? 'Sem categoria'); ?></p>
                <p><strong>Gênero:</strong> <?php echo htmlspecialchars($produto['genero'] ?? 'Unissex'); ?></p>
                <p><strong>Tamanho:</strong> <?php echo htmlspecialchars($produto['tamanho'] ?? 'N/A'); ?></p>
                <p><strong>Cor:</strong> <?php echo htmlspecialchars($produto['cor'] ?? 'N/A'); ?></p>
                <p><?php echo nl2br(htmlspecialchars($produto['descricao'] ?? 'Descrição não disponível.')); ?></p>
                
                <form method="POST" class="mt-3">
                    <input type="hidden" name="acao" value="adicionar_carrinho">
                    <button type="submit" class="btn btn-success btn-lg">Adicionar ao Carrinho</button>
                    <small class="text-muted d-block mt-1">Este é um produto único - venda única!</small>
                </form>

                <div class="mt-4">
                    <h4>Calcular Frete (via Melhor Envio)</h4>
                    <form id="frete-form">
                        <div class="mb-3">
                        <label for="cep" class="form-label">Digite seu CEP</label>
                        <input type="text" class="form-control" id="cep" placeholder="Ex: 12345-678" maxlength="9" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Calcular Frete</button>
                    </form>
                    <div id="frete-result" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script.js"></script>

    <script>
    document.getElementById('frete-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const cep = document.getElementById('cep').value.replace(/\D/g, '');  // Remove não-dígitos
        const resultDiv = document.getElementById('frete-result');
        
        if (cep.length !== 8) {
            resultDiv.innerHTML = '<div class="alert alert-warning">CEP inválido! Digite 8 dígitos.</div>';
            return;
        }
        
        // Dados do produto (passados via PHP para JS)
        const produtoData = {
            id: <?php echo $idProduto; ?>,
            preco: <?php echo $produto['preco']; ?>,
            peso: <?php echo $produto['peso']; ?>,
            largura: <?php echo $produto['largura']; ?>,
            altura: <?php echo $produto['altura']; ?>,
            comprimento: <?php echo $produto['comprimento']; ?>
        };
        
        // Enviar para PHP backend via AJAX
        fetch('calcular_frete.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cep_destino: cep, produto: produtoData })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                resultDiv.innerHTML = `<div class="alert alert-danger">Erro: ${data.error}</div>`;
            } else if (data.fretes && data.fretes.length > 0) {
                let opcoesHtml = '<h5>Opções de Frete:</h5>';
                data.fretes.forEach(frete => {
                    opcoesHtml += `
                        <div class="frete-opcao">
                            <h6>${frete.transportadora} - ${frete.servico}</h6>
                            <p><span class="frete-preco">R$ ${frete.valor.replace('.', ',')}</span></p>
                            <p>Prazo: ${frete.prazo_entrega} dias úteis</p>
                            <small>CEP Origem: ${data.cep_origem}</small>
                        </div>
                    `;
                });
                resultDiv.innerHTML = `<div class="alert alert-success">${opcoesHtml}</div>`;
            } else {
                resultDiv.innerHTML = '<div class="alert alert-info">Nenhuma opção de frete disponível para este CEP.</div>';
            }
        })
        .catch(() => {
            resultDiv.innerHTML = '<div class="alert alert-danger">Erro ao calcular frete. Tente novamente.</div>';
        });
    });
    </script>
    
    <?php endif; ?>

</body>
</html>
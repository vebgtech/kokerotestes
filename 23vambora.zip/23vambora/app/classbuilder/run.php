<?php
declare(strict_types=1);

use app\classbuilder\ClassBuilder;

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

$builder = new ClassBuilder();
$builder->buildAll();

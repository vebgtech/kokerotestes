<?php
// Inclui a nova classe de conexão PDO
require_once '../../config/Conexao.php';

try {
    // Obtém a conexão PDO usando Singleton
    $conexao = Conexao::getConexao();
    
    // Busca produtos vendidos há mais de 7 dias
    $stmt = $conexao->prepare("SELECT idProduto, imagem FROM produtos WHERE vendido=1 AND data_venda < DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $stmt->execute();
    
    $produtosExcluidos = 0;
    $imagensExcluidas = 0;
    
    while ($row = $stmt->fetch()) {
        $imagem_nome = $row['imagem'];
        
        // Remove a imagem física se não for a padrão
        if ($imagem_nome != 'default.jpg') {
            $imagem_path = "../../public/img/" . $imagem_nome;
            if (file_exists($imagem_path)) {
                if (unlink($imagem_path)) {
                    $imagensExcluidas++;
                }
            }
        }
        
        // Deletar produto do banco de dados
        $deleteStmt = $conexao->prepare("DELETE FROM produtos WHERE idProduto = ?");
        $deleteStmt->execute([$row['idProduto']]);
        $produtosExcluidos++;
    }
    
    // Log da operação (opcional)
    error_log("Limpeza automática: $produtosExcluidos produtos excluídos, $imagensExcluidas imagens removidas.");
    
} catch (PDOException $e) {
    // Log do erro
    error_log("Erro na limpeza automática: " . $e->getMessage());
}
?>
<?php
// debug_api.php
session_start();

// Configurações de erro
ini_set('display_errors', 1);
error_reporting(E_ALL);
ini_set('log_errors', 1);

echo "<pre>";
echo "=== DEBUG API ===\n";

try {
    // 1. Verificar sessão
    echo "1. Sessão:\n";
    print_r($_SESSION);
    echo "\n";
    
    // 2. Verificar se tem permissão
    if (!isset($_SESSION['idNivelUsuario']) || $_SESSION['idNivelUsuario'] < 2) {
        echo "ERRO: Usuário não tem permissão de admin\n";
        echo "idNivelUsuario: " . ($_SESSION['idNivelUsuario'] ?? 'não definido') . "\n";
        exit;
    }
    
    // 3. Carregar banco de dados
    echo "2. Carregando banco de dados...\n";
    require_once __DIR__ . '/config/database.php';
    
    if (!isset($conn)) {
        echo "ERRO: Variável \$conn não definida\n";
        exit;
    }
    
    if (!$conn) {
        echo "ERRO: Conexão com banco falhou\n";
        exit;
    }
    
    echo "✓ Banco conectado\n";
    
    // 4. Carregar classes
    echo "3. Carregando classes...\n";
    
    $classes = [
        'Produto' => __DIR__ . '/app/model/Produto.php',
        'ProdutoDAO' => __DIR__ . '/app/model/ProdutoDAO.php',
        'AdminController' => __DIR__ . '/app/controller/admincontroller.php'
    ];
    
    foreach ($classes as $name => $path) {
        if (!file_exists($path)) {
            echo "ERRO: Arquivo não encontrado - $path\n";
            exit;
        }
        require_once $path;
        echo "✓ $name carregado\n";
    }
    
    // 5. Testar instância do AdminController
    echo "4. Instanciando AdminController...\n";
    try {
        $controller = new AdminController($conn);
        echo "✓ AdminController instanciado\n";
    } catch (Exception $e) {
        echo "ERRO ao instanciar AdminController: " . $e->getMessage() . "\n";
        echo "Trace: " . $e->getTraceAsString() . "\n";
        exit;
    }
    
    // 6. Testar método listarProdutos
    echo "5. Chamando listarProdutos...\n";
    try {
        ob_start();
        $controller->listarProdutos([]);
        $output = ob_get_clean();
        echo "✓ listarProdutos executado\n";
        echo "Saída: $output\n";
    } catch (Exception $e) {
        echo "ERRO em listarProdutos: " . $e->getMessage() . "\n";
        echo "Trace: " . $e->getTraceAsString() . "\n";
        exit;
    }
    
    echo "\n=== DEBUG CONCLUÍDO ===\n";
    
} catch (Exception $e) {
    echo "ERRO GERAL: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
echo "</pre>";
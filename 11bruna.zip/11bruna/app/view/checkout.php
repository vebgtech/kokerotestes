<?php
// Inicia a sessão para acessar o carrinho de compras
session_start();
// Inclui o arquivo de conexão com o banco de dados
include('../config/conexao.php');

// Verifica se o carrinho existe na sessão e não está vazio
if (!isset($_SESSION['carrinho']) || count($_SESSION['carrinho']) === 0) {
    // Se o carrinho estiver vazio, redireciona para a página de produtos
    header("Location: produtos.php");
    exit; // Encerra a execução do script
}

// Gera a mensagem completa do WhatsApp no PHP
$itensTexto = "";
$total = 0;

foreach ($_SESSION['carrinho'] as $id) {
    $stmt = $conn->prepare("SELECT nome, preco FROM produtos WHERE idProduto = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($p = $res->fetch_assoc()) {
        $total += $p['preco'];
        $itensTexto .= "• " . $p['nome'] . " - R$ " . number_format($p['preco'], 2, ',', '.') . "%0A";
    }
}

$mensagemBase = "✨ *NOVO PEDIDO - BRECHO KOKERO* ✨%0A%0A" .
                "➤ *DADOS DO CLIENTE:*%0A" .
                "   • *Nome:* [NOME]%0A" .
                "   • *Telefone:* [TELEFONE]%0A" .
                "   • *Endereço:* [ENDERECO]%0A" .
                "   • *Cidade/UF:* [CIDADE_UF]%0A" .
                "   • *CEP:* [CEP]%0A" .
                "[COMPLEMENTO]" .
                "[OBSERVACOES]" .
                "%0A➤ *ITENS DO PEDIDO:*%0A" .
                $itensTexto .
                "%0A➤ *SUBTOTAL (produtos):* R$ " . number_format($total, 2, ',', '.') . "%0A%0A" .
                "➤ *FRETE E TOTAL FINAL:*%0A" .
                "*A combinar via WhatsApp*%0A%0A" .
                "_Obrigada pela preferencia!_";
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Finalizar Compra | Brechó Kokero</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="../../public/css/estilo.css">
  
</head>
<body>
<div class="checkout-container">
  <!-- Título da página com ícone -->
  <h2 class="text-success"><i class="bi bi-bag-check"></i> Finalizar Compra</h2>

  <div class="checkout-grid">
    <!-- 🧍 SEÇÃO: Dados do Cliente -->
    <div class="checkout-dados-cliente">
      <div class="checkout-card">
        <div class="card-header">Seus dados de contato 💌</div>
        <div class="card-body">
          
          <!-- Aviso sobre frete -->
          <div class="aviso-frete">
            <h6><span class="emoji">🚚💕</span> Sobre o frete e entrega:</h6>
            <p class="mb-2">
                ✨ <strong>Queridinha(o)!</strong> O valor do frete e o total final serão combinados diretamente 
                no WhatsApp com nossa equipe! 💬<br><br>
                
                🎀 Isso nos permite calcular o frete exato para sua região e te dar 
                um atendimento super personalizado! 💝<br><br>
                
                📦 <strong>Não se preocupe!</strong> Vamos encontrar a opção de entrega mais 
                fofa e econômica para você! 🌈
            </p>
          </div>
          
          <!-- Formulário de dados do cliente -->
          <form class="checkout-form" id="checkoutForm">
            <!-- Campo Nome Completo -->
            <div class="form-group">
              <label class="form-label">Nome completo</label>
              <input type="text" id="nome" class="form-control" required placeholder="Seu nome completo">
            </div>
            
            <!-- Campo Telefone -->
            <div class="form-group">
              <label class="form-label">Telefone (WhatsApp)</label>
              <input type="tel" id="telefone" class="form-control" required placeholder="(11) 99999-9999">
            </div>
            
            <!-- Campo CEP com busca automática -->
            <div class="form-group">
              <label class="form-label">CEP</label>
              <input type="text" id="cep" class="form-control" required placeholder="00000-000">
            </div>
            
            <!-- Campos de endereço (preenchidos automaticamente via CEP) -->
            <div class="form-group">
              <label class="form-label">Rua</label>
              <input type="text" id="rua" class="form-control" required>
            </div>
            
            <div class="form-group">
              <label class="form-label">Número</label>
              <input type="text" id="numero" class="form-control" required>
            </div>
            
            <div class="form-group">
              <label class="form-label">Bairro</label>
              <input type="text" id="bairro" class="form-control" required>
            </div>
            
            <div class="form-group">
              <label class="form-label">Cidade</label>
              <input type="text" id="cidade" class="form-control" required>
            </div>
            
            <div class="form-group">
              <label class="form-label">Estado</label>
              <input type="text" id="estado" class="form-control" required>
            </div>
            
            <!-- Campo opcional -->
            <div class="form-group">
              <label class="form-label">Complemento (opcional)</label>
              <input type="text" id="complemento" class="form-control" placeholder="Apartamento, bloco, referência...">
            </div>

            <!-- Campo opcional para observações -->
            <div class="form-group">
              <label class="form-label">Alguma observação? (opcional)</label>
              <textarea id="observacao" class="form-control" rows="3" placeholder="Nos conte algo importante sobre a entrega ou seu pedido..."></textarea>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- 💰 SEÇÃO: Resumo do Pedido -->
    <div class="checkout-resumo-pedido">
      <div class="checkout-card">
        <div class="card-header">Resumo do Pedido</div>
        <div class="card-body">
          <!-- Lista de itens do carrinho -->
          <ul class="checkout-list mb-3">
            <?php
              // Reinicializa para exibir os itens
              $total = 0;
              
              foreach ($_SESSION['carrinho'] as $id) {
                  $stmt = $conn->prepare("SELECT nome, preco, imagem FROM produtos WHERE idProduto = ?");
                  $stmt->bind_param("i", $id);
                  $stmt->execute();
                  $res = $stmt->get_result();
                  
                  if ($p = $res->fetch_assoc()) {
                      $total += $p['preco'];
                      
                      echo '<li class="list-group-item d-flex justify-content-between align-items-center">'
                        . '<div class="d-flex align-items-center">'
                        . '<img src="../../public/img/' . htmlspecialchars($p['imagem'] ?? 'default.jpg') . '" class="produto-img me-3" alt="' . htmlspecialchars($p['nome']) . '">'
                        . '<div class="produto-info">'
                        . '<div class="produto-nome">' . htmlspecialchars($p['nome']) . '</div>'
                        . '</div>'
                        . '</div>'
                        . '<span class="produto-preco">R$ ' . number_format($p['preco'], 2, ',', '.') . '</span></li>';
                  }
              }
            ?>
          </ul>
          
          <!-- Exibe o total parcial do pedido -->
          <div class="checkout-total">
            <div class="total-line">
              <span>Subtotal dos produtos:</span>
              <span>R$ <?php echo number_format($total, 2, ',', '.'); ?></span>
            </div>
            <div class="total-line">
              <span>Frete:</span>
              <span>A combinar 💕</span>
            </div>
            <div class="total-final">
              <span>Total estimado:</span>
              <span>R$ <?php echo number_format($total, 2, ',', '.'); ?></span>
            </div>
          </div>
          
          <!-- Aviso sobre frete no resumo -->
          <div class="alert alert-warning mb-3">
            <small>💕 <strong>Encontraremos um frete que cabe no seu bolso!</strong> Vamos juntas encontrar a melhor opção! 💝</small>
          </div>
          
          <!-- Botão para finalizar pedido via WhatsApp -->
          <button id="enviarWhatsApp" class="btn-whatsapp" data-mensagem-base="<?php echo htmlspecialchars($mensagemBase); ?>">
            <i class="bi bi-whatsapp"></i> Finalizar pedido no WhatsApp
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// ======================================================
//  SCRIPT PARA CHECKOUT - INTEGRADO DIRETAMENTE
// ======================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Checkout carregado!');
    
    // 🔧 FORMATAÇÃO DO TELEFONE
    const telefoneInput = document.getElementById('telefone');
    if (telefoneInput) {
        telefoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            e.target.removeAttribute('maxlength');
            
            if (value.length > 11) value = value.substring(0, 11);
            
            let formattedValue = '';
            if (value.length > 0) formattedValue = '(' + value.substring(0, 2);
            if (value.length > 2) formattedValue += ') ' + value.substring(2, 7);
            if (value.length > 7) formattedValue += '-' + value.substring(7, 11);
            
            e.target.value = formattedValue;
        });
    }

    // 📦 BUSCA AUTOMÁTICA DE CEP
    const cepInput = document.getElementById('cep');
    if (cepInput) {
        cepInput.addEventListener('blur', function() {
            const cep = this.value.replace(/\D/g, '');
            
            if (cep.length !== 8) {
                this.classList.add('is-invalid');
                let errorMsg = this.parentNode.querySelector('.invalid-feedback');
                if (!errorMsg) {
                    errorMsg = document.createElement('div');
                    errorMsg.className = 'invalid-feedback';
                    this.parentNode.appendChild(errorMsg);
                }
                errorMsg.textContent = 'CEP deve conter exatamente 8 dígitos';
                return;
            }
            
            this.classList.remove('is-invalid');
            this.disabled = true;
            this.placeholder = 'Buscando endereço...';
            
            fetch(`https://viacep.com.br/ws/${cep}/json/`)
                .then(res => res.json())
                .then(data => {
                    this.disabled = false;
                    this.placeholder = '00000-000';
                    
                    if (data.erro) {
                        this.classList.add('is-invalid');
                        let errorMsg = this.parentNode.querySelector('.invalid-feedback');
                        if (!errorMsg) errorMsg = document.createElement('div');
                        errorMsg.className = 'invalid-feedback';
                        errorMsg.textContent = 'CEP não encontrado';
                        this.parentNode.appendChild(errorMsg);
                        return;
                    }
                    
                    document.getElementById('rua').value = data.logradouro || '';
                    document.getElementById('bairro').value = data.bairro || '';
                    document.getElementById('cidade').value = data.localidade || '';
                    document.getElementById('estado').value = data.uf || '';
                    document.getElementById('numero').focus();
                })
                .catch(() => {
                    this.disabled = false;
                    this.placeholder = '00000-000';
                    this.classList.add('is-invalid');
                    let errorMsg = this.parentNode.querySelector('.invalid-feedback');
                    if (!errorMsg) errorMsg = document.createElement('div');
                    errorMsg.className = 'invalid-feedback';
                    errorMsg.textContent = 'Erro ao buscar CEP';
                    this.parentNode.appendChild(errorMsg);
                });
        });

        // Máscara do CEP
        cepInput.addEventListener('input', function() {
            let cep = this.value.replace(/\D/g, '');
            if (cep.length > 5) cep = cep.substring(0, 5) + '-' + cep.substring(5, 8);
            this.value = cep;
            
            if (this.classList.contains('is-invalid')) {
                this.classList.remove('is-invalid');
                const errorMsg = this.parentNode.querySelector('.invalid-feedback');
                if (errorMsg) errorMsg.remove();
            }
        });
    }

    // 🟢 ENVIAR PEDIDO VIA WHATSAPP
    const enviarWhatsAppBtn = document.getElementById('enviarWhatsApp');
    if (enviarWhatsAppBtn) {
        enviarWhatsAppBtn.addEventListener('click', function() {
            console.log('🎯 Botão WhatsApp clicado!');
            
            const nome = document.getElementById('nome').value.trim();
            const telefone = document.getElementById('telefone').value.trim();
            const cep = document.getElementById('cep').value.trim();
            const rua = document.getElementById('rua').value.trim();
            const numero = document.getElementById('numero').value.trim();
            const bairro = document.getElementById('bairro').value.trim();
            const cidade = document.getElementById('cidade').value.trim();
            const estado = document.getElementById('estado').value.trim();
            const complemento = document.getElementById('complemento').value.trim();
            const observacao = document.getElementById('observacao').value.trim();

            // Validações
            if (!nome || !telefone || !cep || !rua || !numero || !bairro || !cidade || !estado) {
                alert('Por favor, preencha todos os campos obrigatórios! 💝');
                return;
            }

            const telefoneLimpo = telefone.replace(/\D/g, '');
            if (telefoneLimpo.length < 10) {
                alert('Por favor, digite um telefone válido com DDD! 📱');
                return;
            }

            // Número do WhatsApp
            const numeroVendedor = "5511962474158";

            // Formata a mensagem
            let mensagem = this.getAttribute('data-mensagem-base');
            mensagem = mensagem.replace('[NOME]', nome);
            mensagem = mensagem.replace('[TELEFONE]', telefone);
            mensagem = mensagem.replace('[ENDERECO]', `${rua}, ${numero} - ${bairro}`);
            mensagem = mensagem.replace('[CIDADE_UF]', `${cidade}/${estado}`);
            mensagem = mensagem.replace('[CEP]', cep);
            mensagem = mensagem.replace('[COMPLEMENTO]', complemento ? `*Complemento:* ${complemento}%0A` : '');
            mensagem = mensagem.replace('[OBSERVACOES]', observacao ? `*Observações:* ${observacao}%0A` : '');

            const link = `https://wa.me/${numeroVendedor}?text=${mensagem}`;

            // Primeiro salva o pedido no banco
            console.log('📦 Salvando pedido no banco...');
            fetch('../controller/salvar_pedido.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    nome_cliente: nome,
                    telefone: telefone,
                    endereco: `${rua}, ${numero} - ${bairro}, ${cidade}/${estado} - CEP: ${cep}`,
                    observacoes_pagamento: observacao,
                    status_pagamento: 'pendente'
                })
            })
            .then(response => {
                console.log('📨 Resposta do servidor recebida');
                return response.text();
            })
            .then(result => {
                console.log('✅ Pedido salvo:', result);
                
                // Abre o WhatsApp
                console.log('📱 Abrindo WhatsApp...');
                window.open(link, '_blank');
                
                // Redireciona após 1 segundo
                setTimeout(() => {
                    console.log('🔄 Redirecionando para produtos...');
                    window.location.href = 'produtos.php';
                }, 1000);
            })
            .catch((error) => {
                console.error('❌ Erro:', error);
                // Mesmo com erro, ainda abre o WhatsApp
                window.open(link, '_blank');
                setTimeout(() => {
                    window.location.href = 'produtos.php';
                }, 1000);
            });

            // Prevenir múltiplos cliques
            this.disabled = true;
            this.innerHTML = '<i class="bi bi-whatsapp"></i> Enviando...';
        });
    }

    // Prevenir envio duplo do formulário
    const formCheckout = document.getElementById('checkoutForm');
    if (formCheckout) {
        formCheckout.addEventListener('submit', function(e) {
            e.preventDefault();
            const submitBtn = this.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="bi bi-whatsapp"></i> Enviando...';
            }
        });
    }
});
</script>

</body>
</html>
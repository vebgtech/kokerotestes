<?php
// verificar_estrutura.php
echo "<h1>Estrutura de Arquivos</h1>";
echo "<p>DIR: " . __DIR__ . "</p>";

function scanDirRecursive($dir, $level = 0) {
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') continue;
        
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        $indent = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level);
        
        if (is_dir($path)) {
            echo $indent . "📁 <strong>$item</strong><br>";
            scanDirRecursive($path, $level + 1);
        } else {
            echo $indent . "📄 $item<br>";
        }
    }
}

echo "<h3>Estrutura completa:</h3>";
scanDirRecursive(__DIR__);

// Testar caminhos específicos
echo "<h3>Testando caminhos:</h3>";
$paths = [
    'api.php' => __DIR__ . DIRECTORY_SEPARATOR . 'api.php',
    'app/api.php' => __DIR__ . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'api.php',
    'model/ProdutoDAO.php' => __DIR__ . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'ProdutoDAO.php',
    'app/model/ProdutoDAO.php' => __DIR__ . DIRECTORY_SEPARATOR . 'app' . DIRECTORY_SEPARATOR . 'model' . DIRECTORY_SEPARATOR . 'ProdutoDAO.php',
];

foreach ($paths as $label => $path) {
    echo "$label: ";
    echo file_exists($path) ? "✅ Existe" : "❌ Não existe";
    echo "<br>";
}
?>
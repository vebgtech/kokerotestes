<?php
declare(strict_types=1);

namespace app\classBuilder;

use app\core\DBConnection;
use RuntimeException;

/**
 * ============================================================================
 *  ZaitTiny Framework - ClassBuilder
 *  ----------------------------------------------------------------------------
 *  Gera scaffolds de:
 *    - Models       em: app/classBuilder/files/_models/      (Model + DAO)
 *    - Controllers  em: app/classBuilder/files/_controllers/
 *    - Views        em: app/classBuilder/files/_views/
 *    - Forms        em: app/classBuilder/files/_forms/       (Bootstrap 5)
 *    - Rotas        em: app/classBuilder/files/_routes.json
 *
 *  Antes de gerar, remove TODAS as pastas/arquivos que começam com "_"
 *  dentro da pasta base (app/classBuilder/files por padrão).
 *
 *  Depende de:
 *    - app\core\DBConnection (usa a configuração de $_SESSION['config']['database'])
 *    - app\core\DBQuery
 *    - app\core\ControllerHandler
 * ============================================================================
 */
class ClassBuilder {
	
	private DBConnection $dbConnection;
	private string       $schemaName;
	private string       $baseDir;
	
	private string $modelsDir;
	private string $controllersDir;
	private string $viewsDir;
	private string $formsDir;
	private string $routesFile;
	
	private array $routes = [];
	
	public function __construct(?string $baseDir = null) {
		$this->dbConnection = new DBConnection();
		
		// Garante sessão para ler a configuração
		if (session_status() === PHP_SESSION_NONE) {
			session_start();
		}
		
		// Pega o schema a partir de $_SESSION['config']['database']['dbname']
		$this->schemaName = (string)($_SESSION['config']['database']['dbname'] ?? '');
		if ($this->schemaName === '') {
			throw new RuntimeException(
					'Schema (dbname) não definido em $_SESSION["config"]["database"]["dbname"].'
					);
		}
		
		// baseDir padrão: app/classBuilder/files
		$appDir = dirname(__DIR__);          // .../app
		$defaultBase = $appDir . DIRECTORY_SEPARATOR . 'classBuilder' . DIRECTORY_SEPARATOR . 'files';
		
		$this->baseDir = $baseDir !== null
		? rtrim($baseDir, DIRECTORY_SEPARATOR)
		: $defaultBase;
		
		// Limpa qualquer artefato pré-existente começando com "_"
		$this->cleanupGenerated();
		
		$this->modelsDir      = $this->baseDir . DIRECTORY_SEPARATOR . '_models';
		$this->controllersDir = $this->baseDir . DIRECTORY_SEPARATOR . '_controllers';
		$this->viewsDir       = $this->baseDir . DIRECTORY_SEPARATOR . '_views';
		$this->formsDir       = $this->baseDir . DIRECTORY_SEPARATOR . '_forms';
		$this->routesFile     = $this->baseDir . DIRECTORY_SEPARATOR . '_routes.json';
		
		$this->ensureDirectories();
	}
	
	/**
	 * Remove tudo que começar com "_" dentro de baseDir.
	 * Ex.: _models, _controllers, _views, _forms, _routes.json, etc.
	 */
	private function cleanupGenerated(): void {
		if (!is_dir($this->baseDir)) {
			@mkdir($this->baseDir, 0777, true);
			return;
		}
		
		$directoryHandle = opendir($this->baseDir);
		if ($directoryHandle === false) {
			return;
		}
		
		while (($entry = readdir($directoryHandle)) !== false) {
			if ($entry === '.' || $entry === '..') {
				continue;
			}
			if (!str_starts_with($entry, '_')) {
				continue;
			}
			
			$fullPath = $this->baseDir . DIRECTORY_SEPARATOR . $entry;
			
			if (is_dir($fullPath)) {
				$this->deleteDirectoryRecursive($fullPath);
			} else {
				@unlink($fullPath);
			}
		}
		closedir($directoryHandle);
	}
	
	private function deleteDirectoryRecursive(string $directoryPath): void {
		if (!is_dir($directoryPath)) {
			return;
		}
		
		$items = scandir($directoryPath);
		if ($items === false) {
			return;
		}
		
		foreach ($items as $item) {
			if ($item === '.' || $item === '..') {
				continue;
			}
			$fullItemPath = $directoryPath . DIRECTORY_SEPARATOR . $item;
			if (is_dir($fullItemPath)) {
				$this->deleteDirectoryRecursive($fullItemPath);
			} else {
				@unlink($fullItemPath);
			}
		}
		@rmdir($directoryPath);
	}
	
	private function ensureDirectories(): void {
		foreach (
				[
						$this->baseDir,
						$this->modelsDir,
						$this->controllersDir,
						$this->viewsDir,
						$this->formsDir
				] as $directory
				) {
					if (!is_dir($directory)) {
						@mkdir($directory, 0777, true);
					}
				}
	}
	
	/**
	 * Ponto principal: gera tudo.
	 */
	public function buildAll(): void {
		$tables = $this->listTables();
		
		foreach ($tables as $tableRow) {
			$tableName = (string)$tableRow['TABLE_NAME'];
			
			$columns = $this->listTableColumns($tableName);
			if (empty($columns)) {
				continue;
			}
			
			$className   = $this->tableToClassName($tableName);
			$primaryKeys = $this->extractPrimaryKeys($columns);
			
			// 1) Model
			$modelCode = $this->buildModelCode($tableName, $className, $columns, $primaryKeys);
			$modelPath = $this->modelsDir . DIRECTORY_SEPARATOR . $className . '.php';
			file_put_contents($modelPath, $modelCode);
			
			// 2) DAO
			$daoCode = $this->buildDaoCode($tableName, $className, $columns, $primaryKeys);
			$daoPath = $this->modelsDir . DIRECTORY_SEPARATOR . $className . 'DAO.php';
			file_put_contents($daoPath, $daoCode);
			
			// 3) Controller
			$controllerCode = $this->buildControllerCode($tableName, $className, $primaryKeys);
			$controllerPath = $this->controllersDir . DIRECTORY_SEPARATOR . $className . 'Ctrl.php';
			file_put_contents($controllerPath, $controllerCode);
			
			// 4) View placeholder (PHP simples)
			//$viewCode = $this->buildViewCode($tableName, $className);
			//$viewPath = $this->viewsDir . DIRECTORY_SEPARATOR . $className . 'View.php';
			//file_put_contents($viewPath, $viewCode);
			
			// 5) Form HTML com Bootstrap 5
			$formCode = $this->buildFormCode($tableName, $className, $columns, $primaryKeys);
			$formPath = $this->formsDir . DIRECTORY_SEPARATOR . $className . 'Form.html';
			file_put_contents($formPath, $formCode);
			
			// 6) Rota sugerida
			$routeName = $tableName;
			$this->routes[$routeName] = [
					'path'       => "app/classBuilder/files/_controllers/{$className}Ctrl.php",
					'sessionKey' => [],
					'sanitize'   => [
							'requestVars' => true,
							'code'        => true,
							'sql'         => true
					],
					'errorPath'  => 'app/views/error.php'
							];
			
			echo "<br>Gerado: Model + DAO + Controller + Form para tabela <b>{$tableName}</b>";
		}
		
		$this->writeRoutesFile();
		
		echo "<hr>Arquivos gerados em: {$this->baseDir}";
	}
	
	// =====================================================================
	// Metadados do schema
	// =====================================================================
	
	private function listTables(): array {
		$sql = "
			SELECT DISTINCT TABLE_NAME
			FROM information_schema.columns
			WHERE TABLE_SCHEMA = :schema
			ORDER BY TABLE_NAME
		";
		return $this->dbConnection->query($sql, [':schema' => $this->schemaName]);
	}
	
	private function listTableColumns(string $tableName): array {
		$sql = "
			SELECT
				ORDINAL_POSITION,
				COLUMN_NAME,
				COLUMN_TYPE,
				COLUMN_KEY,
				COLUMN_DEFAULT,
				IS_NULLABLE,
				DATA_TYPE,
				CHARACTER_MAXIMUM_LENGTH,
				NUMERIC_PRECISION,
				NUMERIC_SCALE
			FROM information_schema.columns
			WHERE TABLE_SCHEMA = :schema
			  AND TABLE_NAME   = :table
			ORDER BY ORDINAL_POSITION
		";
		return $this->dbConnection->query($sql, [
				':schema' => $this->schemaName,
				':table'  => $tableName
		]);
	}
	
	private function extractPrimaryKeys(array $columns): array {
		$primaryKeys = [];
		foreach ($columns as $column) {
			if (($column['COLUMN_KEY'] ?? '') === 'PRI') {
				$primaryKeys[] = (string)$column['COLUMN_NAME'];
			}
		}
		if (empty($primaryKeys) && isset($columns[0]['COLUMN_NAME'])) {
			$primaryKeys[] = (string)$columns[0]['COLUMN_NAME'];
		}
		return $primaryKeys;
	}
	
	// =====================================================================
	// Helpers de nome/tipo
	// =====================================================================
	
	private function tableToClassName(string $tableName): string {
		$tmp = str_replace(['-', '_'], ' ', strtolower($tableName));
		$tmp = ucwords($tmp);
		return str_replace(' ', '', $tmp);
	}
	
	private function sqlTypeToPhpType(array $column): string {
		$dataType = strtolower((string)$column['DATA_TYPE']);
		
		return match ($dataType) {
			'int', 'tinyint', 'smallint', 'mediumint', 'bigint' => '?int',
			'decimal', 'float', 'double', 'real'                => '?float',
			default                                            => '?string',
		};
	}
	
	private function defaultPhpValue(string $phpType): string {
		return 'null';
	}
	
	private function writeRoutesFile(): void {
		$json = json_encode(
				$this->routes,
				JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
				);
		if ($json === false) {
			throw new RuntimeException('Falha ao converter rotas para JSON.');
		}
		file_put_contents($this->routesFile, $json);
	}
	
	// =====================================================================
	// Geração de Model
	// =====================================================================
	
	private function buildModelCode(
			string $tableName,
			string $className,
			array  $columns,
			array  $primaryKeys
			): string {
				$propertiesCode = '';
				$loadCode       = '';
				$toArrayCode    = '';
				$gettersSetters = '';
				
				foreach ($columns as $column) {
					$columnName = (string)$column['COLUMN_NAME'];
					$phpType    = $this->sqlTypeToPhpType($column);
					$defaultVal = $this->defaultPhpValue($phpType);
					
					$propName = $columnName;
					
					$propertiesCode .= "\n\tprivate {$phpType} \${$propName} = {$defaultVal};";
					
					$loadCode .= <<<PHP
					
		if (array_key_exists('{$columnName}', \$data)) {
			\$this->{$propName} = \$data['{$columnName}'] === null
				? null
				: \$data['{$columnName}'];
		}
PHP;
					
					$toArrayCode .= "\n\t\t\t'{$columnName}' => \$this->{$propName},";
					
					$methodSuffix   = ucfirst($propName);
					$gettersSetters .= <<<PHP
					
	public function get{$methodSuffix}(): {$phpType} {
		return \$this->{$propName};
	}
	
	public function set{$methodSuffix}({$phpType} \$value): void {
		\$this->{$propName} = \$value;
	}
	
PHP;
				}
				
				$code = <<<PHP
<?php
declare(strict_types=1);

namespace app\models;

/**
 * Model gerado automaticamente para a tabela `{$tableName}`.
 * Ajuste tipos, validações e regras de negócio conforme necessário.
 */
class {$className} {
{$propertiesCode}

	public function __construct() {
	}
	
	public function load(array \$data): self {{$loadCode}
	
		return \$this;
	}
	
	public static function fromArray(array \$data): self {
		\$model = new self();
		return \$model->load(\$data);
	}
	
	public function toArray(): array {
		return [
{$toArrayCode}
		];
	}
{$gettersSetters}
}

PHP;
return $code;
	}
	
	// =====================================================================
	// Geração de DAO
	// =====================================================================
	
	private function buildDaoCode(
			string $tableName,
			string $className,
			array  $columns,
			array  $primaryKeys
			): string {
				$fieldsNames = implode(', ', array_map(fn($col) => $col['COLUMN_NAME'], $columns));
				$primaryKeysArrayCode = count($primaryKeys) === 1
				? "'" . $primaryKeys[0] . "'"
						: "['" . implode("','", $primaryKeys) . "']";
						
						$primaryKeyFirst = $primaryKeys[0] ?? $columns[0]['COLUMN_NAME'];
						$pkMethodSuffix  = ucfirst($primaryKeyFirst);
						
						$code = <<<PHP
<?php
declare(strict_types=1);

namespace app\models;

use app\core\DBQuery;
use InvalidArgumentException;

/**
 * DAO gerado automaticamente para a tabela `{$tableName}`.
 * Extende DBQuery para operações básicas.
 */
class {$className}DAO extends DBQuery {

	public function __construct() {
		parent::__construct(
			'{$tableName}',
			'{$fieldsNames}',
			{$primaryKeysArrayCode}
		);
	}
	
	public function insert({$className} \$model): string {
		return parent::insert(\$model->toArray());
	}
	
	public function update({$className} \$model): int {
		return parent::update(\$model->toArray());
	}
	
	public function deleteById(int \$id): int {
		if (\$id <= 0) {
			throw new InvalidArgumentException('ID inválido para delete.');
		}
		return parent::delete(['{$primaryKeyFirst}' => \$id]);
	}
	
	public function findById(int \$id): ?{$className} {
		if (\$id <= 0) {
			return null;
		}
		
		\$this->resetWhere();
		\$this->addCondition('AND', '{$primaryKeyFirst}', '=', \$id)
		     ->addLimit(1);
		     
		\$rows = \$this->select();
		if (empty(\$rows)) {
			return null;
		}
		\$row = \$rows[0];
		return {$className}::fromArray(\$row);
	}
	
	public function findAll(): array {
		\$rows = parent::select();
		\$result = [];
		foreach (\$rows as \$row) {
			\$result[] = {$className}::fromArray(\$row);
		}
		return \$result;
	}
}

PHP;
			return $code;
	}
	
	// =====================================================================
	// Geração de Controller
	// =====================================================================
	
	private function buildControllerCode(
			string $tableName,
			string $className,
			array  $primaryKeys
			): string {
				$primaryKeyFirst = $primaryKeys[0] ?? 'id';
				$pkParamName     = $primaryKeyFirst;
				$pkMethodSuffix  = ucfirst($primaryKeyFirst);
				
				$code = <<<PHP
<?php
declare(strict_types=1);

namespace app\controllers;

use app\core\ControllerHandler;
use app\models\\{$className};
use app\models\\{$className}DAO;

/**
 * Controller REST gerado automaticamente para {$className} / tabela `{$tableName}`.
 */
class {$className}Ctrl extends ControllerHandler {

	private {$className}DAO \$dao;
	
	public function __construct() {
		parent::__construct();
		\$this->dao = new {$className}DAO();
	}
	
	protected function doGet(): void {
		\$idParam = \$this->getParameter('{$pkParamName}', null);
		if (\$idParam !== null && \$idParam !== '') {
			\$id    = (int)\$idParam;
			\$model = \$this->dao->findById(\$id);
			if (\$model === null) {
				\$this->jsonEcho(['error' => 'NOT_FOUND'], 404);
			}
			\$this->jsonEcho(['data' => \$model->toArray()]);
		}
		
		\$list = \$this->dao->findAll();
		\$data = [];
		foreach (\$list as \$model) {
			if (\$model instanceof {$className}) {
				\$data[] = \$model->toArray();
			}
		}
		\$this->jsonEcho(['data' => \$data]);
	}
	
	protected function doPost(): void {
		\$data  = \$this->getParameters();
		\$model = new {$className}();
		\$model->load(\$data);
		
		\$newId = \$this->dao->insert(\$model);
		if (is_numeric(\$newId)) {
			\$model->set{$pkMethodSuffix}((int)\$newId);
		}
		
		\$this->jsonEcho(
			[
				'message' => '{$className} criado com sucesso.',
				'data'    => \$model->toArray()
			],
			201
		);
	}
	
	protected function doPut(): void {
		\$data = \$this->getParameters();
		\$id   = isset(\$data['{$pkParamName}']) ? (int)\$data['{$pkParamName}'] : 0;
		
		if (\$id <= 0) {
			\$this->jsonEcho(
				['error' => 'ID_REQUIRED', 'message' => 'Campo {$pkParamName} é obrigatório para update.'],
				400
			);
		}
		
		\$current = \$this->dao->findById(\$id);
		if (\$current === null) {
			\$this->jsonEcho(['error' => 'NOT_FOUND'], 404);
		}
		
		\$currentArray = \$current->toArray();
		foreach (\$data as \$key => \$value) {
			if (array_key_exists(\$key, \$currentArray)) {
				\$currentArray[\$key] = \$value;
			}
		}
		\$current->load(\$currentArray);
		
		\$rows = \$this->dao->update(\$current);
		
		\$this->jsonEcho(
			[
				'message' => '{$className} atualizado com sucesso.',
				'rows'    => \$rows,
				'data'    => \$current->toArray()
			]
		);
	}
	
	protected function doDelete(): void {
		\$idParam = \$this->getParameter('{$pkParamName}', null);
		if (\$idParam === null || \$idParam === '') {
			\$this->jsonEcho(
				['error' => 'ID_REQUIRED', 'message' => 'Campo {$pkParamName} é obrigatório para delete.'],
				400
			);
		}
		
		\$id = (int)\$idParam;
		if (\$id <= 0) {
			\$this->jsonEcho(
				['error' => 'INVALID_ID', 'message' => 'ID inválido para delete.'],
				400
			);
		}
		
		\$rows = \$this->dao->deleteById(\$id);
		
		\$this->jsonEcho(
			[
				'message' => '{$className} removido com sucesso.',
				'rows'    => \$rows
			]
		);
	}
}

// Ponto de entrada
(new {$className}Ctrl())->service();

PHP;
				return $code;
	}
	
	// =====================================================================
	// View placeholder
	// =====================================================================
	
	private function buildViewCode(string $tableName, string $className): string {
		$code = <<<PHP
<?php
declare(strict_types=1);
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>View {$className}</title>
</head>
<body>
	<h1>View {$className}</h1>
	<p>View gerada automaticamente para a tabela <strong>{$tableName}</strong>.</p>
	<p>Ajuste este arquivo conforme a necessidade do seu projeto.</p>
</body>
</html>

PHP;
		return $code;
	}
	
	// =====================================================================
	// Form HTML com Bootstrap 5
	// =====================================================================
	
	private function buildFormCode(
			string $tableName,
			string $className,
			array  $columns,
			array  $primaryKeys
			): string {
				$formFieldsHtml = '';
				$primaryKeySet  = array_flip($primaryKeys);
				
				foreach ($columns as $column) {
					$columnName = (string)$column['COLUMN_NAME'];
					$dataType   = strtolower((string)$column['DATA_TYPE']);
					
					// PK → hidden por padrão
					if (isset($primaryKeySet[$columnName])) {
						$formFieldsHtml .= <<<HTML
						
					<input type="hidden" name="{$columnName}" id="{$columnName}">
HTML;
						continue;
					}
					
					$label   = ucfirst($columnName);
					$inputId = $columnName;
					
					$inputType = match ($dataType) {
						'int', 'tinyint', 'smallint', 'mediumint', 'bigint' => 'number',
						'decimal', 'float', 'double', 'real'                => 'number',
						'date'                                              => 'date',
						'datetime', 'timestamp'                             => 'datetime-local',
						default                                             => 'text',
					};
					
					$formFieldsHtml .= <<<HTML
					
					<div class="mb-3">
						<label for="{$inputId}" class="form-label">{$label}</label>
						<input type="{$inputType}"
						       class="form-control"
						       name="{$columnName}"
						       id="{$inputId}">
					</div>
HTML;
				}
				
				$actionUrl = '/' . $tableName;
				
				$html = <<<HTML
<!DOCTYPE html>
<html lang="pt-BR">
<head>
	<meta charset="utf-8">
	<title>Formulário {$className}</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link
		href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
		rel="stylesheet"
		integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
		crossorigin="anonymous">
</head>
<body>
	<div class="container py-4">
		<h1 class="mb-4">Cadastro {$className}</h1>
		
		<div class="card shadow-sm">
			<div class="card-body">
				<form method="post" action="{$actionUrl}">
{$formFieldsHtml}

					<div class="d-flex justify-content-end">
						<button type="submit" class="btn btn-primary">
							Salvar
						</button>
					</div>
				</form>
			</div>
		</div>
		
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
	        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
	        crossorigin="anonymous"></script>
</body>
</html>
HTML;

return $html;
	}
}

// ----------------------------------------------------------------------
// Execução direta opcional (descomente se quiser rodar via CLI ou browser)
// ----------------------------------------------------------------------
/*
 use app\classBuilder\ClassBuilder;
 
 if (session_status() === PHP_SESSION_NONE) {
 session_start();
 }
 
 \$builder = new ClassBuilder();
 \$builder->buildAll();
 */

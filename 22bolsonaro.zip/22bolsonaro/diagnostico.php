<?php
// diagnostico.php
session_start();
$_SESSION['idNivelUsuario'] = 2;

echo "<h1>Diagnóstico do Sistema</h1>";

// Testar conexão
require_once 'app/config/conexao.php';
try {
    $conn = Conexao::getConexao();
    echo "✅ Conexão com banco: OK<br>";
    
    // Testar DAO
    require_once 'app/model/produto.php';
    require_once 'app/model/produto_dao.php';
    
    $dao = new ProdutoDAO($conn);
    
    // Testar categorias
    $categorias = $dao->getCategorias();
    echo "✅ Categorias: " . count($categorias) . " encontradas<br>";
    
    // Testar produtos
    $produtos = $dao->listar();
    echo "✅ Produtos: " . count($produtos) . " encontrados<br>";
    
    if (count($produtos) > 0) {
        echo "<h3>Primeiro produto:</h3>";
        echo "<pre>";
        print_r($produtos[0]);
        echo "</pre>";
        
        // Testar toArray()
        if (method_exists($produtos[0], 'toArray')) {
            echo "<h3>toArray() do primeiro produto:</h3>";
            echo "<pre>";
            print_r($produtos[0]->toArray());
            echo "</pre>";
        } else {
            echo "❌ Método toArray() não existe na classe Produto<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage() . "<br>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

// Testar API
echo "<h2>Teste da API:</h2>";
$api_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/app/api.php?action=listar";
echo "URL da API: <a href='$api_url' target='_blank'>$api_url</a><br>";

$context = stream_context_create([
    'http' => [
        'header' => 'Cookie: ' . session_name() . '=' . session_id()
    ]
]);

$response = file_get_contents($api_url, false, $context);
echo "<h3>Resposta da API:</h3>";
echo "<pre>" . htmlspecialchars($response) . "</pre>";
?>